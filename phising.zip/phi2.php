<?php

error_reporting(1);
$name = "";

if (isset($_GET["tunnel"])) {

    $getTunnel = file_get_contents('readme.txt');
    $explode = explode(PHP_EOL, $getTunnel);
    foreach ($explode as $item) {
        $str = substr($item, 1);
        $replace = trim(str_replace(' ', '-', $str));
        if ($_GET['tunnel'] == $replace) {
            $name = str_replace('-', " ", strtoupper($replace));
        }
    }

    if ($name != "") {
?>
<!doctype html>
  <html class="no-js" lang="en">
    <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width,initial-scale=1">
      <meta name="theme-color" content="">
      <link rel="canonical" href="<?php echo 'https://' . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]; ?>">
      <link rel="amphtml" href="https://ampdragonhunter.com/">
      <link rel="preconnect" href="https://cdn.shopify.com" crossorigin>
      <link rel="icon" type="image/png" href="https://i.ibb.co/6Z5fsh6/iconseru.png">
      <link rel="preconnect" href="https://fonts.shopifycdn.com" crossorigin>
      <title><?php echo $name; ?> | Situs Gacor Pasti Seru Main Bareng Teman</title>
      <meta name="description" content="<?php echo $name; ?> penyedia tempat main seru paling gacor dari situs dan berbagai permainan yang ada dengan teman bareng bisa gacor maxwin jutaan rupiah setiap hari tanpa harus keluar rumah.">
      <meta name="robots" content="index, follow" />
      <meta content="true" name="HandheldFriendly">
      <meta content="width" name="MobileOptimized">
      <meta name="apple-mobile-web-app-status-bar-style" content="default"/>
      <meta name="apple-mobile-web-app-capable" content="yes"/>
      <meta name="mobile-web-app-capable" content="yes"/>
      <meta name="language" content="ID">
      <meta name="copyright" content="<?php echo $name; ?>">
      <meta name="author" content="<?php echo $name; ?>">
      <meta name="distribution" content="global">
      <meta name="publisher" content="<?php echo $name; ?>">
      <meta name="geo.placename" content="DKI Jakarta">
      <meta name="geo.country" content="ID">
      <meta name="geo.region" content="ID"/>
      <meta name="tgn.nation" content="Indonesia">
      <meta property="og:locale" content="id_ID"/>
      <meta property="og:site_name" content="<?php echo $name; ?>">
      <meta property="og:url" content="<?php echo 'https://' . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]; ?>">
      <meta property="og:title" content="<?php echo $name; ?> | Situs Gacor Pasti Seru Main Bareng Teman">
      <meta property="og:type" content="product">
      <meta property="og:description" content="<?php echo $name; ?> penyedia tempat main seru paling gacor dari situs dan berbagai permainan yang ada dengan teman bareng bisa gacor maxwin jutaan rupiah setiap hari tanpa harus keluar rumah.">
      <meta property="og:image" content="https://i.ibb.co/BC6QyzQ/slotgacor.webp">
      <meta property="og:image:secure_url" content="https://i.ibb.co/BC6QyzQ/slotgacor.webp">
      <meta property="og:image:width" content="2000">
      <meta property="og:image:height" content="2000">
      <meta property="og:price:amount" content="1.11">
      <meta property="og:price:currency" content="USD">
      <meta name="twitter:site" content="@eatmaxjerky">
      <meta name="twitter:card" content="summary_large_image">
      <meta name="twitter:title" content="<?php echo $name; ?> | Situs Gacor Pasti Seru Main Bareng Teman">
      <meta name="twitter:description" content="<?php echo $name; ?> penyedia tempat main seru paling gacor dari situs dan berbagai permainan yang ada dengan teman bareng bisa gacor maxwin jutaan rupiah setiap hari tanpa harus keluar rumah.">
      <script src="//www.maxjerky.com/cdn/shop/t/3/assets/constants.js?v=165488195745554878101680102127" defer="defer"></script>
      <script src="//www.maxjerky.com/cdn/shop/t/3/assets/pubsub.js?v=2921868252632587581680102127" defer="defer"></script>
      <script src="//www.maxjerky.com/cdn/shop/t/3/assets/global.js?v=121644587955111361041701424430" defer="defer"></script>
      <script>
        window.performance && window.performance.mark && window.performance.mark('shopify.content_for_header.start');
      </script>
      <meta id="shopify-digital-wallet" name="shopify-digital-wallet" content="/71318765888/digital_wallets/dialog">
      <meta name="shopify-checkout-api-token" content="27c8dfa06223bd56a6f2332e69934dcf">
      <meta id="in-context-paypal-metadata" data-shop-id="71318765888" data-venmo-supported="true" data-environment="production" data-locale="en_US" data-paypal-v4="true" data-currency="USD">
      <link rel="alternate" type="application/json+oembed" href="<?php echo 'https://' . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]; ?>">
      <script async="async" src="/checkouts/internal/preloads.js?locale=en-US"></script>
      <script id="apple-pay-shop-capabilities" type="application/json">
        {
          "shopId": 71318765888,
          "countryCode": "US",
          "currencyCode": "USD",
          "merchantCapabilities": ["supports3DS"],
          "merchantId": "gid:\/\/shopify\/Shop\/71318765888",
          "merchantName": "<?php echo $name; ?>",
          "requiredBillingContactFields": ["postalAddress", "email"],
          "requiredShippingContactFields": ["postalAddress", "email"],
          "shippingType": "shipping",
          "supportedNetworks": ["visa", "masterCard", "amex", "discover", "elo", "jcb"],
          "total": {
            "type": "pending",
            "label": "<?php echo $name; ?>",
            "amount": "1.00"
          },
          "shopifyPaymentsEnabled": true,
          "supportsSubscriptions": true
        }
      </script>
      <script id="shopify-features" type="application/json">
        {
          "accessToken": "27c8dfa06223bd56a6f2332e69934dcf",
          "betas": ["rich-media-storefront-analytics"],
          "domain": "www.maxjerky.com",
          "predictiveSearch": true,
          "shopId": 71318765888,
          "smart_payment_buttons_url": "https:\/\/www.maxjerky.com\/cdn\/shopifycloud\/payment-sheet\/assets\/latest\/spb.en.js",
          "dynamic_checkout_cart_url": "https:\/\/www.maxjerky.com\/cdn\/shopifycloud\/payment-sheet\/assets\/latest\/dynamic-checkout-cart.en.js",
          "locale": "en",
          "optimusEnabled": true,
          "optimusHidden": false,
          "betterDynamicCheckoutRecommendationVariant": "control",
          "shopPromisePDPV3Enabled": true
        }
      </script>
      <script>
        var Shopify = Shopify || {};
        Shopify.shop = "maxjerky.myshopify.com";
        Shopify.locale = "en";
        Shopify.currency = {
          "active": "USD",
          "rate": "1.0"
        };
        Shopify.country = "US";
        Shopify.theme = {
          "name": "Github Code\/\/Custom Sense",
          "id": 147102531904,
          "theme_store_id": null,
          "role": "main"
        };
        Shopify.theme.handle = "null";
        Shopify.theme.style = {
          "id": null,
          "handle": null
        };
        Shopify.cdnHost = "www.maxjerky.com/cdn";
        Shopify.routes = Shopify.routes || {};
        Shopify.routes.root = "/";
      </script>
      <script type="module">
        ! function(o) {
          (o.Shopify = o.Shopify || {}).modules = !0
        }(window);
      </script>
      <script>
        ! function(o) {
          function n() {
            var o = [];
  
            function n() {
              o.push(Array.prototype.slice.apply(arguments))
            }
            return n.q = o, n
          }
          var t = o.Shopify = o.Shopify || {};
          t.loadFeatures = n(), t.autoloadFeatures = n()
        }(window);
      </script>
      <script>
        window.ShopifyPay = window.ShopifyPay || {};
        window.ShopifyPay.apiHost = "shop.app\/pay";
      </script>
      <script>
        window.Shopify = window.Shopify || {};
        if (!window.Shopify.featureAssets) window.Shopify.featureAssets = {};
        window.Shopify.featureAssets['shop-js'] = {
          "pay-button": ["modules/client.pay-button_79c3c26b.en.esm.js", "modules/chunk.common_831fa0cb.esm.js"],
          "init-shop-email-lookup-coordinator": ["modules/client.init-shop-email-lookup-coordinator_27bbf9a8.en.esm.js", "modules/chunk.common_831fa0cb.esm.js"],
          "init-customer-accounts-sign-up": ["modules/client.init-customer-accounts-sign-up_1766bbbf.en.esm.js", "modules/chunk.common_831fa0cb.esm.js"],
          "init-customer-accounts": ["modules/client.init-customer-accounts_e88efa16.en.esm.js", "modules/chunk.common_831fa0cb.esm.js"],
          "init-shop-for-new-customer-accounts": ["modules/client.init-shop-for-new-customer-accounts_ecdd363e.en.esm.js", "modules/chunk.common_831fa0cb.esm.js"],
          "shop-pay-payment-request": ["modules/client.shop-pay-payment-request_05a19cae.en.esm.js", "modules/chunk.common_831fa0cb.esm.js", "modules/chunk.shop-pay_e0998b06.esm.js"],
          "login-button": ["modules/client.login-button_f4a48b65.en.esm.js", "modules/chunk.common_831fa0cb.esm.js"],
          "discount-app": ["modules/client.discount-app_f81c33ef.en.esm.js", "modules/chunk.common_831fa0cb.esm.js"],
          "payment-terms": ["modules/client.payment-terms_26bab528.en.esm.js", "modules/chunk.common_831fa0cb.esm.js"]
        };
      </script>
      <script>
        (function() {
          function asyncLoad() {
            var urls = ["https:\/\/cdn.pickystory.com\/widget\/static\/js\/noop.js?shop=maxjerky.myshopify.com", "https:\/\/geolocation-recommendations.shopifyapps.com\/locale_bar\/script.js?shop=maxjerky.myshopify.com", "https:\/\/cdn1.judge.me\/assets\/installed.js?shop=maxjerky.myshopify.com", "https:\/\/cdn.nfcube.com\/instafeed-2bf4c4f2a3436413659eeed2a8ce94ca.js?shop=maxjerky.myshopify.com", "https:\/\/id-shop.govx.com\/app\/maxjerky.myshopify.com\/govx.js?shop=maxjerky.myshopify.com", "https:\/\/cdn.attn.tv\/maxjerky\/dtag.js?shop=maxjerky.myshopify.com"];
            for (var i = 0; i < urls.length; i++) {
              var s = document.createElement('script');
              s.type = 'text/javascript';
              s.async = true;
              s.src = urls[i];
              var x = document.getElementsByTagName('script')[0];
              x.parentNode.insertBefore(s, x);
            }
          };
          if (window.attachEvent) {
            window.attachEvent('onload', asyncLoad);
          } else {
            window.addEventListener('load', asyncLoad, false);
          }
        })();
      </script>
      <script id="__st">
        var __st = {
          "a": 71318765888,
          "offset": -18000,
          "reqid": "f0b51373-6c36-4fa1-9287-c09a4e6a251d",
          "pageurl": "covid19.puncakjayakab.go.id\/tentang\/rekomen-gacor\/",
          "u": "f65b77922871",
          "p": "product",
          "rtyp": "product",
          "rid": 8175435383104
        };
      </script>
      <script>
        window.ShopifyPaypalV4VisibilityTracking = true;
      </script>
      <script>
        ! function(o) {
          o.addEventListener("DOMContentLoaded", function() {
            window.Shopify = window.Shopify || {}, window.Shopify.recaptchaV3 = window.Shopify.recaptchaV3 || {
              siteKey: "6LcCR2cUAAAAANS1Gpq_mDIJ2pQuJphsSQaUEuc9"
            };
            var t = ['form[action*="/contact"] input[name="form_type"][value="contact"]', 'form[action*="/comments"] input[name="form_type"][value="new_comment"]', 'form[action*="/account"] input[name="form_type"][value="customer_login"]', 'form[action*="/account"] input[name="form_type"][value="recover_customer_password"]', 'form[action*="/account"] input[name="form_type"][value="create_customer"]', 'form[action*="/contact"] input[name="form_type"][value="customer"]'].join(",");
  
            function n(e) {
              e = e.target;
              null == e || null != (e = function e(t, n) {
                if (null == t.parentElement) return null;
                if ("FORM" != t.parentElement.tagName) return e(t.parentElement, n);
                for (var o = t.parentElement.action, r = 0; r < n.length; r++)
                  if (-1 !== o.indexOf(n[r])) return t.parentElement;
                return null
              }(e, ["/contact", "/comments", "/account"])) && null != e.querySelector(t) && ((e = o.createElement("script")).setAttribute("src", "https://cdn.shopify.com/shopifycloud/storefront-recaptcha-v3/v0.6/index.js"), o.body.appendChild(e), o.removeEventListener("focus", n, !0), o.removeEventListener("change", n, !0), o.removeEventListener("click", n, !0))
            }
            o.addEventListener("click", n, !0), o.addEventListener("change", n, !0), o.addEventListener("focus", n, !0)
          })
        }(document);
      </script>
      <script integrity="sha256-h4dvokWvGcvRSqiG7VnGqoonxF0k3NeoHPLSMjUGIz4=" data-source-attribution="shopify.loadfeatures" defer="defer" src="//www.maxjerky.com/cdn/shopifycloud/shopify/assets/storefront/load_feature-87876fa245af19cbd14aa886ed59c6aa8a27c45d24dcd7a81cf2d2323506233e.js" crossorigin="anonymous"></script>
      <script crossorigin="anonymous" defer="defer" src="//www.maxjerky.com/cdn/shopifycloud/shopify/assets/shopify_pay/storefront-a2d444786d996da5634fbbaeeffe6104ee672440dfa6cdcaebfb27dceaaf9c0f.js?v=20220906"></script>
      <script integrity="sha256-HAs5a9TQVLlKuuHrahvWuke+s1UlxXohfHeoYv8G2D8=" data-source-attribution="shopify.dynamic-checkout" defer="defer" src="//www.maxjerky.com/cdn/shopifycloud/shopify/assets/storefront/features-1c0b396bd4d054b94abae1eb6a1bd6ba47beb35525c57a217c77a862ff06d83f.js" crossorigin="anonymous"></script>
      <script id="sections-script" data-sections="header,footer" defer="defer" src="//www.maxjerky.com/cdn/shop/t/3/compiled_assets/scripts.js?3801"></script>
      <style id="shopify-dynamic-checkout-cart">
        @media screen and (min-width: 750px) {
          #dynamic-checkout-cart {
            min-height: 50px;
          }
        }
  
        @media screen and (max-width: 750px) {
          #dynamic-checkout-cart {
            min-height: 180px;
          }
        }
      </style>
      <script>
        window.performance && window.performance.mark && window.performance.mark('shopify.content_for_header.end');
      </script>
      <style data-shopify>
        @font-face {
          font-family: "Harmonia Sans";
          font-weight: 400;
          font-style: normal;
          font-display: swap;
          src: url("//www.maxjerky.com/cdn/fonts/harmonia_sans/harmoniasans_n4.73cf0589f7839ec88463a09f5335a2885467ed0c.woff2?h1=bWF4amVya3kuYWNjb3VudC5teXNob3BpZnkuY29t&h2=bWF4amVya3kuY29t&h3=aHlkcm9nZW4tbWF4amVya3ktNDI2ZDY1N2QzNDMzZjVkNDZmMDMubzIubXlzaG9waWZ5LmRldg&hmac=657bf22b7a92a8422d94ba48b8b11ff6498e7d6f2017cda2015c5a258c405339") format("woff2"),
            url("//www.maxjerky.com/cdn/fonts/harmonia_sans/harmoniasans_n4.1c5276ef69780b63aa8f0ba7897fb3bc87270bb0.woff?h1=bWF4amVya3kuYWNjb3VudC5teXNob3BpZnkuY29t&h2=bWF4amVya3kuY29t&h3=aHlkcm9nZW4tbWF4amVya3ktNDI2ZDY1N2QzNDMzZjVkNDZmMDMubzIubXlzaG9waWZ5LmRldg&hmac=0881d5254c272c7fa23771533e3d70faf8dce50f3cd9aadc5491a0e1159b5fec") format("woff");
        }
  
        @font-face {
          font-family: "Harmonia Sans";
          font-weight: 700;
          font-style: normal;
          font-display: swap;
          src: url("//www.maxjerky.com/cdn/fonts/harmonia_sans/harmoniasans_n7.db6a243cdeddb2eba0b2e8fccdce1e6910fd06d0.woff2?h1=bWF4amVya3kuYWNjb3VudC5teXNob3BpZnkuY29t&h2=bWF4amVya3kuY29t&h3=aHlkcm9nZW4tbWF4amVya3ktNDI2ZDY1N2QzNDMzZjVkNDZmMDMubzIubXlzaG9waWZ5LmRldg&hmac=442f4ba60f4e9d845f1901905e804dca8430a98c5511873e09d1918d408bf920") format("woff2"),
            url("//www.maxjerky.com/cdn/fonts/harmonia_sans/harmoniasans_n7.a069bd4d0320d5bc303f7f96d7bf28abc297b6aa.woff?h1=bWF4amVya3kuYWNjb3VudC5teXNob3BpZnkuY29t&h2=bWF4amVya3kuY29t&h3=aHlkcm9nZW4tbWF4amVya3ktNDI2ZDY1N2QzNDMzZjVkNDZmMDMubzIubXlzaG9waWZ5LmRldg&hmac=510939190da92caea0ea117969cea60ddfd540afb4de8ab39f1a760f2cd30314") format("woff");
        }
  
        @font-face {
          font-family: "Harmonia Sans";
          font-weight: 400;
          font-style: italic;
          font-display: swap;
          src: url("//www.maxjerky.com/cdn/fonts/harmonia_sans/harmoniasans_i4.ccbfea79fd847e76d49925a923aa89064359e629.woff2?h1=bWF4amVya3kuYWNjb3VudC5teXNob3BpZnkuY29t&h2=bWF4amVya3kuY29t&h3=aHlkcm9nZW4tbWF4amVya3ktNDI2ZDY1N2QzNDMzZjVkNDZmMDMubzIubXlzaG9waWZ5LmRldg&hmac=23ec9655d12b7ebf52d39004480b6a25e86d009492a57d719bd21a415ccddc91") format("woff2"),
            url("//www.maxjerky.com/cdn/fonts/harmonia_sans/harmoniasans_i4.e5c05a10aacfb8cc7fdf892df8dba937a214e6e7.woff?h1=bWF4amVya3kuYWNjb3VudC5teXNob3BpZnkuY29t&h2=bWF4amVya3kuY29t&h3=aHlkcm9nZW4tbWF4amVya3ktNDI2ZDY1N2QzNDMzZjVkNDZmMDMubzIubXlzaG9waWZ5LmRldg&hmac=1dcffd3e8e207bd39516954cd0106a149e6630206887b837e7457efc08eb85b4") format("woff");
        }
  
        @font-face {
          font-family: "Harmonia Sans";
          font-weight: 700;
          font-style: italic;
          font-display: swap;
          src: url("//www.maxjerky.com/cdn/fonts/harmonia_sans/harmoniasans_i7.4a7dd579ac7cb56f507f74a6af51c429211c3385.woff2?h1=bWF4amVya3kuYWNjb3VudC5teXNob3BpZnkuY29t&h2=bWF4amVya3kuY29t&h3=aHlkcm9nZW4tbWF4amVya3ktNDI2ZDY1N2QzNDMzZjVkNDZmMDMubzIubXlzaG9waWZ5LmRldg&hmac=2b4b8e058991d7919fe3329729949d997cb127be9d82f61a85f961de13963d2f") format("woff2"),
            url("//www.maxjerky.com/cdn/fonts/harmonia_sans/harmoniasans_i7.f513289b781582823a912d2e8125b8c109e5d61c.woff?h1=bWF4amVya3kuYWNjb3VudC5teXNob3BpZnkuY29t&h2=bWF4amVya3kuY29t&h3=aHlkcm9nZW4tbWF4amVya3ktNDI2ZDY1N2QzNDMzZjVkNDZmMDMubzIubXlzaG9waWZ5LmRldg&hmac=63b2eff6c9aa35f69cf798b3eff4de34e90e0f053712ac9a08795057a622093e") format("woff");
        }
  
        @font-face {
          font-family: "Harmonia Sans";
          font-weight: 600;
          font-style: normal;
          font-display: swap;
          src: url("//www.maxjerky.com/cdn/fonts/harmonia_sans/harmoniasans_n6.dd3d6084d29e4754e80fe6aa1c0e37f511474ffa.woff2?h1=bWF4amVya3kuYWNjb3VudC5teXNob3BpZnkuY29t&h2=bWF4amVya3kuY29t&h3=aHlkcm9nZW4tbWF4amVya3ktNDI2ZDY1N2QzNDMzZjVkNDZmMDMubzIubXlzaG9waWZ5LmRldg&hmac=752e01be04849093ca20192ad29aaae993855b5149f5feb4f18481d11c044743") format("woff2"),
            url("//www.maxjerky.com/cdn/fonts/harmonia_sans/harmoniasans_n6.b0d6879084373b473d0c7a4c3d54ece9c289cbb4.woff?h1=bWF4amVya3kuYWNjb3VudC5teXNob3BpZnkuY29t&h2=bWF4amVya3kuY29t&h3=aHlkcm9nZW4tbWF4amVya3ktNDI2ZDY1N2QzNDMzZjVkNDZmMDMubzIubXlzaG9waWZ5LmRldg&hmac=0c6a499e5107a09c0712d5370cbb58d07f1b06f4cf2140a684630da8602126ac") format("woff");
        }
  
        :root {
          --font-body-family: "Harmonia Sans", sans-serif;
          --font-body-style: normal;
          --font-body-weight: 400;
          --font-body-weight-bold: 700;
          --font-heading-family: "Harmonia Sans", sans-serif;
          --font-heading-style: normal;
          --font-heading-weight: 600;
          --font-body-scale: 1.0;
          --font-heading-scale: 1.3;
          --color-base-text: 46, 42, 57;
          --color-shadow: 46, 42, 57;
          --color-base-background-1: 244, 129, 32;
          --color-base-background-2: 237, 255, 167;
          --color-base-solid-button-labels: 253, 251, 247;
          --color-base-outline-button-labels: 46, 42, 57;
          --color-base-accent-1: 0, 0, 0;
          --color-base-accent-2: 220, 76, 62;
          --payment-terms-background-color: #ff0000;
          --gradient-base-background-1: linear-gradient(180deg, rgba(240, 244, 236, 1), rgba(241, 235, 226, 1) 100%);
          --gradient-base-background-2: radial-gradient(rgba(255, 229, 229, 1), rgba(255, 224, 218, 1) 25%, rgba(215, 255, 137, 1) 100%);
          --gradient-base-accent-1: #000000;
          --gradient-base-accent-2: radial-gradient(rgba(102, 51, 153, 1), rgba(102, 51, 153, 1) 100%);
          --media-padding: px;
          --media-border-opacity: 0.1;
          --media-border-width: 0px;
          --media-radius: 12px;
          --media-shadow-opacity: 0.1;
          --media-shadow-horizontal-offset: 10px;
          --media-shadow-vertical-offset: 12px;
          --media-shadow-blur-radius: 20px;
          --media-shadow-visible: 1;
          --page-width: 120rem;
          --page-width-margin: 0rem;
          --product-card-image-padding: 0.0rem;
          --product-card-corner-radius: 1.2rem;
          --product-card-text-alignment: center;
          --product-card-border-width: 0.0rem;
          --product-card-border-opacity: 0.1;
          --product-card-shadow-opacity: 0.05;
          --product-card-shadow-visible: 1;
          --product-card-shadow-horizontal-offset: 1.0rem;
          --product-card-shadow-vertical-offset: 1.0rem;
          --product-card-shadow-blur-radius: 3.5rem;
          --collection-card-image-padding: 0.0rem;
          --collection-card-corner-radius: 1.2rem;
          --collection-card-text-alignment: center;
          --collection-card-border-width: 0.0rem;
          --collection-card-border-opacity: 0.1;
          --collection-card-shadow-opacity: 0.05;
          --collection-card-shadow-visible: 1;
          --collection-card-shadow-horizontal-offset: 1.0rem;
          --collection-card-shadow-vertical-offset: 1.0rem;
          --collection-card-shadow-blur-radius: 3.5rem;
          --blog-card-image-padding: 0.0rem;
          --blog-card-corner-radius: 1.2rem;
          --blog-card-text-alignment: center;
          --blog-card-border-width: 0.0rem;
          --blog-card-border-opacity: 0.1;
          --blog-card-shadow-opacity: 0.05;
          --blog-card-shadow-visible: 1;
          --blog-card-shadow-horizontal-offset: 1.0rem;
          --blog-card-shadow-vertical-offset: 1.0rem;
          --blog-card-shadow-blur-radius: 3.5rem;
          --badge-corner-radius: 2.0rem;
          --popup-border-width: 1px;
          --popup-border-opacity: 0.1;
          --popup-corner-radius: 22px;
          --popup-shadow-opacity: 0.1;
          --popup-shadow-horizontal-offset: 10px;
          --popup-shadow-vertical-offset: 12px;
          --popup-shadow-blur-radius: 20px;
          --drawer-border-width: 1px;
          --drawer-border-opacity: 0.1;
          --drawer-shadow-opacity: 0.0;
          --drawer-shadow-horizontal-offset: 0px;
          --drawer-shadow-vertical-offset: 4px;
          --drawer-shadow-blur-radius: 5px;
          --spacing-sections-desktop: 36px;
          --spacing-sections-mobile: 25px;
          --grid-desktop-vertical-spacing: 40px;
          --grid-desktop-horizontal-spacing: 40px;
          --grid-mobile-vertical-spacing: 20px;
          --grid-mobile-horizontal-spacing: 20px;
          --text-boxes-border-opacity: 0.1;
          --text-boxes-border-width: 0px;
          --text-boxes-radius: 24px;
          --text-boxes-shadow-opacity: 0.0;
          --text-boxes-shadow-visible: 0;
          --text-boxes-shadow-horizontal-offset: 10px;
          --text-boxes-shadow-vertical-offset: 12px;
          --text-boxes-shadow-blur-radius: 20px;
          --buttons-radius: 10px;
          --buttons-radius-outset: 11px;
          --buttons-border-width: 1px;
          --buttons-border-opacity: 0.55;
          --buttons-shadow-opacity: 0.0;
          --buttons-shadow-visible: 0;
          --buttons-shadow-horizontal-offset: 0px;
          --buttons-shadow-vertical-offset: 4px;
          --buttons-shadow-blur-radius: 5px;
          --buttons-border-offset: 0.3px;
          --inputs-radius: 10px;
          --inputs-border-width: 1px;
          --inputs-border-opacity: 0.55;
          --inputs-shadow-opacity: 0.0;
          --inputs-shadow-horizontal-offset: 0px;
          --inputs-margin-offset: 0px;
          --inputs-shadow-vertical-offset: 4px;
          --inputs-shadow-blur-radius: 5px;
          --inputs-radius-outset: 11px;
          --variant-pills-radius: 10px;
          --variant-pills-border-width: 0px;
          --variant-pills-border-opacity: 0.1;
          --variant-pills-shadow-opacity: 0.0;
          --variant-pills-shadow-horizontal-offset: 0px;
          --variant-pills-shadow-vertical-offset: 4px;
          --variant-pills-shadow-blur-radius: 5px;
        }
  
        *,
        *::before,
        *::after {
          box-sizing: inherit;
        }
  
        @font-face {
          font-family: "LexendDeca-Black";
          src: url('https://cdn.shopify.com/s/files/1/0713/1876/5888/files/LexendDeca-Black.woff2?v=1678705047') format("WOFF2");
        }
  
        @font-face {
          font-family: "Workfolk-Extended";
          src: url('https://cdn.shopify.com/s/files/1/0713/1876/5888/files/Workfolk-Extended.woff2?v=1680249909') format("WOFF2");
        }
  
        @font-face {
          font-family: "Workfolk-Condensed";
          src: url('https://cdn.shopify.com/s/files/1/0713/1876/5888/files/Workfolk-Condensed.woff2?v=1680251727') format("WOFF2");
        }
  
        @font-face {
          font-family: "Workfolk";
          src: url('https://cdn.shopify.com/s/files/1/0713/1876/5888/files/Workfolk.woff2?v=1680252387') format("WOFF2");
        }
  
        @font-face {
          font-family: "LexendDeca-Regular";
          src: url('https://cdn.shopify.com/s/files/1/0713/1876/5888/files/LexendDeca-Regular.woff2?v=1680252816') format("WOFF2");
        }
  
        @font-face {
          font-family: "LexendDeca-Bold";
          src: url('https://cdn.shopify.com/s/files/1/0713/1876/5888/files/LexendDeca-Bold.woff2?v=1680255349') format("WOFF2");
        }
  
        @font-face {
          font-family: "LexendDeca-Light";
          src: url('https://cdn.shopify.com/s/files/1/0713/1876/5888/files/LexendDeca-Light.ttf?v=1680255755') format("WOFF2");
        }
  
        @font-face {
          font-family: "LexendDeca-SemiBold";
          src: url('https://cdn.shopify.com/s/files/1/0713/1876/5888/files/LexendDeca-SemiBold.woff2?v=1680255904') format("WOFF2");
        }
  
        html {
          box-sizing: border-box;
          font-size: calc(var(--font-body-scale) * 62.5%);
          height: 100%;
        }
  
        body {
          display: grid;
          grid-template-rows: auto auto 1fr auto;
          grid-template-columns: 100%;
          min-height: 100%;
          margin: 0;
          font-size: 1.5rem;
          letter-spacing: 0.06rem;
          line-height: calc(1 + 0.8 / var(--font-body-scale));
          font-family: 'LexendDeca-Black';
          /*         font-family: var(--font-body-family); */
          font-style: var(--font-body-style);
          font-weight: var(--font-body-weight);
        }
  
        @media screen and (min-width: 750px) {
          body {
            font-size: 1.6rem;
          }
        }
  
        #MainContent {
          background: black;
        }
  
        #shopify-section-template--18511645671744__image-with-text {
          background-image: url(https://cdn.shopify.com/s/files/1/0713/1876/5888/files/tiled-jerky.jpg?v=1683092291);
          background-repeat: no-repeat;
          background-position: center;
          background-size: cover;
        }
  
        #MainContent>.shopify-section>cart-items {
          background: black;
        }
  
        #MainContent>#shopify-section-template--18161589125440__image-with-text {
          background-image: url(https://cdn.shopify.com/s/files/1/0713/1876/5888/files/tiled-jerky.jpg?v=1683092291);
          background-repeat: no-repeat;
          background-position: center;
          background-size: cover;
        }
  
        #shopify-section-template--18534878314816__b52ec4b0-421a-487a-9742-d38c45d7abae {
          margin-top: 0 !important;
        }
  
        /* custom liquid- who is max */
        #shopify-section-template--18511645671744__fa5ade39-eb76-4ec2-a73e-a82acd2301cb {
          margin-top: 0 !important;
        }
  
        /* instagram container */
        #shopify-section-template--18511645671744__2697889c-4130-46ba-b303-c5e1cc1fd25d {
          background: #E8781D;
          margin-top: 0 !important;
        }
  
        @media screen and (min-width: 968px) {
          .rc-radio-group__options {
            display: flex;
            /* position: absolute; */
            /* top: 350px; */
          }
  
          .rc-subscription-details {
            /* position: absolute !important; */
            /* top: 475px; */
          }
  
          .ComboSlide_picky-combo-slide-content_1e7bJ {
            display: flex !important;
            flex-direction: row !important;
          }
        }
  
        @media screen and (max-width: 967px) {
          .ComboSlide_picky-combo-slide-content_1e7bJ {
            flex-direction: column !important;
            align-items: center !important;
          }
  
          .rc-radio-group__options {
            display: flex;
            /* position: absolute; */
            /* top: 630px; */
            flex-direction: column;
          }
  
          .rc-subscription-details {
            /* position: absolute !important; */
            /* top: 726px; */
          }
        }
  
        .QuantityInput_input_3ByxW {
          min-width: 30px !important;
        }
  
        .rc-radio__label {
          display: inline-block !important;
        }
  
        .rc-radio {
          max-width: 340px;
        }
  
        .rc-widget {
          font-family: LexendDeca-Regular;
          margin: auto;
          width: fit-content;
        }
  
        .onetime-radio {
          margin-right: 30px !important;
          border-radius: 40px;
          background: #222323;
        }
  
        .rc-radio--active {
          border: 2px solid #9363A8 !important;
        }
  
        .rc-radio-group__options {
          border: none !important;
        }
  
        .subscription-radio {
          background: #222323;
          border-radius: 40px;
          border-top: none;
        }
  
        .rc-radio__label {
          line-height: 1 !important;
        }
  
        .rc-radio {
          padding-top: 0;
          padding-bottom: 0
        }
  
        input[type='radio']:checked:after {
          width: 16px;
          height: 16px;
          border-radius: 15px;
          top: 0px;
          left: 2px;
          position: relative;
          background-color: #9363A8;
          content: '';
          display: inline-block;
          visibility: visible;
          border: 3px solid white;
        }
  
        .QuantityInput_picky-product-quantity-input_3ZQjb {
          border-radius: 20px !important;
          border: 2px solid white !important;
        }
  
        .ComboSlide_quantity-wrap_3Tgdz {
          margin: 0 !important;
        }
  
        .AddSelectedToCart_button_1h33d {
          background: white !important;
          max-height: 50px !important;
          border-radius: 10px !important;
          width: 350px !important;
          margin-bottom: 0 !important;
          z-index: 2 !important;
          position: relative !important;
          font-family: 'LexendDeca-Bold' !important;
          font-size: 12px !important;
          color: black !important;
        }
  
        .section-template--18864594649408__main-padding,
        .section-template--18864592290112__main-padding,
        .section-template--19843705307456__main-padding,
        .shopify-section-template--19353714491712__main,
        .section-template--19353714491712__main-padding {
          margin: 0 !important;
          max-width: 100vw !important;
        }
  
        #shopify-section-template--18511644262720__8d697b10-c132-4ed0-bc30-b4fbaf8e86e6 {
          margin-top: 150px;
        }
  
        #checkout {
          border: 2px solid white;
        }
  
        /* custom combo css */
        .GridLayout_picky-horizontal-product-card-orientation_11_vB {
          grid-template-columns: 1fr 1fr;
        }
  
        .picky-product-image-box.tns-item,
        .RecommendedProductCard_picky-cart-checkbox-wrap_lFAhV.RecommendedProductCard_clickable_1TnMf,
        .RecommendedProductCard_carousel-wrap_9_I5y {
          display: none !important;
        }
  
        .picky-add-selected-to-cart-button.AddSelectedToCart_button_1h33d {
          margin: auto;
        }
  
        .AddSelectedToCart_add-selected-to-cart_2Wl7M.BundleSlide_picky-bundle-add-selected-wrap_3vc-F {
          padding: 0;
        }
  
        .picky-product-card-container.GridLayout_picky-horizontal-product-card-orientation_11_vB {
          display: none;
        }
  
        .RecommendedProductCard_fixed-height_3Ux1q.RecommendedProductCard_horizontal-picky-product-card-orientation_24WKW.RecommendedProductCard_replace-product-form-widget_3SJiG {
          align-items: center;
          justify-content: center;
          display: flex;
        }
  
        .RecommendedProductCard_product-options_IhS3I {
          justify-content: center;
          display: flex;
          flex-direction: column;
          align-items: center;
        }
  
        .RecommendedProductCard_picky-quantity-container_nUTVu {
          max-width: fit-content;
        }
  
        .RecommendedProductCard_picky-product-options-container_BhxH7.RecommendedProductCard_fixed-height_3Ux1q {
          justify-content: center;
        }
  
        .RecommendedProductCard_picky-options-ttl_3akmV {
          text-align: center !important;
        }
  
        .ProductCardInfoMessage_message_3Dpa- {
          max-width: fit-content;
        }
  
        .picky-compare-at-price.picky-compare-at-price_is-new {
          color: white !important;
        }
  
        /* only for develpoment */
        .section-template--19325805429056__main-padding {
          max-width: 100vw !important;
        }
      </style><link href="//www.maxjerky.com/cdn/shop/t/3/assets/base.css?v=176612488300343602291682653455" rel="stylesheet" type="text/css" media="all" />
      <link rel="preload" as="font" href="//www.maxjerky.com/cdn/fonts/harmonia_sans/harmoniasans_n4.73cf0589f7839ec88463a09f5335a2885467ed0c.woff2?h1=bWF4amVya3kuYWNjb3VudC5teXNob3BpZnkuY29t&h2=bWF4amVya3kuY29t&h3=aHlkcm9nZW4tbWF4amVya3ktNDI2ZDY1N2QzNDMzZjVkNDZmMDMubzIubXlzaG9waWZ5LmRldg&hmac=657bf22b7a92a8422d94ba48b8b11ff6498e7d6f2017cda2015c5a258c405339" type="font/woff2" crossorigin>
      <link rel="preload" as="font" href="//www.maxjerky.com/cdn/fonts/harmonia_sans/harmoniasans_n6.dd3d6084d29e4754e80fe6aa1c0e37f511474ffa.woff2?h1=bWF4amVya3kuYWNjb3VudC5teXNob3BpZnkuY29t&h2=bWF4amVya3kuY29t&h3=aHlkcm9nZW4tbWF4amVya3ktNDI2ZDY1N2QzNDMzZjVkNDZmMDMubzIubXlzaG9waWZ5LmRldg&hmac=752e01be04849093ca20192ad29aaae993855b5149f5feb4f18481d11c044743" type="font/woff2" crossorigin>
      <link rel="stylesheet" href="//www.maxjerky.com/cdn/shop/t/3/assets/component-predictive-search.css?v=85913294783299393391680102127" media="print" onload="this.media='all'">
      <script>
        document.documentElement.className = document.documentElement.className.replace('no-js', 'js');
        if (Shopify.designMode) {
          document.documentElement.classList.add('shopify-design-mode');
        }
      </script>
      <!-- BEGIN app block: shopify://apps/judge-me-product-reviews/blocks/judgeme_core/61ccd3b1-a9f2-4160-9fe9-4fec8413e5d8 -->
      <!-- Start of Judge.me Core -->
      <link rel="dns-prefetch" href="https://cdn.judge.me">
      <script data-cfasync='false' class='jdgm-settings-script'>
        window.jdgmSettings = {
          "pagination": 5,
          "disable_web_reviews": false,
          "badge_no_review_text": "No reviews",
          "badge_n_reviews_text": "{{ n }} review/reviews",
          "hide_badge_preview_if_no_reviews": true,
          "badge_hide_text": false,
          "enforce_center_preview_badge": false,
          "widget_title": "Customer Reviews",
          "widget_open_form_text": "Write a review",
          "widget_close_form_text": "Cancel review",
          "widget_refresh_page_text": "Refresh page",
          "widget_summary_text": "Based on {{ number_of_reviews }} review/reviews",
          "widget_no_review_text": "Be the first to write a review",
          "widget_name_field_text": "Name",
          "widget_verified_name_field_text": "Verified Name (public)",
          "widget_name_placeholder_text": "Enter your name (public)",
          "widget_required_field_error_text": "This field is required.",
          "widget_email_field_text": "Email",
          "widget_verified_email_field_text": "Verified Email (private, can not be edited)",
          "widget_email_placeholder_text": "Enter your email (private)",
          "widget_email_field_error_text": "Please enter a valid email address.",
          "widget_rating_field_text": "Rating",
          "widget_review_title_field_text": "Review Title",
          "widget_review_title_placeholder_text": "Give your review a title",
          "widget_review_body_field_text": "Review",
          "widget_review_body_placeholder_text": "Write your comments here",
          "widget_pictures_field_text": "Picture/Video (optional)",
          "widget_submit_review_text": "Submit Review",
          "widget_submit_verified_review_text": "Submit Verified Review",
          "widget_submit_success_msg_with_auto_publish": "Thank you! Please refresh the page in a few moments to see your review. You can remove or edit your review by logging into \u003ca href='https://judge.me/login' target='_blank' rel='nofollow noopener'\u003eJudge.me\u003c/a\u003e",
          "widget_submit_success_msg_no_auto_publish": "Thank you! Your review will be published as soon as it is approved by the shop admin. You can remove or edit your review by logging into \u003ca href='https://judge.me/login' target='_blank' rel='nofollow noopener'\u003eJudge.me\u003c/a\u003e",
          "widget_show_default_reviews_out_of_total_text": "Showing {{ n_reviews_shown }} out of {{ n_reviews }} reviews.",
          "widget_show_all_link_text": "Show all",
          "widget_show_less_link_text": "Show less",
          "widget_author_said_text": "{{ reviewer_name }} said:",
          "widget_days_text": "{{ n }} days ago",
          "widget_weeks_text": "{{ n }} week/weeks ago",
          "widget_months_text": "{{ n }} month/months ago",
          "widget_years_text": "{{ n }} year/years ago",
          "widget_yesterday_text": "Yesterday",
          "widget_today_text": "Today",
          "widget_replied_text": "\u003e\u003e {{ shop_name }} replied:",
          "widget_read_more_text": "Read more",
          "widget_rating_filter_see_all_text": "See all reviews",
          "widget_sorting_most_recent_text": "Most Recent",
          "widget_sorting_highest_rating_text": "Highest Rating",
          "widget_sorting_lowest_rating_text": "Lowest Rating",
          "widget_sorting_with_pictures_text": "Only Pictures",
          "widget_sorting_most_helpful_text": "Most Helpful",
          "widget_open_question_form_text": "Ask a question",
          "widget_reviews_subtab_text": "Reviews",
          "widget_questions_subtab_text": "Questions",
          "widget_question_label_text": "Question",
          "widget_answer_label_text": "Answer",
          "widget_question_placeholder_text": "Write your question here",
          "widget_submit_question_text": "Submit Question",
          "widget_question_submit_success_text": "Thank you for your question! We will notify you once it gets answered.",
          "verified_badge_text": "Verified",
          "verified_badge_placement": "left-of-reviewer-name",
          "widget_hide_border": false,
          "widget_social_share": false,
          "widget_thumb": false,
          "widget_review_location_show": false,
          "widget_location_format": "country_iso_code",
          "all_reviews_include_out_of_store_products": true,
          "all_reviews_out_of_store_text": "(out of store)",
          "all_reviews_product_name_prefix_text": "about",
          "enable_review_pictures": true,
          "enable_question_anwser": false,
          "widget_product_reviews_subtab_text": "Product Reviews",
          "widget_shop_reviews_subtab_text": "Shop Reviews",
          "widget_sorting_pictures_first_text": "Pictures First",
          "floating_tab_button_name": "★ Judge.me Reviews",
          "floating_tab_title": "Let customers speak for us",
          "floating_tab_url": "",
          "floating_tab_url_enabled": false,
          "all_reviews_text_badge_text": "Customers rate us {{ shop.metafields.judgeme.all_reviews_rating | round: 1 }}/5 based on {{ shop.metafields.judgeme.all_reviews_count }} reviews.",
          "all_reviews_text_badge_text_branded_style": "{{ shop.metafields.judgeme.all_reviews_rating | round: 1 }} out of 5 stars based on {{ shop.metafields.judgeme.all_reviews_count }} reviews",
          "all_reviews_text_badge_url": "",
          "featured_carousel_title": "Love from All Over",
          "featured_carousel_count_text": "from {{ n }} reviews",
          "featured_carousel_url": "",
          "featured_carousel_show_images": false,
          "featured_carousel_width": 100,
          "verified_count_badge_url": "",
          "picture_reminder_submit_button": "Upload Pictures",
          "widget_sorting_videos_first_text": "Videos First",
          "widget_review_pending_text": "Pending",
          "remove_microdata_snippet": true,
          "preview_badge_no_question_text": "No questions",
          "preview_badge_n_question_text": "{{ number_of_questions }} question/questions",
          "widget_search_bar_placeholder": "Search reviews",
          "widget_sorting_verified_only_text": "Verified only",
          "all_reviews_page_load_more_text": "Load More Reviews",
          "widget_advanced_speed_features": 5,
          "widget_public_name_text": "displayed publicly like",
          "default_reviewer_name_has_non_latin": true,
          "widget_reviewer_anonymous": "Anonymous",
          "medals_widget_title": "Judge.me Review Medals",
          "widget_invalid_yt_video_url_error_text": "Not a YouTube video URL",
          "widget_max_length_field_error_text": "Please enter no more than {0} characters.",
          "widget_verified_by_shop_text": "Verified by Shop",
          "widget_load_with_code_splitting": true,
          "widget_ugc_title": "Made by us, Shared by you",
          "widget_ugc_subtitle": "Tag us to see your picture featured in our page",
          "widget_ugc_primary_button_text": "Buy Now",
          "widget_ugc_secondary_button_text": "Load More",
          "widget_ugc_reviews_button_text": "View Reviews",
          "widget_summary_average_rating_text": "{{ average_rating }} out of 5",
          "widget_media_grid_title": "Customer photos \u0026 videos",
          "widget_media_grid_see_more_text": "See more",
          "widget_verified_by_judgeme_text": "Verified by Judge.me",
          "widget_verified_by_judgeme_text_in_store_medals": "Verified by Judge.me",
          "widget_media_field_exceed_quantity_message": "Sorry, we can only accept {{ max_media }} for one review.",
          "widget_media_field_exceed_limit_message": "{{ file_name }} is too large, please select a {{ media_type }} less than {{ size_limit }}MB.",
          "widget_review_submitted_text": "Review Submitted!",
          "widget_question_submitted_text": "Question Submitted!",
          "widget_close_form_text_question": "Cancel",
          "widget_write_your_answer_here_text": "Write your answer here",
          "widget_show_collected_by_judgeme": false,
          "widget_collected_by_judgeme_text": "collected by Judge.me",
          "widget_load_more_text": "Load More",
          "widget_full_review_text": "Full Review",
          "widget_read_more_reviews_text": "Read More Reviews",
          "widget_read_questions_text": "Read Questions",
          "widget_questions_and_answers_text": "Questions \u0026 Answers",
          "widget_verified_by_text": "Verified by",
          "widget_number_of_reviews_text": "{{ number_of_reviews }} reviews",
          "widget_back_button_text": "Back",
          "widget_next_button_text": "Next",
          "widget_custom_forms_filter_button": "Filters",
          "custom_forms_style": "vertical",
          "how_reviews_are_collected": "How reviews are collected?",
          "platform": "shopify",
          "branding_url": "https://judge.me/reviews",
          "branding_text": "Powered by Judge.me",
          "locale": "en",
          "reply_name": "<?php echo $name; ?>",
          "widget_version": "3.0",
          "footer": true,
          "autopublish": false,
          "review_dates": true,
          "enable_custom_form": false,
          "shop_use_review_site": false,
          "can_be_branded": true
        };
      </script>
      <style class='jdgm-settings-style'>
        .jdgm-xx {
          left: 0
        }
  
        :root {
          --jdgm-primary-color: #399;
          --jdgm-secondary-color: rgba(51, 153, 153, 0.1);
          --jdgm-star-color: #399;
          --jdgm-paginate-color: #399;
          --jdgm-border-radius: 0
        }
  
        .jdgm-histogram__bar-content {
          background-color: #399
        }
  
        .jdgm-rev[data-verified-buyer=true] .jdgm-rev__icon.jdgm-rev__icon:after,
        .jdgm-rev__buyer-badge.jdgm-rev__buyer-badge {
          color: white;
          background-color: #399
        }
  
        .jdgm-review-widget--small .jdgm-gallery.jdgm-gallery .jdgm-gallery__thumbnail-link:nth-child(8) .jdgm-gallery__thumbnail-wrapper.jdgm-gallery__thumbnail-wrapper:before {
          content: "See more"
        }
  
        @media only screen and (min-width: 768px) {
          .jdgm-gallery.jdgm-gallery .jdgm-gallery__thumbnail-link:nth-child(8) .jdgm-gallery__thumbnail-wrapper.jdgm-gallery__thumbnail-wrapper:before {
            content: "See more"
          }
        }
  
        .jdgm-prev-badge[data-average-rating='0.00'] {
          display: none !important
        }
  
        .jdgm-author-all-initials {
          display: none !important
        }
  
        .jdgm-author-last-initial {
          display: none !important
        }
  
        .jdgm-rev-widg__title {
          visibility: hidden
        }
  
        .jdgm-rev-widg__summary-text {
          visibility: hidden
        }
  
        .jdgm-prev-badge__text {
          visibility: hidden
        }
  
        .jdgm-rev__replier:before {
          content: 'maxjerky.com'
        }
  
        .jdgm-rev__prod-link-prefix:before {
          content: 'about'
        }
  
        .jdgm-rev__out-of-store-text:before {
          content: '(out of store)'
        }
  
        @media only screen and (min-width: 768px) {
  
          .jdgm-rev__pics .jdgm-rev_all-rev-page-picture-separator,
          .jdgm-rev__pics .jdgm-rev__product-picture {
            display: none
          }
        }
  
        @media only screen and (max-width: 768px) {
  
          .jdgm-rev__pics .jdgm-rev_all-rev-page-picture-separator,
          .jdgm-rev__pics .jdgm-rev__product-picture {
            display: none
          }
        }
  
        .jdgm-preview-badge[data-template="product"] {
          display: none !important
        }
  
        .jdgm-preview-badge[data-template="collection"] {
          display: none !important
        }
  
        .jdgm-preview-badge[data-template="index"] {
          display: none !important
        }
  
        .jdgm-review-widget[data-from-snippet="true"] {
          display: none !important
        }
  
        .jdgm-verified-count-badget[data-from-snippet="true"] {
          display: none !important
        }
  
        .jdgm-carousel-wrapper[data-from-snippet="true"] {
          display: none !important
        }
  
        .jdgm-all-reviews-text[data-from-snippet="true"] {
          display: none !important
        }
  
        .jdgm-medals-section[data-from-snippet="true"] {
          display: none !important
        }
  
        .jdgm-ugc-media-wrapper[data-from-snippet="true"] {
          display: none !important
        }
      </style>
      <style class='jdgm-miracle-styles'>
        @-webkit-keyframes jdgm-spin {
          0% {
            -webkit-transform: rotate(0deg);
            -ms-transform: rotate(0deg);
            transform: rotate(0deg)
          }
  
          100% {
            -webkit-transform: rotate(359deg);
            -ms-transform: rotate(359deg);
            transform: rotate(359deg)
          }
        }
  
        @keyframes jdgm-spin {
          0% {
            -webkit-transform: rotate(0deg);
            -ms-transform: rotate(0deg);
            transform: rotate(0deg)
          }
  
          100% {
            -webkit-transform: rotate(359deg);
            -ms-transform: rotate(359deg);
            transform: rotate(359deg)
          }
        }
  
        @font-face {
          font-family: 'JudgemeStar';
          src: url("data:application/x-font-woff;charset=utf-8;base64,d09GRgABAAAAAAScAA0AAAAABrAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABGRlRNAAAEgAAAABoAAAAcbyQ+3kdERUYAAARgAAAAHgAAACAAMwAGT1MvMgAAAZgAAABGAAAAVi+vS9xjbWFwAAAB8AAAAEAAAAFKwBMjvmdhc3AAAARYAAAACAAAAAj//wADZ2x5ZgAAAkAAAAEJAAABdH33LXtoZWFkAAABMAAAAC0AAAA2BroQKWhoZWEAAAFgAAAAHAAAACQD5QHQaG10eAAAAeAAAAAPAAAAFAYAAABsb2NhAAACMAAAAA4AAAAOAO4AeG1heHAAAAF8AAAAHAAAACAASgAvbmFtZQAAA0wAAADeAAABkorWfVZwb3N0AAAELAAAACkAAABEp3ubLXgBY2BkYADhPPP4OfH8Nl8ZuJkYQODS2fRrCPr/aSYGxq1ALgcDWBoAO60LkwAAAHgBY2BkYGDc+v80gx4TAwgASaAICmABAFB+Arl4AWNgZGBgYGPQYWBiAAIwyQgWc2AAAwAHVQB6eAFjYGRiYJzAwMrAwejDmMbAwOAOpb8ySDK0MDAwMbByMsCBAAMCBKS5pjA4PGB4wMR44P8BBj3GrQymQGFGkBwAjtgK/gAAeAFjYoAAEA1jAwAAZAAHAHgB3crBCcAwDEPRZydkih567CDdf4ZskmLwFBV8xBfCaC4BXkOUmx4sU0h2ngNb9V0vQCxaRKIAevT7fGWuBrEAAAAAAAAAAAA0AHgAugAAeAF9z79Kw1AUx/FzTm7un6QmJtwmQ5Bg1abgEGr/BAqlU6Gju+Cgg1MkQ/sA7Vj7BOnmO/gUvo2Lo14NqIO6/IazfD8HEODtmQCfoANwNsyp2/GJt3WKQrd1NLiYYWx2PBqOsmJMEOznPOTzfSCrhAtbbLdmeFLJV9eKd63WLrZcIcuaEVdssWCKM6pLCfTVOYbz/0pNSMSZKLIZpvh78sAUH6PlMrreTCabP9r+Z/puPZ2ur/RqpQHgh+MIegCnXeM4MRAPjYN//5tj4ZtTjkFqEdmeMShlEJ7tVAly2TAkx6R68Fl4E/aVvn8JqHFQ4JS1434gXKcuL31dDhzs3YbsEOAd/IU88gAAAHgBfY4xTgMxEEVfkk0AgRCioKFxQYd2ZRtpixxgRU2RfhU5q5VWseQ4JdfgAJyBlmNwAM7ABRhZQ0ORwp7nr+eZAa54YwYg9zm3ynPOeFRe8MCrciXOh/KSS76UV5L/iDmrLiS5AeU519wrL3jmSbkS5115yR2fyivJv9kx0ZMZ2RLZw27q87iNQi8EBo5FSPIMw3HqBboi5lKTGAGDp8FKXWP+t9TU01Lj5His1Ba6uM9dTEMwvrFmbf5GC/q2drW3ruXUhhsCiQOjznFlCzYhHUZp4xp76vsvQh89CQAAeAFjYGJABowM6IANLMrEyMTIzMjCXpyRWJBqZshWXJJYBKOMAFHFBucAAAAAAAAB//8AAngBY2BkYGDgA2IJBhBgAvKZGViBJAuYxwAABJsAOgAAeAFjYGBgZACCk535hiD60tn0azAaAEqpB6wAAA==") format("woff");
          font-weight: normal;
          font-style: normal
        }
  
        .jdgm-star {
          font-family: 'JudgemeStar';
          display: inline !important;
          text-decoration: none !important;
          padding: 0 4px 0 0 !important;
          margin: 0 !important;
          font-weight: bold;
          opacity: 1;
          -webkit-font-smoothing: antialiased;
          -moz-osx-font-smoothing: grayscale
        }
  
        .jdgm-star:hover {
          opacity: 1
        }
  
        .jdgm-star:last-of-type {
          padding: 0 !important
        }
  
        .jdgm-star.jdgm--on:before {
          content: "\e000"
        }
  
        .jdgm-star.jdgm--off:before {
          content: "\e001"
        }
  
        .jdgm-star.jdgm--half:before {
          content: "\e002"
        }
  
        .jdgm-widget * {
          margin: 0;
          line-height: 1.4;
          -webkit-box-sizing: border-box;
          -moz-box-sizing: border-box;
          box-sizing: border-box;
          -webkit-overflow-scrolling: touch
        }.jdgm-hidden {
          display: none !important;
          visibility: hidden !important
        }
  
        .jdgm-temp-hidden {
          display: none
        }
  
        .jdgm-spinner {
          width: 40px;
          height: 40px;
          margin: auto;
          border-radius: 50%;
          border-top: 2px solid #eee;
          border-right: 2px solid #eee;
          border-bottom: 2px solid #eee;
          border-left: 2px solid #ccc;
          -webkit-animation: jdgm-spin 0.8s infinite linear;
          animation: jdgm-spin 0.8s infinite linear
        }
  
        .jdgm-prev-badge {
          display: block !important
        }
      </style>
      <script data-cfasync='false' class='jdgm-script'>
        ! function(e) {
          window.jdgm = window.jdgm || {}, jdgm.CDN_HOST = "https://cdn.judge.me/",
            jdgm.docReady = function(d) {
              (e.attachEvent ? "complete" === e.readyState : "loading" !== e.readyState) ? setTimeout(d, 0): e.addEventListener("DOMContentLoaded", d)
            }, jdgm.loadCSS = function(d, t, o, a) {
              !o && jdgm.loadCSS.requestedUrls.indexOf(d) >= 0 || (jdgm.loadCSS.requestedUrls.push(d),
                (a = e.createElement("link")).rel = "stylesheet", a.class = "jdgm-stylesheet", a.media = "nope!", a.href = d, a.onload = function() {
                  this.media = "all", t && setTimeout(t)
                }, e.body.appendChild(a))
            },
            jdgm.loadCSS.requestedUrls = [], jdgm.loadJS = function(e, d) {
              var t = new XMLHttpRequest;
              t.onreadystatechange = function() {
                  4 === t.readyState && (Function(t.response)(), d && d(t.response))
                },
                t.open("GET", e), t.send()
            }, jdgm.docReady((function() {
              (window.jdgmLoadCSS || e.querySelectorAll(".jdgm-widget, .jdgm-all-reviews-page").length > 0) && (jdgmSettings.widget_load_with_code_splitting ? parseFloat(jdgmSettings.widget_version) >= 3 ? jdgm.loadCSS(jdgm.CDN_HOST + "widget_v3/base.css") : jdgm.loadCSS(jdgm.CDN_HOST + "widget/base.css") : jdgm.loadCSS(jdgm.CDN_HOST + "shopify_v2.css"), jdgm.loadJS(jdgm.CDN_HOST + "loader.js"))
            }))
        }(document);
      </script>
      <noscript>
        <link rel="stylesheet" type="text/css" media="all" href="https://cdn.judge.me/shopify_v2.css">
      </noscript>
      <!-- BEGIN app snippet: theme_fix_tags -->
      <script>
        (function() {
          var jdgmThemeFixes = null;
          if (!jdgmThemeFixes) return;
          var thisThemeFix = jdgmThemeFixes[Shopify.theme.id];
          if (!thisThemeFix) return;
          if (thisThemeFix.html) {
            document.addEventListener("DOMContentLoaded", function() {
              var htmlDiv = document.createElement('div');
              htmlDiv.classList.add('jdgm-theme-fix-html');
              htmlDiv.innerHTML = thisThemeFix.html;
              document.body.append(htmlDiv);
            });
          };
          if (thisThemeFix.css) {
            var styleTag = document.createElement('style');
            styleTag.classList.add('jdgm-theme-fix-style');
            styleTag.innerHTML = thisThemeFix.css;
            document.head.append(styleTag);
          };
          if (thisThemeFix.js) {
            var scriptTag = document.createElement('script');
            scriptTag.classList.add('jdgm-theme-fix-script');
            scriptTag.innerHTML = thisThemeFix.js;
            document.head.append(scriptTag);
          };
        })();
      </script>
      <!-- END app snippet -->
      <!-- End of Judge.me Core -->
      <!-- END app app block -->
      <!-- BEGIN app block: shopify://apps/klaviyo-email-marketing-sms/blocks/klaviyo-onsite-embed/2632fe16-c075-4321-a88b-50b567f42507 -->
      <script async src="https://static.klaviyo.com/onsite/js/klaviyo.js?company_id=RS52tJ"></script>
      <script>
        ! function() {
          if (!window.klaviyo) {
            window._klOnsite = window._klOnsite || [];
            try {
              window.klaviyo = new Proxy({}, {
                get: function(n, i) {
                  return "push" === i ? function() {
                    var n;
                    (n = window._klOnsite).push.apply(n, arguments)
                  } : function() {
                    for (var n = arguments.length, o = new Array(n), w = 0; w < n; w++) o[w] = arguments[w];
                    var t = "function" == typeof o[o.length - 1] ? o.pop() : void 0,
                      e = new Promise((function(n) {
                        window._klOnsite.push([i].concat(o, [function(i) {
                          t && t(i), n(i)
                        }]))
                      }));
                    return e
                  }
                }
              })
            } catch (n) {
              window.klaviyo = window.klaviyo || [], window.klaviyo.push = function() {
                var n;
                (n = window._klOnsite).push.apply(n, arguments)
              }
            }
          }
        }();
      </script>
      <script id="viewed_product">
        if (item == null) {
          var _learnq = _learnq || [];
          var item = {
            Name: "<?php echo $name; ?> | Situs Gacor Pasti Seru Main Bareng Teman",
            ProductID: 8175435383104,
            Categories: ["Max Originals"],
            ImageURL: "https://www.maxjerky.com/cdn/shop/files/MJ_Tex_ProductPhoto2_grande.png?v=1683387818",
            URL: "<?php echo 'https://' . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]; ?>",
            Brand: "Max Jerky",
            Price: "$1.11",
            CompareAtPrice: "$0.00"
          };
          _learnq.push(['track', 'Viewed Product', item]);
          _learnq.push(['trackViewedItem', {
            Title: item.Name,
            ItemId: item.ProductID,
            Categories: item.Categories,
            ImageUrl: item.ImageURL,
            Url: item.URL,
            Metadata: {
              Brand: item.Brand,
              Price: item.Price,
              CompareAtPrice: item.CompareAtPrice
            }
          }]);
        }
      </script>
      <!-- END app app block -->
      <link href="https://monorail-edge.shopifysvc.com" rel="dns-prefetch">
      <script>
        (function() {
          if ("sendBeacon" in navigator && "performance" in window) {
            var session_token = document.cookie.match(/_shopify_s=([^;]*)/);
  
            function handle_abandonment_event(e) {
              var entries = performance.getEntries().filter(function(entry) {
                return /monorail-edge.shopifysvc.com/.test(entry.name);
              });
              if (!window.abandonment_tracked && entries.length === 0) {
                window.abandonment_tracked = true;
                var currentMs = Date.now();
                var navigation_start = performance.timing.navigationStart;
                var payload = {
                  shop_id: 71318765888,
                  url: window.location.href,
                  navigation_start,
                  duration: currentMs - navigation_start,
                  session_token: session_token && session_token.length === 2 ? session_token[1] : "",
                  page_type: "product"};
                window.navigator.sendBeacon("https://monorail-edge.shopifysvc.com/v1/produce", JSON.stringify({
                  schema_id: "online_store_buyer_site_abandonment/1.1",
                  payload: payload,
                  metadata: {
                    event_created_at_ms: currentMs,
                    event_sent_at_ms: currentMs
                  }
                }));
              }
            }
            window.addEventListener('pagehide', handle_abandonment_event);
          }
        }());
      </script>
      <script id="web-pixels-manager-setup">
        (function e(e, n, a, t, o, r, i) {
          var s = null !== e,
            l = ("function" == typeof BigInt && BigInt.toString().indexOf("[native code]") ? "modern" : "legacy").substring(0, 1),
            c =t.substring(0, 1);
          if (s) {
            window.Shopify = window.Shopify || {};
            var d = window.Shopify;
            d.analytics = d.analytics || {};
            var u = d.analytics;
            u.replayQueue = [], u.publish = function(e, n, a) {
              u.replayQueue.push([e, n, a])
            };
            try {
              self.performance.mark("wpm:start")
            } catch (e) {}
          }
          var p, f, y, h, v, m, w, g, b, _ = [a, "/wpm", "/", c, r, l,".js"].join("");
          f = (p = {
            src: _,
            async: !0,
            onload: function() {
              if (e) {
                var a = window.webPixelsManager.init(e);
                null == n || n(a);
                var t = window.Shopify.analytics;
                t.replayQueue.forEach((function(e) {
                  var n = e[0],
                    t = e[1],
                    o = e[2];
                  a.publishCustomEvent(n, t, o)
                })), t.replayQueue = [], t.publish = a.publishCustomEvent, t.visitor = a.visitor
              }
            },
            onerror: function() {
              var n = (null == e ? void 0 : e.storefrontBaseUrl) ? e.storefrontBaseUrl.replace(/\/$/, "") : self.location.origin,
                a = "".concat(n, "/.well-known/shopify/monorail/unstable/produce_batch"),
                t = JSON.stringify({
                  metadata: {
                    event_sent_at_ms: (new Date).getTime()
                  },
                  events: [{
                    schema_id: "web_pixels_manager_load/2.0",
                    payload: {
                      version: o || "latest",
                      page_url: self.location.href,
                      status: "failed",
                      error_msg: "".concat(_, " has failed to load")
                    },
                    metadata: {
                      event_created_at_ms: (new Date).getTime()
                    }
                  }]
                });
              try {
                if (self.navigator.sendBeacon.bind(self.navigator)(a, t)) return !0
              } catch (e) {}
              var r = new XMLHttpRequest;
              try {
                return r.open("POST", a, !0), r.setRequestHeader("Content-Type", "text/plain"), r.send(t), !0
              } catch (e) {
                console && console.warn && console.warn("[Web Pixels Manager] Got an unhandled error while logging a load error.")
              }
              return !1
            }
          }).src, y = p.async, h = void 0 === y || y, v = p.onload, m = p.onerror, w = document.createElement("script"), g = document.head, b = document.body, w.async = h, w.src = f, v && w.addEventListener("load", v), m && w.addEventListener("error", m), g ? g.appendChild(w) : b ? b.appendChild(w) : console.error("Did not find a head or body element to append the script")
        })({
          shopId: 71318765888,
          storefrontBaseUrl: "https://www.maxjerky.com",
          cdnBaseUrl: "https://www.maxjerky.com/cdn",
          surface: "storefront-renderer",
          enabledBetaFlags: ["web_pixels_async_pixel_refactor", "web_pixels_manager_performance_improvement"],
          webPixelsConfigList: [{
            "id": "shopify-app-pixel",
            "configuration": "{}",
            "eventPayloadVersion": "v1",
            "runtimeContext": "STRICT",
            "scriptVersion": "0570",
            "apiClientId": "shopify-pixel",
            "type": "APP"
          }, {
            "id": "shopify-custom-pixel",
            "eventPayloadVersion": "v1",
            "runtimeContext": "LAX",
            "scriptVersion": "0570",
            "apiClientId": "shopify-pixel",
            "type": "CUSTOM"
          }],
          initData: {
            "cart": null,
            "checkout": null,
            "customer": null,
            "productVariants": [{
              "id": "44546957803840",
              "image": {
                "src": "\/\/www.maxjerky.com\/cdn\/shop\/files\/MJ_Tex_ProductPhoto2.png?v=1683387818"
              },
              "price": {
                "amount": 1.11,
                "currencyCode": "USD"
              },
              "product": {
                "id": "8175435383104",
                "title": "<?php echo $name; ?> | Situs Gacor Pasti Seru Main Bareng Teman",
                "untranslatedTitle": "<?php echo $name; ?> | Situs Gacor Pasti Seru Main Bareng Teman",
                "url": "\/tentang/rekomen-gacor\/",
                "vendor": "Max Jerky",
                "type": "Jerky"
              },
              "sku": "MJ001",
              "title": "Default Title",
              "untranslatedTitle": "Default Title"
            }]
          },
        }, function pageEvents(webPixelsManagerAPI) {
          webPixelsManagerAPI.publish("page_viewed");
          webPixelsManagerAPI.publish("product_viewed", {
            "productVariant": {
              "id": "44546957803840",
              "image": {
                "src": "\/\/www.maxjerky.com\/cdn\/shop\/files\/MJ_Tex_ProductPhoto2.png?v=1683387818"
              },
              "price": {
                "amount": 1.11,
                "currencyCode": "USD"
              },
              "product": {
                "id": "8175435383104",
                "title": "<?php echo $name; ?> | Situs Gacor Pasti Seru Main Bareng Teman",
                "untranslatedTitle": "<?php echo $name; ?> | Situs Gacor Pasti Seru Main Bareng Teman",
                "url": "\/tentang/rekomen-gacor\/",
                "vendor": "Max Jerky",
                "type": "Jerky"
              },
              "sku": "MJ001",
              "title": "Default Title",
              "untranslatedTitle": "Default Title"
            }
          });
        }, "https://www.maxjerky.com/cdn", "browser", "0.0.409", "ff96195dw4cf21a27pf853c495m3895a265", ["web_pixels_async_pixel_refactor", "web_pixels_manager_performance_improvement"]);
      </script>
      <script>
        window.ShopifyAnalytics = window.ShopifyAnalytics || {};
        window.ShopifyAnalytics.meta = window.ShopifyAnalytics.meta || {};
        window.ShopifyAnalytics.meta.currency = 'USD';
        var meta = {
          "product": {
            "id": 8175435383104,
            "gid": "gid:\/\/shopify\/Product\/8175435383104",
            "vendor": "Max Jerky",
            "type": "Jerky",
            "variants": [{
              "id": 44546957803840,
              "price": 999,
              "name": "<?php echo $name; ?> | Situs Gacor Pasti Seru Main Bareng Teman",
              "public_title": null,
              "sku": "MJ001"
            }]
          },
          "page": {
            "pageType": "product",
            "resourceType": "product",
            "resourceId": 8175435383104
          }
        };
        for (var attr in meta) {
          window.ShopifyAnalytics.meta[attr] = meta[attr];
        }
      </script>
      <script>
        window.ShopifyAnalytics.merchantGoogleAnalytics = function() {};
      </script>
      <script class="analytics">
        (function() {
          var customDocumentWrite = function(content) {
            var jquery = null;
            if (window.jQuery) {
              jquery = window.jQuery;
            } else if (window.Checkout && window.Checkout.$) {
              jquery = window.Checkout.$;
            }
            if (jquery) {
              jquery('body').append(content);
            }
          };
          var hasLoggedConversion = function(token) {
            if (token) {
              return document.cookie.indexOf('loggedConversion=' + token) !== -1;
            }
            return false;
          }
          var setCookieIfConversion = function(token) {
            if (token) {
              var twoMonthsFromNow = new Date(Date.now());
              twoMonthsFromNow.setMonth(twoMonthsFromNow.getMonth() + 2);
              document.cookie = 'loggedConversion=' + token + '; expires=' + twoMonthsFromNow;
            }
          }
          var trekkie = window.ShopifyAnalytics.lib = window.trekkie = window.trekkie || [];
          if (trekkie.integrations) {
            return;
          }
          trekkie.methods = ['identify', 'page', 'ready', 'track', 'trackForm', 'trackLink'];
          trekkie.factory = function(method) {
            return function() {
              var args = Array.prototype.slice.call(arguments);
              args.unshift(method);
              trekkie.push(args);return trekkie;
            };
          };
          for (var i = 0; i < trekkie.methods.length; i++) {
            var key = trekkie.methods[i];
            trekkie[key] = trekkie.factory(key);
          }
          trekkie.load = function(config) {
            trekkie.config = config || {};
            trekkie.config.initialDocumentCookie = document.cookie;
            var first = document.getElementsByTagName('script')[0];
            var script = document.createElement('script');script.type = 'text/javascript';
            script.onerror = function(e) {
              var scriptFallback = document.createElement('script');
              scriptFallback.type = 'text/javascript';
              scriptFallback.onerror = function(error) {
                var Monorail = {
                  produce: function produce(monorailDomain, schemaId, payload) {
                    var currentMs = new Date().getTime();
                    var event = {
                      schema_id: schemaId,
                      payload: payload,
                      metadata: {
                        event_created_at_ms: currentMs,
                        event_sent_at_ms: currentMs
                      }
                    };
                    return Monorail.sendRequest("https://" + monorailDomain + "/v1/produce", JSON.stringify(event));
                  },
                  sendRequest: function sendRequest(endpointUrl, payload) {
                    // Try the sendBeacon API
                    if (window && window.navigator && typeof window.navigator.sendBeacon === 'function' && typeof window.Blob === 'function' && !Monorail.isIos12()) {
                      var blobData = new window.Blob([payload], {
                        type: 'text/plain'
                      });
                      if (window.navigator.sendBeacon(endpointUrl, blobData)) {
                        return true;
                      } // sendBeacon was not successful
                    } // XHR beacon
                    var xhr = new XMLHttpRequest();
                    try {
                      xhr.open('POST', endpointUrl);
                      xhr.setRequestHeader('Content-Type', 'text/plain');
                      xhr.send(payload);
                    } catch (e) {
                      console.log(e);
                    }
                    return false;
                  },
                  isIos12: function isIos12() {
                    return window.navigator.userAgent.lastIndexOf('iPhone; CPU iPhone OS 12_') !== -1 || window.navigator.userAgent.lastIndexOf('iPad; CPU OS 12_') !== -1;
                  }
                };
                Monorail.produce('monorail-edge.shopifysvc.com', 'trekkie_storefront_load_errors/1.1', {
                  shop_id: 71318765888,
                  theme_id: 147102531904,
                  app_name: "storefront",
                  context_url: window.location.href,
                  source_url: "//www.maxjerky.com/cdn/s/trekkie.storefront.7a4225caf9379fe42103e492053220a7195df1ae.min.js"
                });
              };
              scriptFallback.async = true;
              scriptFallback.src = '//www.maxjerky.com/cdn/s/trekkie.storefront.7a4225caf9379fe42103e492053220a7195df1ae.min.js';
              first.parentNode.insertBefore(scriptFallback, first);
            };
            script.async = true;
            script.src = '//www.maxjerky.com/cdn/s/trekkie.storefront.7a4225caf9379fe42103e492053220a7195df1ae.min.js';
            first.parentNode.insertBefore(script, first);
          };
          trekkie.load({
            "Trekkie": {
              "appName": "storefront",
              "development": false,
              "defaultAttributes": {
                "shopId": 71318765888,
                "isMerchantRequest": null,
                "themeId": 147102531904,
                "themeCityHash": "17273214885172366671",
                "contentLanguage": "en",
                "currency": "USD"
              },
              "isServerSideCookieWritingEnabled": true,
              "monorailRegion": "shop_domain"
            },
            "Facebook Pixel": {
              "pixelIds": ["255286390595096"],
              "agent": "plshopify1.2"
            },
            "TikTok Pixel": {
              "pixelId": "CIFO9J3C77UCFTF4P490"
            },
            "Google Gtag Pixel": {
              "conversionId": "GT-T5R8MBK",
              "eventLabels": [{
                "type": "purchase",
                "action_label": "MC-X2S2P3RN76"
              }, {
                "type": "page_view",
                "action_label": "MC-X2S2P3RN76"
              }, {
                "type": "view_item",
                "action_label": "MC-X2S2P3RN76"
              }],
              "targetCountry": "US"
            },
            "Session Attribution": {},
            "S2S": {
              "facebookCapiEnabled": true,
              "facebookAppPixelId": "255286390595096",
              "source": "trekkie-storefront-renderer"
            }
          });
          var loaded = false;
          trekkie.ready(function() {
            if (loaded) return;
            loaded = true;
            window.ShopifyAnalytics.lib = window.trekkie;
            var originalDocumentWrite = document.write;
            document.write = customDocumentWrite;
            try {
              window.ShopifyAnalytics.merchantGoogleAnalytics.call(this);
            } catch (error) {};
            document.write = originalDocumentWrite;
            window.ShopifyAnalytics.lib.page(null, {
              "pageType": "product",
              "resourceType": "product",
              "resourceId": 8175435383104
            });
            var match = window.location.pathname.match(/checkouts\/(.+)\/(thank_you|post_purchase)/)
            var token = match ? match[1] : ;
            if (!hasLoggedConversion(token)) {
              setCookieIfConversion(token);
              window.ShopifyAnalytics.lib.track("Viewed Product", {
                "currency": "USD",
                "variantId": 44546957803840,
                "productId": 8175435383104,
                "productGid": "gid:\/\/shopify\/Product\/8175435383104",
                "name": "<?php echo $name; ?> | Situs Gacor Pasti Seru Main Bareng Teman",
                "price": "1.11",
                "sku": "MJ001",
                "brand": "Max Jerky",
                "variant": null,
                "category": "Jerky",
                "nonInteraction": true
              });
              window.ShopifyAnalytics.lib.track("monorail:\/\/trekkie_storefront_viewed_product\/1.1", {
                "currency": "USD",
                "variantId": 44546957803840,
                "productId": 8175435383104,
                "productGid": "gid:\/\/shopify\/Product\/8175435383104",
                "name": "<?php echo $name; ?> | Situs Gacor Pasti Seru Main Bareng Teman",
                "price": "1.11",
                "sku": "MJ001",
                "brand": "Max Jerky",
                "variant": null,
                "category": "Jerky",
                "nonInteraction": true,
                "referer": "https:\/\/covid19.puncakjayakab.go.id\/tentang\/rekomen-gacor\/"
              });
            }
          });
          var eventsListenerScript = document.createElement('script');
          eventsListenerScript.async = true;
          eventsListenerScript.src = "//www.maxjerky.com/cdn/shopifycloud/shopify/assets/shop_events_listener-a7c63dba65ccddc484f77541dc8ca437e60e1e9e297fe1c3faebf6523a0ede9b.js";
          document.getElementsByTagName('head')[0].appendChild(eventsListenerScript);
        })();
      </script>
      <script class="boomerang">
        (function() {
            if (window.BOOMR && (window.BOOMR.version || window.BOOMR.snippetExecuted)) {
              return;
            }
            window.BOOMR = window.BOOMR || {};
            window.BOOMR.snippetStart = new Date().getTime();
            window.BOOMR.snippetExecuted = true;
            window.BOOMR.snippetVersion = 12;
            window.BOOMR.application = "storefront-renderer";
            window.BOOMR.themeName = "Sense";
            window.BOOMR.themeVersion = "8.0.0";
            window.BOOMR.shopId = 71318765888;
            window.BOOMR.themeId = 147102531904;
            window.BOOMR.renderRegion = "gcp-us-central1";
            window.BOOMR.url = "https://www.maxjerky.com/cdn/shopifycloud/boomerang/shopify-boomerang-1.0.0.min.js";
            var where= document.currentScript || document.getElementsByTagName("script")[0];
            var parentNode = where.parentNode;
            var promoted = false;
            var LOADER_TIMEOUT = 3000;
  
            function promote() {
              if (promoted) {
                return;
              }
              var script = document.createElement("script");
              script.id = "boomr-scr-as";
              script.src = window.BOOMR.url;
              script.async = true;parentNode.appendChild(script);
              promoted = true;
            }
  
            function iframeLoader(wasFallback) {
              promoted = true;
              var dom, bootstrap, iframe, iframeStyle;
              var doc = document;
              var win = window;
              window.BOOMR.snippetMethod = wasFallback ? "if" : "i";
              bootstrap = function(parent, scriptId) {
                var script = doc.createElement("script");
                script.id = scriptId || "boomr-if-as";
                script.src = window.BOOMR.url;
                BOOMR_lstart = new Date().getTime();
                parent = parent || doc.body;
                parent.appendChild(script);
              };
              if (!window.addEventListener && window.attachEvent && navigator.userAgent.match(/MSIE [67]./)) {
                window.BOOMR.snippetMethod = "s";
                bootstrap(parentNode, "boomr-async");
                return;
              }
              iframe = document.createElement("IFRAME");
              iframe.src = "about:blank";
              iframe.title = "";
              iframe.role = "presentation";
              iframe.loading = "eager";
              iframeStyle = (iframe.frameElement || iframe).style;
              iframeStyle.width = 0;
              iframeStyle.height = 0;
              iframeStyle.border = 0;
              iframeStyle.display = "none";
              parentNode.appendChild(iframe);
              try {
                win = iframe.contentWindow;
                doc = win.document.open();
              } catch (e) {
                dom = document.domain;
                iframe.src = "javascript:var d=document.open();d.domain='" + dom + "';void(0);";
                win = iframe.contentWindow;
                doc = win.document.open();
              }
              if (dom) {
                doc._boomrl = function() {
                  this.domain = dom;
                  bootstrap();
                };
                doc.write(" < body onload = 'document._boomrl();' > ");
                }
                else {
                  win._boomrl = function() {
                    bootstrap();
                  };
                  if (win.addEventListener) {
                    win.addEventListener("load", win._boomrl, false);
                  } else if (win.attachEvent) {
                    win.attachEvent("onload", win._boomrl);
                  }
                }
                doc.close();
              }
              var link = document.createElement("link");
              if (link.relList && typeof link.relList.supports === "function" && link.relList.supports("preload") && ("as" in link)) {
                window.BOOMR.snippetMethod = "p";
                link.href = window.BOOMR.url;
                link.rel = "preload";
                link.as = "script";
                link.addEventListener("load", promote);
                link.addEventListener("error", function() {
                  iframeLoader(true);
                });
                setTimeout(function() {
                  if (!promoted) {
                    iframeLoader(true);
                  }
                }, LOADER_TIMEOUT);
                BOOMR_lstart = new Date().getTime();
                parentNode.appendChild(link);
              } else {
                iframeLoader(false);
              }
  
              function boomerangSaveLoadTime(e) {
                window.BOOMR_onload = (e && e.timeStamp) || new Date().getTime();
              }
              if (window.addEventListener) {
                window.addEventListener("load", boomerangSaveLoadTime, false);
              } else if (window.attachEvent) {
                window.attachEvent("onload", boomerangSaveLoadTime);
              }
              if (document.addEventListener) {
                document.addEventListener("onBoomerangLoaded", function(e) {
                  e.detail.BOOMR.init({
                    ResourceTiming: {
                      enabled: true,
                      trackedResourceTypes: ["script", "img", "css"]
                    },
                  });
                  e.detail.BOOMR.t_end = new Date().getTime();
                });
              } else if (document.attachEvent) {
                document.attachEvent("onpropertychange", function(e) {
                  if (!e) e = event;
                  if (e.propertyName === "onBoomerangLoaded") {
                    e.detail.BOOMR.init({
                      ResourceTiming: {
                        enabled: true,
                        trackedResourceTypes: ["script", "img", "css"]
                      },
                    });
                    e.detail.BOOMR.t_end = new Date().getTime();
                  }
                });
              }
            })();
      </script>
    </head>
    <body class="gradient">
      <a class="skip-to-content-link button visually-hidden" href="#MainContent"> Skip to content </a>
      <!-- BEGIN sections: header-group -->
      <div id="shopify-section-sections--18511643312448__announcement-bar" class="shopify-section shopify-section-group-header-group announcement-bar-section">
        <div class="announcement-bar color-inverse gradient" role="region" aria-label="Announcement">
          <div class="page-width" style="background: #ff0000; max-width: 100vw !important;">
            <p class="announcement-bar__message center h5" style="color: ##ff0000;">
              <span><?php echo $name; ?> DENGAN BONUS TERBESAR 2024</span>
            </p>
          </div>
        </div>
      </div>
      <div id="shopify-section-sections--18511643312448__header" class="shopify-section shopify-section-group-header-group section-header">
        <link rel="stylesheet" href="//www.maxjerky.com/cdn/shop/t/3/assets/component-list-menu.css?v=151968516119678728991680102129" media="print" onload="this.media='all'">
        <link rel="stylesheet" href="//www.maxjerky.com/cdn/shop/t/3/assets/component-search.css?v=184225813856820874251680102129" media="print" onload="this.media='all'">
        <link rel="stylesheet" href="//www.maxjerky.com/cdn/shop/t/3/assets/component-menu-drawer.css?v=182311192829367774911680102129" media="print" onload="this.media='all'">
        <link rel="stylesheet" href="//www.maxjerky.com/cdn/shop/t/3/assets/component-cart-notification.css?v=137625604348931474661680102129" media="print" onload="this.media='all'">
        <link rel="stylesheet" href="//www.maxjerky.com/cdn/shop/t/3/assets/component-cart-items.css?v=55474296274625234991680102129" media="print" onload="this.media='all'">
        <link rel="stylesheet" href="//www.maxjerky.com/cdn/shop/t/3/assets/component-price.css?v=82028280056449651151680102127" media="print" onload="this.media='all'">
        <link rel="stylesheet" href="//www.maxjerky.com/cdn/shop/t/3/assets/component-loading-overlay.css?v=167310470843593579841680102127" media="print" onload="this.media='all'">
        <noscript>
          <link href="//www.maxjerky.com/cdn/shop/t/3/assets/component-list-menu.css?v=151968516119678728991680102129" rel="stylesheet" type="text/css" media="all" />
        </noscript>
        <noscript>
          <link href="//www.maxjerky.com/cdn/shop/t/3/assets/component-search.css?v=184225813856820874251680102129" rel="stylesheet" type="text/css" media="all" />
        </noscript>
        <noscript>
          <link href="//www.maxjerky.com/cdn/shop/t/3/assets/component-menu-drawer.css?v=182311192829367774911680102129" rel="stylesheet" type="text/css" media="all" />
        </noscript>
        <noscript>
          <link href="//www.maxjerky.com/cdn/shop/t/3/assets/component-cart-notification.css?v=137625604348931474661680102129" rel="stylesheet" type="text/css" media="all" />
        </noscript>
        <noscript>
          <link href="//www.maxjerky.com/cdn/shop/t/3/assets/component-cart-items.css?v=55474296274625234991680102129" rel="stylesheet" type="text/css" media="all" />
        </noscript><style>
          .header,
          .h2 {
            font-family: 'Workfolk-Extended';
          }
  
          header-drawer {
            justify-self: start;
            margin-left: -1.2rem;
          }
  
          .header__heading-logo {
            max-width: 70px;
          }
  
          @media screen and (min-width: 990px) {
            header-drawer {
              display: none;
            }
          }
  
          .menu-drawer-container {
            display: flex;}
  
          .list-menu {
            list-style: none;
            padding: 0;
            margin: 0;
          }
  
          .list-menu--inline {
            display: inline-flex;
            flex-wrap: wrap;
          }
  
          summary.list-menu__item {
            padding-right: 2.7rem;
          }
  
          .list-menu__item {
            display: flex;
            align-items: center;
            line-height: calc(1 + 0.3 / var(--font-body-scale));
          }
  
          .list-menu__item--link {
            text-decoration: none;
            padding-bottom: 1rem;
            padding-top: 1rem;
            line-height: calc(1 + 0.8 / var(--font-body-scale));
          }
  
          @media screen and (min-width: 750px) {
            .list-menu__item--link {
              padding-bottom: 0.5rem;
              padding-top: 0.5rem;
            }
  
            .customWideDropdown {
              display: flex;
              width: 100vw !important;
              justify-content: center;
              background: #F58020;
              border-radius: 0px !important;
              padding: 5px !important;
              border: none !important;
            }
          }
  
          @media screen and (min-width: 1000px) {
            #mainNav {
              width: 50vw;
              display: flex;
            }
          }
  
          .customDropdownLink {
            color: black !important;
            font-size: 20px;
          }
  
          .customDropdownLink:hover {
            color: white !important;
          }
  
          #mainNav>ul {
            flex: 1;
            justify-content: space-around;
          }
  
          #Details-HeaderMenu-2:hover {
            color: black !important;
            background: #F58020 !important;
          }
  
          #Details-HeaderMenu-2>summary {
            text-decoration: none !important;
          }
        </style>
        <style data-shopify>
          .header__heading {
            text-transform: uppercase;
          }
  
          .header {
            padding-top: 10px;
            padding-bottom: 0px;
          }
  
          .section-header {
            position: sticky;
            /* This is for fixing a Safari z-index issue. PR #2147 */
            margin-bottom: 0px;
          }
  
          @media screen and (min-width: 750px) {
            .section-header {
              margin-bottom: 0px;
            }
          }
  
          @media screen and (min-width: 990px) {
            .header {
              padding-top: 20px;
              padding-bottom: 0px;
            }
          }
        </style>
        <script src="//www.maxjerky.com/cdn/shop/t/3/assets/details-disclosure.js?v=153497636716254413831681289699" defer="defer"></script>
        <script src="//www.maxjerky.com/cdn/shop/t/3/assets/details-modal.js?v=111603181540343972631680853569" defer="defer"></script>
        <script src="//www.maxjerky.com/cdn/shop/t/3/assets/cart-notification.js?v=160453272920806432391680102128" defer="defer"></script>
        <script src="//www.maxjerky.com/cdn/shop/t/3/assets/search-form.js?v=113639710312857635801680102128" defer="defer"></script>
        <script src="//www.maxjerky.com/cdn/shop/t/3/assets/navHover.js?v=139944281942753229291682675534" defer="defer"></script>
        <svg xmlns="http://www.w3.org/2000/svg" class="hidden">
          <symbol id="icon-search" viewbox="0 0 18 19" fill="none">
            <path fill-rule="evenodd" clip-rule="evenodd" d="M11.03 11.68A5.784 5.784 0 112.85 3.5a5.784 5.784 0 018.18 8.18zm.26 1.12a6.78 6.78 0 11.72-.7l5.4 5.4a.5.5 0 11-.71.7l-5.41-5.4z" fill="currentColor" />
          </symbol>
          <symbol id="icon-reset" class="icon icon-close" fill="none" viewBox="0 0 18 18" stroke="currentColor">
            <circle r="8.5" cy="9" cx="9" stroke-opacity="0.2" />
            <path d="M6.82972 6.82915L1.17193 1.17097" stroke-linecap="round" stroke-linejoin="round" transform="translate(5 5)" />
            <path d="M1.22896 6.88502L6.77288 1.11523" stroke-linecap="round" stroke-linejoin="round" transform="translate(5 5)" />
          </symbol>
          <symbol id="icon-close" class="icon icon-close" fill="none" viewBox="0 0 18 17">
            <path d="M.865 15.978a.5.5 0 00.707.707l7.433-7.431 7.579 7.282a.501.501 0 00.846-.37.5.5 0 00-.153-.351L9.712 8.546l7.417-7.416a.5.5 0 10-.707-.708L8.991 7.853 1.413.573a.5.5 0 10-.693.72l7.563 7.268-7.418 7.417z" fill="currentColor">
          </symbol>
        </svg>
        <sticky-header data-sticky-type="on-scroll-up" class="header-wrapper color-accent-1 gradient">
          <header class="header header--top-center header--mobile-left page-width header--has-menu">
            <header-drawer data-breakpoint="tablet">
              <details id="Details-menu-drawer-container" class="menu-drawer-container">
                <summary class="header__icon header__icon--menu header__icon--summary link focus-inset" aria-label="Menu">
                  <span>
                    <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" class="icon icon-hamburger" fill="none" viewBox="0 0 18 16">
                      <path d="M1 .5a.5.5 0 100 1h15.71a.5.5 0 000-1H1zM.5 8a.5.5 0 01.5-.5h15.71a.5.5 0 010 1H1A.5.5 0 01.5 8zm0 7a.5.5 0 01.5-.5h15.71a.5.5 0 010 1H1a.5.5 0 01-.5-.5z" fill="currentColor">
                    </svg>
                    <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" class="icon icon-close" fill="none" viewBox="0 0 18 17">
                      <path d="M.865 15.978a.5.5 0 00.707.707l7.433-7.431 7.579 7.282a.501.501 0 00.846-.37.5.5 0 00-.153-.351L9.712 8.546l7.417-7.416a.5.5 0 10-.707-.708L8.991 7.853 1.413.573a.5.5 0 10-.693.72l7.563 7.268-7.418 7.417z" fill="currentColor">
                    </svg>
                  </span>
                </summary>
                <div id="menu-drawer" class="gradient menu-drawer motion-reduce" tabindex="-1">
                  <div class="menu-drawer__inner-container">
                    <div class="menu-drawer__navigation-container">
                      <nav class="menu-drawer__navigation">
                        <ul class="menu-drawer__menu has-submenu list-menu" role="list">
                          <li>
                            <a href="/" class="menu-drawer__menu-item list-menu__item link link--text focus-inset"> Beranda </a>
                          </li>
                          <li><details id="Details-menu-drawer-menu-item-2">
                              <summary class="menu-drawer__menu-item list-menu__item link link--text focus-inset"> <?php echo $name; ?> <svg viewBox="0 0 14 10" fill="none" aria-hidden="true" focusable="false" class="icon icon-arrow" xmlns="http://www.w3.org/2000/svg">
                                  <path fill-rule="evenodd" clip-rule="evenodd" d="M8.537.808a.5.5 0 01.817-.162l4 4a.5.5 0 010 .708l-4 4a.5.5 0 11-.708-.708L11.793 5.5H1a.5.5 0 010-1h10.793L8.646 1.354a.5.5 0 01-.109-.546z" fill="currentColor">
                                </svg>
                                <svg aria-hidden="true" focusable="false" class="icon icon-caret" viewBox="0 0 10 6">
                                  <path fill-rule="evenodd" clip-rule="evenodd" d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z" fill="currentColor">
                                </svg>
                              </summary>
                              <div id="link-shop" class="menu-drawer__submenu has-submenu gradient motion-reduce" tabindex="-1">
                                <div class="menu-drawer__inner-submenu">
                                  <button class="menu-drawer__close-button link link--text focus-inset" aria-expanded="true">
                                    <svg viewBox="0 0 14 10" fill="none" aria-hidden="true" focusable="false" class="icon icon-arrow" xmlns="http://www.w3.org/2000/svg">
                                      <path fill-rule="evenodd" clip-rule="evenodd" d="M8.537.808a.5.5 0 01.817-.162l4 4a.5.5 0 010 .708l-4 4a.5.5 0 11-.708-.708L11.793 5.5H1a.5.5 0 010-1h10.793L8.646 1.354a.5.5 0 01-.109-.546z" fill="currentColor">
                                    </svg> <?php echo $name; ?> </button>
                                  <ul class="menu-drawer__menu list-menu" role="list" tabindex="-1">
                                    <li>
                                      <a href="./" class="menu-drawer__menu-item link link--text list-menu__item focus-inset"> <?php echo $name; ?> Terbaru </a>
                                    </li>
                                    <li>
                                      <a href="./" class="menu-drawer__menu-item link link--text list-menu__item focus-inset"> <?php echo $name; ?> Terpercaya </a>
                                    </li>
                                    <li>
                                      <a href="./" class="menu-drawer__menu-item link link--text list-menu__item focus-inset"> <?php echo $name; ?> Tergacor </a>
                                    </li>
                                  </ul>
                                </div>
                              </div>
                            </details>
                          </li>
                          <li>
                            <a href="/pages/vote" class="menu-drawer__menu-item list-menu__item link link--text focus-inset"> Vote <?php echo $name; ?> </a>
                          </li>
                          <li>
                            <a href="/pages/about-us" class="menu-drawer__menu-item list-menu__item link link--text focus-inset"> Tentang <?php echo $name; ?> </a>
                          </li>
                          <li>
                            <a href="/pages/contact" class="menu-drawer__menu-item list-menu__item link link--text focus-inset"> Kontak <?php echo $name; ?> </a>
                          </li>
                        </ul>
                      </nav>
                      <div class="menu-drawer__utility-links">
                        <ul class="list list-social list-unstyled" role="list">
                          <li class="list-social__item">
                            <a href="https://twitter.com/" class="list-social__link link" s>
                              <svg aria-hidden="true" focusable="false" class="icon icon-twitter" viewBox="0 0 18 15">
                                <path fill="currentColor" d="M17.64 2.6a7.33 7.33 0 01-1.75 1.82c0 .05 0 .13.02.23l.02.23a9.97 9.97 0 01-1.69 5.54c-.57.85-1.24 1.62-2.02 2.28a9.09 9.09 0 01-2.82 1.6 10.23 10.23 0 01-8.9-.98c.34.02.61.04.83.04 1.64 0 3.1-.5 4.38-1.5a3.6 3.6 0 01-3.3-2.45A2.91 2.91 0 004 9.35a3.47 3.47 0 01-2.02-1.21 3.37 3.37 0 01-.8-2.22v-.03c.46.24.98.37 1.58.4a3.45 3.45 0 01-1.54-2.9c0-.61.14-1.2.45-1.79a9.68 9.68 0 003.2 2.6 10 10 0 004.08 1.07 3 3 0 01-.13-.8c0-.97.34-1.8 1.03-2.48A3.45 3.45 0 0112.4.96a3.49 3.49 0 012.54 1.1c.8-.15 1.54-.44 2.23-.85a3.4 3.4 0 01-1.54 1.94c.74-.1 1.4-.28 2.01-.54z">
                              </svg>
                              <span class="visually-hidden">Twitter</span>
                            </a>
                          </li>
                          <li class="list-social__item">
                            <a href="https://www.facebook.com/" class="list-social__link link" s>
                              <svg aria-hidden="true" focusable="false" class="icon icon-facebook" viewBox="0 0 18 18">
                                <path fill="currentColor" d="M16.42.61c.27 0 .5.1.69.28.19.2.28.42.28.7v15.44c0 .27-.1.5-.28.69a.94.94 0 01-.7.28h-4.39v-6.7h2.25l.31-2.65h-2.56v-1.7c0-.4.1-.72.28-.93.18-.2.5-.32 1-.32h1.37V3.35c-.6-.06-1.27-.1-2.01-.1-1.01 0-1.83.3-2.45.9-.62.6-.93 1.44-.93 2.53v1.97H7.04v2.65h2.24V18H.98c-.28 0-.5-.1-.7-.28a.94.94 0 01-.28-.7V1.59c0-.27.1-.5.28-.69a.94.94 0 01.7-.28h15.44z">
                              </svg>
                              <span class="visually-hidden">Facebook</span>
                            </a>
                          </li>
                          <li class="list-social__item">
                            <a href="https://www.instagram.com/" class="list-social__link link" s>
                              <svg aria-hidden="true" focusable="false" class="icon icon-instagram" viewBox="0 0 18 18">
                                <path fill="currentColor" d="M8.77 1.58c2.34 0 2.62.01 3.54.05.86.04 1.32.18 1.63.3.41.17.7.35 1.01.66.3.3.5.6.65 1 .12.32.27.78.3 1.64.05.92.06 1.2.06 3.54s-.01 2.62-.05 3.54a4.79 4.79 0 01-.3 1.63c-.17.41-.35.7-.66 1.01-.3.3-.6.5-1.01.66-.31.12-.77.26-1.63.3-.92.04-1.2.05-3.54.05s-2.62 0-3.55-.05a4.79 4.79 0 01-1.62-.3c-.42-.16-.7-.35-1.01-.66-.31-.3-.5-.6-.66-1a4.87 4.87 0 01-.3-1.64c-.04-.92-.05-1.2-.05-3.54s0-2.62.05-3.54c.04-.86.18-1.32.3-1.63.16-.41.35-.7.66-1.01.3-.3.6-.5 1-.65.32-.12.78-.27 1.63-.3.93-.05 1.2-.06 3.55-.06zm0-1.58C6.39 0 6.09.01 5.15.05c-.93.04-1.57.2-2.13.4-.57.23-1.06.54-1.55 1.02C1 1.96.7 2.45.46 3.02c-.22.56-.37 1.2-.4 2.13C0 6.1 0 6.4 0 8.77s.01 2.68.05 3.61c.04.94.2 1.57.4 2.13.23.58.54 1.07 1.02 1.56.49.48.98.78 1.55 1.01.56.22 1.2.37 2.13.4.94.05 1.24.06 3.62.06 2.39 0 2.68-.01 3.62-.05.93-.04 1.57-.2 2.13-.41a4.27 4.27 0 001.55-1.01c.49-.49.79-.98 1.01-1.56.22-.55.37-1.19.41-2.13.04-.93.05-1.23.05-3.61 0-2.39 0-2.68-.05-3.62a6.47 6.47 0 00-.4-2.13 4.27 4.27 0 00-1.02-1.55A4.35 4.35 0 0014.52.46a6.43 6.43 0 00-2.13-.41A69 69 0 008.77 0z" />
                                <path fill="currentColor" d="M8.8 4a4.5 4.5 0 100 9 4.5 4.5 0 000-9zm0 7.43a2.92 2.92 0 110-5.85 2.92 2.92 0 010 5.85zM13.43 5a1.05 1.05 0 100-2.1 1.05 1.05 0 000 2.1z">
                              </svg>
                              <span class="visually-hidden">Instagram</span>
                            </a>
                          </li>
                          <li class="list-social__item">
                            <a href="https://www.tiktok.com/" class="list-social__link link" s>
                              <svg aria-hidden="true" focusable="false" class="icon icon-tiktok" width="16" height="18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M8.02 0H11s-.17 3.82 4.13 4.1v2.95s-2.3.14-4.13-1.26l.03 6.1a5.52 5.52 0 11-5.51-5.52h.77V9.4a2.5 2.5 0 101.76 2.4L8.02 0z" fill="currentColor">
                              </svg>
                              <span class="visually-hidden">TikTok</span>
                            </a>
                          </li>
                          <li class="list-social__item">
                            <a href="https://www.youtube.com/" class="list-social__link link" s>
                              <svg aria-hidden="true" focusable="false" class="icon icon-youtube" viewBox="0 0 100 70">
                                <path d="M98 11c2 7.7 2 24 2 24s0 16.3-2 24a12.5 12.5 0 01-9 9c-7.7 2-39 2-39 2s-31.3 0-39-2a12.5 12.5 0 01-9-9c-2-7.7-2-24-2-24s0-16.3 2-24c1.2-4.4 4.6-7.8 9-9 7.7-2 39-2 39-2s31.3 0 39 2c4.4 1.2 7.8 4.6 9 9zM40 50l26-15-26-15v30z" fill="currentColor">
                              </svg>
                              <span class="visually-hidden">YouTube</span>
                            </a>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                </div>
              </details>
            </header-drawer>
            <details-modal class="header__search">
              <details>
                <summary class="header__icon header__icon--search header__icon--summary link focus-inset modal__toggle" aria-haspopup="dialog" aria-label="Search">
                  <span>
                    <svg class="modal__toggle-open icon icon-search" aria-hidden="true" focusable="false">
                      <use href="#icon-search">
                    </svg>
                    <svg class="modal__toggle-close icon icon-close" aria-hidden="true" focusable="false">
                      <use href="#icon-close">
                    </svg>
                  </span>
                </summary>
                <div class="search-modal modal__content gradient" role="dialog" aria-modal="true" aria-label="Search">
                  <div class="modal-overlay"></div>
                  <div class="search-modal__content search-modal__content-bottom" tabindex="-1">
                    <predictive-search class="search-modal__form" data-loading-text="Loading...">
                      <form action="/search" method="get" role="search" class="search search-modal__form">
                        <div class="field">
                          <input class="search__input field__input" id="Search-In-Modal-1" type="search" name="q" value="" placeholder="Search" role="combobox" aria-expanded="false" aria-owns="predictive-search-results" aria-controls="predictive-search-results" aria-haspopup="listbox" aria-autocomplete="list" autocorrect="off" autocomplete="off" autocapitalize="off" spellcheck="false">
                          <label class="field__label" for="Search-In-Modal-1">Search</label>
                          <input type="hidden" name="options[prefix]" value="last">
                          <button type="reset" class="reset__button field__button hidden" aria-label="Clear search term">
                            <svg class="icon icon-close" aria-hidden="true" focusable="false">
                              <use xlink:href="#icon-reset">
                            </svg>
                          </button>
                          <button class="search__button field__button" aria-label="Search">
                            <svg class="icon icon-search" aria-hidden="true" focusable="false">
                              <use href="#icon-search">
                            </svg>
                          </button>
                        </div>
                        <div class="predictive-search predictive-search--header" tabindex="-1" data-predictive-search>
                          <div class="predictive-search__loading-state">
                            <svg aria-hidden="true" focusable="false" class="spinner" viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                              <circle class="path" fill="none" stroke-width="6" cx="33" cy="33" r="30"></circle>
                            </svg>
                          </div>
                        </div>
                        <span class="predictive-search-status visually-hidden" role="status" aria-hidden="true"></span>
                      </form>
                    </predictive-search>
                    <button type="button" class="modal__close-button link link--text focus-inset" aria-label="Close">
                      <svg class="icon icon-close" aria-hidden="true" focusable="false">
                        <use href="#icon-close">
                      </svg>
                    </button>
                  </div>
                </div>
              </details>
            </details-modal>
            <a href="./" class="header__heading-link link link--text focus-inset">
              <span class="h2"><?php echo $name; ?></span>
            </a>
            <nav class="header__inline-menu" id="mainNav">
              <ul class="list-menu list-menu--inline" role="list">
                <li>
                  <a href="/" class="header__menu-item list-menu__item link link--text focus-inset">
                    <span>Beranda</span>
                  </a>
                </li>
                <li>
                  <header-menu>
                    <details id="Details-HeaderMenu-2">
                      <!--                   Code for dropdown here -->
                      <summary class="header__menu-item list-menu__item link focus-inset">
                        <span><?php echo $name; ?></span>
                        <svg aria-hidden="true" focusable="false" class="icon icon-caret" viewBox="0 0 10 6">
                          <path fill-rule="evenodd" clip-rule="evenodd" d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z" fill="currentColor">
                        </svg>
                      </summary>
                      <ul id="HeaderMenu-MenuList-2" class="customWideDropdown header__submenu list-menu list-menu--disclosure gradient caption-large motion-reduce global-settings-popup" role="list" tabindex="-1">
                        <li>
                          <a href="./" class="customDropdownLink header__menu-item list-menu__item link link--text focus-inset caption-large"> <?php echo $name; ?> Terbaru </a>
                        </li>
                        <li>
                          <a href="./" class="customDropdownLink header__menu-item list-menu__item link link--text focus-inset caption-large"> <?php echo $name; ?> Terpercaya </a>
                        </li>
                        <li>
                          <a href="./" class="customDropdownLink header__menu-item list-menu__item link link--text focus-inset caption-large"> <?php echo $name; ?> Tergacor </a>
                        </li>
                      </ul>
                    </details>
                  </header-menu>
                </li>
                <li>
                  <a href="/pages/vote" class="header__menu-item list-menu__item link link--text focus-inset">
                    <span>Vote <?php echo $name; ?></span>
                  </a>
                </li>
                <li>
                  <a href="/pages/about-us" class="header__menu-item list-menu__item link link--text focus-inset">
                    <span>Tentang <?php echo $name; ?></span>
                  </a>
                </li>
                <li>
                  <a href="/pages/contact" class="header__menu-item list-menu__item link link--text focus-inset">
                    <span>Kontak <?php echo $name; ?></span>
                  </a>
                </li>
              </ul>
            </nav>
            <div class="header__icons">
              <details-modal class="header__search">
                <details>
                  <summary class="header__icon header__icon--search header__icon--summary link focus-inset modal__toggle" aria-haspopup="dialog" aria-label="Search">
                    <span>
                      <svg class="modal__toggle-open icon icon-search" aria-hidden="true" focusable="false">
                        <use href="#icon-search">
                      </svg>
                      <svg class="modal__toggle-close icon icon-close" aria-hidden="true" focusable="false">
                        <use href="#icon-close">
                      </svg>
                    </span>
                  </summary>
                  <div class="search-modal modal__content gradient" role="dialog" aria-modal="true" aria-label="Search">
                    <div class="modal-overlay"></div>
                    <div class="search-modal__content search-modal__content-bottom" tabindex="-1">
                      <predictive-search class="search-modal__form" data-loading-text="Loading...">
                        <form action="/search" method="get" role="search" class="search search-modal__form">
                          <div class="field">
                            <input class="search__input field__input" id="Search-In-Modal" type="search" name="q" value="" placeholder="Search" role="combobox" aria-expanded="false" aria-owns="predictive-search-results" aria-controls="predictive-search-results" aria-haspopup="listbox" aria-autocomplete="list" autocorrect="off" autocomplete="off" autocapitalize="off" spellcheck="false">
                            <label class="field__label" for="Search-In-Modal">Search</label>
                            <input type="hidden" name="options[prefix]" value="last">
                            <button type="reset" class="reset__button field__button hidden" aria-label="Clear search term">
                              <svg class="icon icon-close" aria-hidden="true" focusable="false">
                                <use xlink:href="#icon-reset">
                              </svg>
                            </button>
                            <button class="search__button field__button" aria-label="Search">
                              <svg class="icon icon-search" aria-hidden="true" focusable="false">
                                <use href="#icon-search">
                              </svg>
                            </button>
                          </div>
                          <div class="predictive-search predictive-search--header" tabindex="-1" data-predictive-search>
                            <div class="predictive-search__loading-state">
                              <svg aria-hidden="true" focusable="false" class="spinner" viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg"><circle class="path" fill="none" stroke-width="6" cx="33" cy="33" r="30"></circle>
                              </svg>
                            </div>
                          </div>
                          <span class="predictive-search-status visually-hidden" role="status" aria-hidden="true"></span>
                        </form>
                      </predictive-search>
                      <button type="button" class="search-modal__close-button modal__close-button link link--text focus-inset" aria-label="Close">
                        <svg class="icon icon-close" aria-hidden="true" focusable="false">
                          <use href="#icon-close">
                        </svg>
                      </button>
                    </div>
                  </div>
                </details>
              </details-modal>
              <a href="/cart" class="header__icon header__icon--cart link focus-inset" id="cart-icon-bubble">
                <svg class="icon icon-cart-empty" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 40 40" fill="none">
                  <path d="m15.75 11.8h-3.16l-.77 11.6a5 5 0 0 0 4.99 5.34h7.38a5 5 0 0 0 4.99-5.33l-.78-11.61zm0 1h-2.22l-.71 10.67a4 4 0 0 0 3.99 4.27h7.38a4 4 0 0 0 4-4.27l-.72-10.67h-2.22v.63a4.75 4.75 0 1 1 -9.5 0zm8.5 0h-7.5v.63a3.75 3.75 0 1 0 7.5 0z" fill="currentColor" fill-rule="evenodd" />
                </svg>
                <span class="visually-hidden">Cart</span>
              </a>
            </div>
          </header>
        </sticky-header>
        <cart-notification>
          <div class="cart-notification-wrapper page-width">
            <div id="cart-notification" class="cart-notification focus-inset color-accent-1 gradient" aria-modal="true" aria-label="Item added to your cart" role="dialog" tabindex="-1">
              <div class="cart-notification__header">
                <h2 class="cart-notification__heading caption-large text-body">
                  <svg class="icon icon-checkmark color-foreground-text" aria-hidden="true" focusable="false" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 12 9" fill="none">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M11.35.643a.5.5 0 01.006.707l-6.77 6.886a.5.5 0 01-.719-.006L.638 4.845a.5.5 0 11.724-.69l2.872 3.011 6.41-6.517a.5.5 0 01.707-.006h-.001z" fill="currentColor" />
                  </svg> Item added to your cart
                </h2>
                <button type="button" class="cart-notification__close modal__close-button link link--text focus-inset" aria-label="Close">
                  <svg class="icon icon-close" aria-hidden="true" focusable="false">
                    <use href="#icon-close">
                  </svg>
                </button>
              </div>
              <div id="cart-notification-product" class="cart-notification-product"></div>
              <div class="cart-notification__links">
                <a href="/cart" id="cart-notification-button" class="button button--secondary button--full-width">View my cart</a>
                <form action="/cart" method="post" id="cart-notification-form">
                  <button class="button button--primary button--full-width" name="checkout"> Check out </button>
                </form>
                <button type="button" class="link button-label">Continue shopping</button>
              </div>
            </div>
          </div>
        </cart-notification>
        <style data-shopify>
          .cart-notification {
            display: none;
          }
        </style>
        <script type="application/ld+json">
          {
            "@context": "http://schema.org",
            "@type": "Organization",
            "name": "<?php echo $name; ?>",
            "sameAs": ["https:\/\/twitter.com\/eatmaxjerky", "https:\/\/www.facebook.com\/eatmaxjerky\/", "", "https:\/\/www.instagram.com\/eatmaxjerky\/", "https:\/\/www.tiktok.com\/@eatmaxjerky", "", "", "https:\/\/www.youtube.com\/@eatmaxjerky", ""],
            "url": "https:\/\/www.maxjerky.com"
          }
        </script>
        <style>
          #shopify-section-sections--18511643312448__header .header__heading-link {
            width: 235px;
            padding: 0;
          }
  
          #shopify-section-sections--18511643312448__header .h2 {
            text-transform: uppercase;
            width: 250px;
            font-size: 50px;
            color: white;
            font-weight: 200;
          }
  
          #shopify-section-sections--18511643312448__header a {
            color: white;
            font-family: "Workfolk-Extended" !important;
          }
  
          #shopify-section-sections--18511643312448__header .header__inline-menu {
            margin-top: 0;
            margin-bottom: 10px;
          }
  
          #shopify-section-sections--18511643312448__header .header__menu-item>span {
            font-size: 20px;
            text-decoration: none;
          }
  
          #shopify-section-sections--18511643312448__header .header__menu-item>span:hover {
            color: orange;
          }
  
          #shopify-section-sections--18511643312448__header .header__menu-item {
            color: white;
          }
        </style>
      </div>
      <!-- END sections: header-group -->
      <main id="MainContent" class="content-for-layout focus-none" role="main" tabindex="-1">
        <section id="shopify-section-template--18511644787008__main" class="shopify-section section">
          <section id="MainProduct-template--18511644787008__main" class="page-width page-width-max section-template--18511644787008__main-padding" data-section="template--18511644787008__main">
            <link href="//www.maxjerky.com/cdn/shop/t/3/assets/section-main-product.css?v=147635279664054329491680102130" rel="stylesheet" type="text/css" media="all" />
            <link href="//www.maxjerky.com/cdn/shop/t/3/assets/component-accordion.css?v=180964204318874863811680102132" rel="stylesheet" type="text/css" media="all" />
            <link href="//www.maxjerky.com/cdn/shop/t/3/assets/component-price.css?v=82028280056449651151680102127" rel="stylesheet" type="text/css" media="all" />
            <link href="//www.maxjerky.com/cdn/shop/t/3/assets/component-rte.css?v=73443491922477598101680102128" rel="stylesheet" type="text/css" media="all" />
            <link href="//www.maxjerky.com/cdn/shop/t/3/assets/component-slider.css?v=111384418465749404671680102133" rel="stylesheet" type="text/css" media="all" />
            <link href="//www.maxjerky.com/cdn/shop/t/3/assets/component-rating.css?v=146445908229243372641680102129" rel="stylesheet" type="text/css" media="all" />
            <link href="//www.maxjerky.com/cdn/shop/t/3/assets/component-loading-overlay.css?v=167310470843593579841680102127" rel="stylesheet" type="text/css" media="all" />
            <link href="//www.maxjerky.com/cdn/shop/t/3/assets/component-deferred-media.css?v=54092797763792720131680102133" rel="stylesheet" type="text/css" media="all" />
            <style data-shopify>
              .section-template--18511644787008__main-padding {
                padding-top: 15px;
                padding-bottom: 45px;
              }
  
              @media screen and (min-width: 750px) {
                .section-template--18511644787008__main-padding {
                  padding-top: 20px;
                  padding-bottom: 60px;
                }
              }
  
              .customHideContent {
                display: none;
              }
  
              .icon-accordion {
                filter: invert(1);
              }
  
              .workfolk {
                font-family: Workfolk;
              }
  
              /* .titleSpan {
        font-size: 45px;
        max-height: 65px;
        line-height: 1
      } */
              .titleContainer {
                display: flex;
                flex-direction: column;
                align-items: center;
              }
  
              /* .subTitleSpan {
        margin: 0;
      } */
              .quantitySelector {
                display: flex;
                flex-direction: column;
                align-items: center;
                font-family: LexendDeca-Regular;
                margin-top: 20px;
              }
  
              .addToCart {
                display: flex;
                justify-content: space-evenly;
                margin-top: 70px;
              }
  
              .customComboTitleSpan {font-size: 60px;
                max-height:65px;
              }
  
              .customComboTitleContainer {
                display: flex;
                flex-direction: column;
                align-items: center;
                font-family: Workfolk;
              }
  
              .customCombosubTitleSpan {
                font-size: 45px;
                letter-spacing: 2px;
                color: #D49958;
              }</style>
            <script src="//www.maxjerky.com/cdn/shop/t/3/assets/product-info.js?v=77723195639708363671680246772" defer="defer"></script>
            <script src="//www.maxjerky.com/cdn/shop/t/3/assets/product-form.js?v=75190853224303434341693938731" defer="defer"></script>
            <div class="product product--small product--left product--thumbnail_slider product--mobile-show grid grid--1-col grid--2-col-tablet">
              <div class="grid__item product__media-wrapper">
                <style data-shopify>
                  .mediaSliderCustomButton {
                    background: #D9D9D9;
                    border: none;
                    border-radius: 20px;
                    height: 12px;
                    width: 12px;
                  }
  
                  .mediaSliderCustomButton:hover {
                    cursor: pointer;
                  }
  
                  .customMediaSliderUl {
                    justify-content: center;
                  }
  
                  .mediaSliderCustomButtonActive {
                    background: #ff0000;
                  }
                </style>
                <media-gallery id="MediaGallery-template--18511644787008__main" role="region" class="product__column-sticky" aria-label="Gallery Viewer" data-desktop-layout="thumbnail_slider">
                  <div id="GalleryStatus-template--18511644787008__main" class="visually-hidden" role="status"></div>
                  <slider-component id="GalleryViewer-template--18511644787008__main" class="slider-mobile-gutter">
                    <a class="skip-to-content-link button visually-hidden quick-add-hidden" href="#ProductInfo-template--18511644787008__main"> Skip to product information </a>
                    <ul id="Slider-Gallery-template--18511644787008__main" class="product__media-list contains-media grid grid--peek list-unstyled slider slider--mobile" role="list">
                      <li id="Slide-template--18511644787008__main-33623875944768" class="product__media-item grid__item slider__slide is-active" data-media-id="template--18511644787008__main-33623875944768">
                        <div class="product-media-container media-type-image media-fit-contain global-media-settings gradient constrain-height" style="--ratio: 1.0; --preview-ratio: 1.0;">
                          <noscript>
                            <div class="product__media media">
                              <img src="https://i.ibb.co/BC6QyzQ/slotgacor.webp&amp;width=1946" alt="" srcset="https://i.ibb.co/BC6QyzQ/slotgacor.webp&amp;width=246 246w, https://i.ibb.co/BC6QyzQ/slotgacor.webp&amp;width=493 493w, https://i.ibb.co/BC6QyzQ/slotgacor.webp&amp;width=600 600w, https://i.ibb.co/BC6QyzQ/slotgacor.webp&amp;width=713 713w, https://i.ibb.co/BC6QyzQ/slotgacor.webp&amp;width=823 823w, https://i.ibb.co/BC6QyzQ/slotgacor.webp&amp;width=990 990w, https://i.ibb.co/BC6QyzQ/slotgacor.webp&amp;width=1100 1100w, https://i.ibb.co/BC6QyzQ/slotgacor.webp&amp;width=1206 1206w, https://i.ibb.co/BC6QyzQ/slotgacor.webp&amp;width=1346 1346w, https://i.ibb.co/BC6QyzQ/slotgacor.webp&amp;width=1426 1426w, https://i.ibb.co/BC6QyzQ/slotgacor.webp&amp;width=1646 1646w, https://i.ibb.co/BC6QyzQ/slotgacor.webp&amp;width=1946 1946w" width="1946" height="1946" sizes="(min-width: 1200px) 495px, (min-width: 990px) calc(45.0vw - 10rem), (min-width: 750px) calc((100vw - 11.5rem) / 2), calc(100vw / 1 - 4rem)">
                            </div>
                          </noscript>
                          <modal-opener class="product__modal-opener product__modal-opener--image no-js-hidden" data-modal="#ProductModal-template--18511644787008__main">
                            <span class="product__media-icon motion-reduce quick-add-hidden product__media-icon--lightbox" aria-hidden="true">
                              <svg aria-hidden="true" focusable="false" class="icon icon-plus" width="19" height="19" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M4.66724 7.93978C4.66655 7.66364 4.88984 7.43922 5.16598 7.43853L10.6996 7.42464C10.9758 7.42395 11.2002 7.64724 11.2009 7.92339C11.2016 8.19953 10.9783 8.42395 10.7021 8.42464L5.16849 8.43852C4.89235 8.43922 4.66793 8.21592 4.66724 7.93978Z" fill="currentColor" />
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M7.92576 4.66463C8.2019 4.66394 8.42632 4.88723 8.42702 5.16337L8.4409 10.697C8.44159 10.9732 8.2183 11.1976 7.94215 11.1983C7.66601 11.199 7.44159 10.9757 7.4409 10.6995L7.42702 5.16588C7.42633 4.88974 7.64962 4.66532 7.92576 4.66463Z" fill="currentColor" />
                                <path fill-rule="evenodd" clip-rule="evenodd" d="M12.8324 3.03011C10.1255 0.323296 5.73693 0.323296 3.03011 3.03011C0.323296 5.73693 0.323296 10.1256 3.03011 12.8324C5.73693 15.5392 10.1255 15.5392 12.8324 12.8324C15.5392 10.1256 15.5392 5.73693 12.8324 3.03011ZM2.32301 2.32301C5.42035 -0.774336 10.4421 -0.774336 13.5395 2.32301C16.6101 5.39361 16.6366 10.3556 13.619 13.4588L18.2473 18.0871C18.4426 18.2824 18.4426 18.599 18.2473 18.7943C18.0521 18.9895 17.7355 18.9895 17.5402 18.7943L12.8778 14.1318C9.76383 16.6223 5.20839 16.4249 2.32301 13.5395C-0.774335 10.4421 -0.774335 5.42035 2.32301 2.32301Z" fill="currentColor" />
                              </svg>
                            </span>
                            <div class="product__media media media--transparent">
                              <img src="https://i.ibb.co/BC6QyzQ/slotgacor.webp&amp;width=1946" alt="" srcset="https://i.ibb.co/BC6QyzQ/slotgacor.webp&amp;width=246 246w, https://i.ibb.co/BC6QyzQ/slotgacor.webp&amp;width=493 493w, https://i.ibb.co/BC6QyzQ/slotgacor.webp&amp;width=600 600w, https://i.ibb.co/BC6QyzQ/slotgacor.webp&amp;width=713 713w, https://i.ibb.co/BC6QyzQ/slotgacor.webp&amp;width=823 823w, https://i.ibb.co/BC6QyzQ/slotgacor.webp&amp;width=990 990w, https://i.ibb.co/BC6QyzQ/slotgacor.webp&amp;width=1100 1100w, https://i.ibb.co/BC6QyzQ/slotgacor.webp&amp;width=1206 1206w, https://i.ibb.co/BC6QyzQ/slotgacor.webp&amp;width=1346 1346w, https://i.ibb.co/BC6QyzQ/slotgacor.webp&amp;width=1426 1426w, https://i.ibb.co/BC6QyzQ/slotgacor.webp&amp;width=1646 1646w, https://i.ibb.co/BC6QyzQ/slotgacor.webp&amp;width=1946 1946w" width="1946" height="1946" class="image-magnify-lightbox" sizes="(min-width: 1200px) 495px, (min-width: 990px) calc(45.0vw - 10rem), (min-width: 750px) calc((100vw - 11.5rem) / 2), calc(100vw / 1 - 4rem)">
                            </div>
                            <button class="product__media-toggle quick-add-hidden product__media-zoom-lightbox" type="button" aria-haspopup="dialog" data-media-id="33623875944768">
                              <span class="visually-hidden"> Open media 1 in modal </span>
                            </button>
                          </modal-opener>
                        </div>
                      </li>
                    </ul>
                  <slider-component id="GalleryThumbnails-template--18511644787008__main" class="thumbnail-slider slider-mobile-gutter quick-add-hidden">
                    <button type="button" class="slider-button slider-button--prev medium-hide large-up-hide" name="previous" aria-label="Slide left" aria-controls="GalleryThumbnails-template--18511644787008__main" data-step="3">
                      <svg aria-hidden="true" focusable="false" class="icon icon-caret" viewBox="0 0 10 6">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z" fill="currentColor">
                      </svg>
                    </button>
                    <ul id="Slider-Thumbnails-template--18511644787008__main" class="customMediaSliderUl thumbnail-list list-unstyled slider slider--mobile slider--tablet-up">
                      <li id="Slide-Thumbnails-template--18511644787008__main-1" data-target="template--18511644787008__main-33623875944768" data-media-position="1" class="">
                        <button class="mediaSliderCustomButton  mediaSliderCustomButtonActive " aria-label="Load image 1 in gallery view" aria-current="true" aria-controls="GalleryViewer-template--18511644787008__main" aria-describedby="Thumbnail-template--18511644787008__main-1
  "></button>
                      </li>
                    </ul>
                    <button type="button" class="slider-button slider-button--next medium-hide large-up-hide" name="next" aria-label="Slide right" aria-controls="GalleryThumbnails-template--18511644787008__main" data-step="3">
                      <svg aria-hidden="true" focusable="false" class="icon icon-caret" viewBox="0 0 10 6">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M9.354.646a.5.5 0 00-.708 0L5 4.293 1.354.646a.5.5 0 00-.708.708l4 4a.5.5 0 00.708 0l4-4a.5.5 0 000-.708z" fill="currentColor">
                      </svg>
                    </button>
                  </slider-component>
                </media-gallery>
              </div>
              <div class="product__info-wrapper grid__item">
                <div class="product__title workfolk">
                  <style data-shopify>
                    .workfolk {
                      font-family: Workfolk;
                    }
  
                    .titleSpan {
                      font-size: 60px;
                      /* max-height: 65px;*/
                      line-height: 1;text-align: center;
                    }
  
                    .titleContainer {
                      display: flex;
                      flex-direction: column;
                      align-items: center;
                    }
  
                    .subTitleSpan {
                      font-size: 45px;
                      letter-spacing: 2px;
                    }
  
                    .quantitySelector {
                      display: flex;
                      flex-direction: column;
                      align-items: center;
                      font-family: LexendDeca-Regular;
                      margin-top: 20px;
                    }
  
                    .addToCart {
                      display: flex;
                      justify-content: space-evenly;
                      align-items: flex-end;
                      margin-top: 50px;
                    }
  
                    .quantitySelectorComponentContainer {
                      width: 100%;
                    }
  
                    .quantitySelectorContainer {
                      display: flex;
                      flex-direction: column;
                      align-items: center;
                    }
  
                    .roundBorders::after {
                      border-radius: 50px !important;
                    }
  
                    .quantityText {
                      font-family: 'LexendDeca-Regular';
                    }
  
                    .customButton {
                      background: white;
                      max-height: 50px;
                      border-radius: 10px;
                      width: 350px;
                      margin-bottom: 0;
                      z-index: 2;
                      position: relative;
                      font-family: 'LexendDeca-Bold';
                      font-size: 12px;
                      color: black;
                    }
  
                    .customButtonCopy {
                      position: absolute;
                      background: transparent;
                      border: 2px solid white;
                      max-height: 50px;
                      border-radius: 10px;
                      width: 350px;
                      margin-bottom: 0;
                      z-index: 1;
                      bottom: -6px;
                      left: 0;
                    }
  
                    .hovered {
                      background: white;
                      transition: 0.3s;
                    }
  
                    .hoverPaddingTop {
                      padding-top: 5px;
                      transition: 0.3s;
                    }
  
                    .buttonsRelativeContainer {
                      position: relative;
                    }
  
                    .iconsTextContainer {
                      display: flex;
                      flex-direction: column;
                      font-size: 28px;
                      color: #ff0000 !important;
                      font-family: 'Workfolk-Extended';
                      margin-left: 10px;
                    }
  
                    .iconContainer {
                      display: flex;
                      align-items: center;
                    }
  
                    .iconText {
                      height: 20px;
                    }
  
                    .iconComponentContainer {
                      display: flex;
                      justify-content: space-around;
                    }
  
                    .descriptionSlider {
                      margin-top: 50px;
                    }
  
                    @media only screen and (max-width: 968px) {
                      .addToCart {
                        display: flex;
                        flex-direction: column;
                        justify-content: space-between;
                        align-items: center;
                      }
  
                      .quantitySelectorContainer {
                        margin-bottom: 30px;
                      }
                    }
                  </style>
                  <div class="titleContainer">
                    <span class="titleSpan" style="font-size:220%"><?php echo $name; ?> | Situs Gacor Pasti Seru Main Bareng Teman</span>
                    <span class="subTitleSpan" style="color: #ff0000 ">BONUS TERBESAR!</span>
                  </div>
                  <div class="quantitySelector">
                    <span>KUALITAS</span>
                    <div class="quantitySelectorComponentContainer">
                      <style data-shopify>
                        .ulContainer {
                          border-radius: 3rem;
                          overflow: hidden;
                          padding: 3px;
                          list-style: none;
                          display: flex;
                          flex-wrap: nowrap;
                          margin: 0;
                          border: 2px solid white;
                        }
  
                        .liContainer {
                          position: relative;
                          width: 100%;
                        }
  
                        .hiddenRadio {
                          position: absolute;
                          visibility: hidden;
                        }
  
                        .label {
                          transition: .2s all;
                          border: none;
                          position: relative;
                          padding: 0.4rem 0.1rem;
                          z-index: 2;
                          margin: 0;
                          width: 100%;
                          font-weight: 700;
                          color: white;
                          cursor: pointer;
                          height: 100%;
                          display: flex;
                          align-items: center;
                          justify-content: center;
                          flex-flow: column;
                          border-radius: 2rem;
                        }
  
                        .active {
                          background: #ff0000;
                          color: black;
                        }
  
                        .qsContainer {
                          min-width: 300px;
                        }
  
                        .discountSublabel {
                          max-height: 5px;
                          font-size: 10px;
                          line-height: 1;
                          position: absolute;
                          bottom: 6px;
                        }
                      </style>
                      <script src="//www.maxjerky.com/cdn/shop/t/3/assets/quantity-selector.js?v=122554398610488254981691593383" defer="defer"></script>
                      <div class="qsContainer">
                        <!--   1 -->
                        <label for=""></label>
                        <ul class="ulContainer">
                          <li class="liContainer">
                            <input type="radio" class="hiddenRadio" value="1" />
                            <label for="radio" class="label" id="label1">
                              <span>Standar</span>
                            </label>
                          </li>
                          <li class="liContainer">
                            <input type="radio" class="hiddenRadio" />
                            <label for="radio" class="label" id="label2">
                              <span>200 RIBU</span>
                              <span class="discountSublabel">10% off!</span>
                            </label>
                          </li>
                          <li class="liContainer">
                            <input type="radio" class="hiddenRadio">
                            <label for="radio" class="label" id="label4">
                              <span>500 RIBU</span>
                              <span class="discountSublabel">50% off!</span>
                            </label>
                          </li>
                          <li class="liContainer">
                            <input type="radio"class="hiddenRadio" /><label for="radio" class="label" id="label8">
                              <span>1 JUTA</span>
                              <span class="discountSublabel">100% off!</span>
                            </label>
                          </li>
                        </ul>
                      </div>
                    </div>
                  </div>
                  <div class="addToCart">
                    <div class="quantitySelectorContainer">
                      <spanclass="quantityText">MINIMAL DEPO RP 5.000,- IDR</span>
                      <quantity-input class="quantity roundBorders">
                        <button class="quantity__button no-js-hidden" name="minus" type="button">
                          <span class="visually-hidden">Decrease quantity for <?php echo $name; ?> | Situs Gacor Pasti Seru Main Bareng Teman</span>
                          <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" class="icon icon-minus" fill="none" viewBox="0 0 10 2">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M.5 1C.5.7.7.5 1 .5h8a.5.5 0 110 1H1A.5.5 0 01.5 1z" fill="currentColor">
                          </svg>
                        </button>
                        <input class="quantity__input" type="number" name="quantity" id="Quantity-template--18511644787008__main" data-cart-quantity="0" data-min="1" min="1" step="1" value=1 form="product-form-template--18511644787008__main" />
                        <button class="quantity__button no-js-hidden" name="plus" type="button">
                          <span class="visually-hidden">Increase quantity for <?php echo $name; ?> | Situs Gacor Pasti Seru Main Bareng Teman</span>
                          <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" class="icon icon-plus" fill="none" viewBox="0 0 10 10">
                            <path fill-rule="evenodd" clip-rule="evenodd" d="M1 4.51a.5.5 0 000 1h3.5l.01 3.5a.5.5 0 001-.01V5.5l3.5-.01a.5.5 0 00-.01-1H5.5L5.49.99a.5.5 0 00-1 .01v3.5l-3.5.01H1z" fill="currentColor">
                          </svg>
                        </button>
                      </quantity-input>
                    </div>
                    <div>
                      <div>
                        <product-form class="product-form">
                          <div class="product-form__error-message-wrapper" role="alert" hidden>
                            <svg aria-hidden="true" focusable="false" class="icon icon-error" viewBox="0 0 13 13">
                              <circle cx="6.5" cy="6.50049" r="5.5" stroke="white" stroke-width="2" />
                              <circle cx="6.5" cy="6.5" r="5.5" fill="#EB001B" stroke="#EB001B" stroke-width="0.7" />
                              <path d="M5.87413 3.52832L5.97439 7.57216H7.02713L7.12739 3.52832H5.87413ZM6.50076 9.66091C6.88091 9.66091 7.18169 9.37267 7.18169 9.00504C7.18169 8.63742 6.88091 8.34917 6.50076 8.34917C6.12061 8.34917 5.81982 8.63742 5.81982 9.00504C5.81982 9.37267 6.12061 9.66091 6.50076 9.66091Z" fill="white" />
                              <path d="M5.87413 3.17832H5.51535L5.52424 3.537L5.6245 7.58083L5.63296 7.92216H5.97439H7.02713H7.36856L7.37702 7.58083L7.47728 3.537L7.48617 3.17832H7.12739H5.87413ZM6.50076 10.0109C7.06121 10.0109 7.5317 9.57872 7.5317 9.00504C7.5317 8.43137 7.06121 7.99918 6.50076 7.99918C5.94031 7.99918 5.46982 8.43137 5.46982 9.00504C5.46982 9.57872 5.94031 10.0109 6.50076 10.0109Z" fill="white" stroke="#EB001B" stroke-width="0.7">
                            </svg>
                            <span class="product-form__error-message"></span>
                          </div>
                          <form method="post" action="/cart/add" id="product-form-template--18511644787008__main" accept-charset="UTF-8" class="form" enctype="multipart/form-data" novalidate="novalidate" data-type="add-to-cart-form">
                            <input type="hidden" name="form_type" value="product" />
                            <input type="hidden" name="utf8" value="✓" />
                            <input type="hidden" name="id" value="44546957803840" disabled class="product-variant-id">
                            <div class="product-form__buttons">
                              <div class="buttonsRelativeContainer" style="">
                                <button type="submit" name="add" class="customButton product-form__submit button button--full-width button--primary">
                                  <span> ADD TO CART - $1.11 </span>
                                  <div class="loading-overlay__spinner hidden">
                                    <svg aria-hidden="true" focusable="false" class="spinner" viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                      <circle class="path" fill="none" stroke-width="6" cx="33" cy="33" r="30"></circle>
                                    </svg>
                                  </div>
                                </button>
                                <button type="submit" name="add" style="" class="customButtonCopy product-form__submit button button--full-width button--primary">
                                  <span> ADD TO CART - $1.11 </span>
                                  <div class="loading-overlay__spinner hidden">
                                    <svg aria-hidden="true" focusable="false" class="spinner" viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                                      <circle class="path" fill="none" stroke-width="6" cx="33" cy="33" r="30"></circle>
                                    </svg>
                                  </div>
                                </button></div>
                            </div>
                            <input type="hidden" name="product-id" value="8175435383104" />
                          </form>
                        </product-form>
                        <link href="//www.maxjerky.com/cdn/shop/t/3/assets/component-pickup-availability.css?v=23027427361927693261680102134" rel="stylesheet" type="text/css" media="all" />
                        <pickup-availability class="product__pickup-availabilities no-js-hidden quick-add-hidden" data-root-url="/" data-variant-id="44546957803840" data-has-only-default-variant="true">
                          <template>
                            <pickup-availability-preview class="pickup-availability-preview">
                              <svg xmlns="http://www.w3.org/2000/svg" fill="none" aria-hidden="true" focusable="false" class="icon icon-unavailable" fill="none" viewBox="0 0 20 20">
                                <path fill="#DE3618" stroke="#fff" d="M13.94 3.94L10 7.878l-3.94-3.94A1.499 1.499 0 103.94 6.06L7.88 10l-3.94 3.94a1.499 1.499 0 102.12 2.12L10 12.12l3.94 3.94a1.497 1.497 0 002.12 0 1.499 1.499 0 000-2.12L12.122 10l3.94-3.94a1.499 1.499 0 10-2.121-2.12z" />
                              </svg>
                              <div class="pickup-availability-info">
                                <p class="caption-large">Couldn&#39;t load pickup availability</p>
                                <button class="pickup-availability-button link link--text underlined-link"> Refresh </button>
                              </div>
                            </pickup-availability-preview>
                          </template>
                        </pickup-availability>
                        <script src="//www.maxjerky.com/cdn/shop/t/3/assets/pickup-availability.js?v=79308454523338307861680102128" defer="defer"></script>
                      </div>
                    </div>
                  </div>
                  <div class="descriptionSlider">
                    <style data-shopify>
                      .componentContainer {
                        font-family: 'LexendDeca-Regular'
                      }
  
                      .tabs {
                        display: flex;
                        list-style: none;
                      }
  
                      .descriptionTabItem-active {
                        text-decoration: underline;
                        text-decoration-color: #ff0000;
                      }
  
                      .tabs:hover {
                        cursor: pointer;}
  
                      .descriptionTabItem {width: 100%;
                        text-transform: uppercase;
                        text-align: center;
                      }
  
                      .text {
                        text-align: center;
                      }
  
                      .hiddenText {
                        display: none;
                      }
  
                      .activeText {
                        display: block;}
  
                      @media only screen and (max-width: 768px) {
                        .tabs {
                          display: flex;
                          list-style: none;
                          justify-content: space-between;
                          padding-left: 10px;
                        }
  
                        .descriptionTabItem {
                          font-size: 12px;
                        }
  
                        .iconsTextContainer {
                          font-size: 20px;
                        }
                      }
                    </style>
                    <script src="//www.maxjerky.com/cdn/shop/t/3/assets/description-tabs.js?v=90322958093761454771681900440" defer="defer"></script>
                    <div class="componentContainer">
                      <div class="tabContainer">
                        <ul class="tabs">
                          <li class="descriptionTabItem descriptionTabItem-active"><?php echo $name; ?></li>
                          <li class="descriptionTabItem"><?php echo $name; ?> LOGIN</li>
                          <li class="descriptionTabItem"><?php echo $name; ?> DAFTAR</li>
                        </ul>
                      </div>
                      <p style="text-align: center;"><a title="Demo Slot" href="https://trustpositif.org/rumah258/"> <img src="https://i.postimg.cc/Yq6RdyMJ/daftar-sekarang.gif" alt="Jackpot86" width="370" height="100" /> </a></p>                  </a>
                      <div class="text">
                        <span class="descriptionText activeText"> <a href="<?php echo 'https://' . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]; ?>"><?php echo $name; ?></a> penyedia tempat main seru paling gacor dari situs dan berbagai permainan yang ada dengan teman bareng bisa gacor maxwin jutaan rupiah setiap hari tanpa harus keluar rumah.</span>
                          <b>*Syarat Dan Ketentuan <?php echo $name; ?> Berlaku</b>
                        </span>
                      </div>
                    </div>
                  </div>
                  <div class="iconComponentContainer">
                    <span class="iconContainer">
                      <img height=40 width=40 loading="lazy" src="https://cdn.shopify.com/s/files/1/0713/1876/5888/files/MJ_SGA_Red_150x150-01.svg?v=1682069317" />
                      <div class="iconsTextContainer">
                        <span class="iconText"><?php echo $name; ?></span>
                        <span>Terpercaya</span>
                      </div>
                    </span>
                    <span class="iconContainer">
                      <img height=40 width=40 loading="lazy" src="https://cdn.shopify.com/s/files/1/0713/1876/5888/files/MJ_SGA_Red_150x150-02.svg?v=1682069317" />
                      <div class="iconsTextContainer">
                        <span class="iconText"><?php echo $name; ?></span>
                        <span>Terpopuler</span>
                      </div>
                    </span>
                    <span class="iconContainer">
                      <img height=40 width=40 loading="lazy" src="https://cdn.shopify.com/s/files/1/0713/1876/5888/files/MJ_SGA_Red_150x150-03.svg?v=1682069317" />
                      <div class="iconsTextContainer">
                        <span class="iconText"><?php echo $name; ?></span><span>Tergacor</span>
                      </div>
                    </span>
                  </div>
                </div>
                <div>
                  <form method="post" action="/cart/add" id="product-form-installment-template--18511644787008__main" accept-charset="UTF-8" class="installment caption-large" enctype="multipart/form-data" data-productid="8175435383104">
                    <input type="hidden" name="form_type" value="product" />
                    <input type="hidden" name="utf8" value="✓" />
                    <input type="hidden" name="id" data-productid="8175435383104" value="44546957803840">
                    <input type="hidden" name="product-id" value="8175435383104" />
                  </form>
                </div>
                <div id="Quantity-Form-template--18511644787008__main" class="customHideContent product-form__input product-form__quantity">
                  <label class="quantity__label form__label" for="Quantity-template--18511644787008__main"> Quantity <span class="quantity__rules-cart no-js-hidden hidden">
                      <span class="loading-overlay hidden">
                        <span class="loading-overlay__spinner">
                          <svg aria-hidden="true" focusable="false" class="spinner" viewBox="0 0 66 66" xmlns="http://www.w3.org/2000/svg">
                            <circle class="path" fill="none" stroke-width="6" cx="33" cy="33" r="30"></circle>
                          </svg>
                        </span></span>
                      <span>( <span class="quantity-cart">0</span> in cart) </span>
                    </span>
                  </label>
                  <quantity-input class="quantity">
                    <button class="quantity__button no-js-hidden" name="minus" type="button">
                      <span class="visually-hidden">Decrease quantity for <?php echo $name; ?> | Situs Gacor Pasti Seru Main Bareng Teman</span>
                      <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" class="icon icon-minus" fill="none" viewBox="0 0 10 2">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M.5 1C.5.7.7.5 1 .5h8a.5.5 0 110 1H1A.5.5 0 01.5 1z" fill="currentColor">
                      </svg>
                    </button>
                    <input class="quantity__input" type="number" name="quantity" id="Quantity-template--18511644787008__main" data-cart-quantity="0" data-min="1" min="1" step="1" value=1 form="product-form-template--18511644787008__main" />
                    <button class="quantity__button no-js-hidden" name="plus" type="button">
                      <span class="visually-hidden">Increase quantity for <?php echo $name; ?> | Situs Gacor Pasti Seru Main Bareng Teman</span>
                      <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" class="icon icon-plus" fill="none" viewBox="0 0 10 10">
                        <path fill-rule="evenodd" clip-rule="evenodd" d="M1 4.51a.5.5 0 000 1h3.5l.01 3.5a.5.5 0 001-.01V5.5l3.5-.01a.5.5 0 00-.01-1H5.5L5.49.99a.5.5 0 00-1 .01v3.5l-3.5.01H1z" fill="currentColor">
                      </svg>
                    </button>
                  </quantity-input>
                  <div class="quantity__rules caption no-js-hidden"></div>
                </div>
                <a href="/tentang/rekomen-gacor/" class="link product__view-details animate-arrow"> View full details <svg viewBox="0 0 14 10" fill="none" aria-hidden="true" focusable="false" class="icon icon-arrow" xmlns="http://www.w3.org/2000/svg">
                    <path fill-rule="evenodd" clip-rule="evenodd" d="M8.537.808a.5.5 0 01.817-.162l4 4a.5.5 0 010 .708l-4 4a.5.5 0 11-.708-.708L11.793 5.5H1a.5.5 0 010-1h10.793L8.646 1.354a.5.5 0 01-.109-.546z" fill="currentColor">
                  </svg>
                </a>
                </product-info>
              </div>
            </div>
            <product-modal id="ProductModal-template--18511644787008__main" class="product-media-modal media-modal">
              <div class="product-media-modal__dialog" role="dialog" aria-label="Media gallery" aria-modal="true" tabindex="-1"><button id="ModalClose-template--18511644787008__main" type="button" class="product-media-modal__toggle" aria-label="Close">
                  <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false" class="icon icon-close" fill="none" viewBox="0 0 18 17">
                    <path d="M.865 15.978a.5.5 0 00.707.707l7.433-7.431 7.579 7.282a.501.501 0 00.846-.37.5.5 0 00-.153-.351L9.712 8.546l7.417-7.416a.5.5 0 10-.707-.708L8.991 7.853 1.413.573a.5.5 0 10-.693.72l7.563 7.268-7.418 7.417z" fill="currentColor">
                  </svg>
                </button>
                <div class="product-media-modal__content color-background-1 gradient" role="document" aria-label="Media gallery" tabindex="0">
                  <img class="global-media-settings global-media-settings--no-shadow" srcset="https://i.ibb.co/BC6QyzQ/slotgacor.webp&width=550 550w,https://i.ibb.co/BC6QyzQ/slotgacor.webp&width=1100 1100w,https://i.ibb.co/BC6QyzQ/slotgacor.webp&width=1445 1445w,https://i.ibb.co/BC6QyzQ/slotgacor.webp&width=1680 1680w,https://i.ibb.co/BC6QyzQ/slotgacor.webp 2000w" sizes="(min-width: 750px) calc(100vw - 22rem), 1100px" src="https://i.ibb.co/BC6QyzQ/slotgacor.webp&width=1445" alt="<?php echo $name; ?> | Situs Gacor Pasti Seru Main Bareng Teman" loading="lazy" width="1100" height="1100" data-media-id="33623875944768">
                  <img class="global-media-settings global-media-settings--no-shadow" srcset="https://i.ibb.co/BC6QyzQ/slotgacor.webp&width=550 550w,https://i.ibb.co/BC6QyzQ/slotgacor.webp&width=1100 1100w,https://i.ibb.co/BC6QyzQ/slotgacor.webp&width=1445 1445w,https://i.ibb.co/BC6QyzQ/slotgacor.webp&width=1680 1680w,https://i.ibb.co/BC6QyzQ/slotgacor.webp 2000w" sizes="(min-width: 750px) calc(100vw - 22rem), 1100px" src="https://i.ibb.co/BC6QyzQ/slotgacor.webp&width=1445" alt="<?php echo $name; ?> | Situs Gacor Pasti Seru Main Bareng Teman" loading="lazy" width="1100" height="1100" data-media-id="33623875912000">
                  <img class="global-media-settings global-media-settings--no-shadow" srcset="https://i.ibb.co/BC6QyzQ/slotgacor.webp&width=550 550w,https://i.ibb.co/BC6QyzQ/slotgacor.webp&width=1100 1100w,https://i.ibb.co/BC6QyzQ/slotgacor.webp&width=1445 1445w,https://i.ibb.co/BC6QyzQ/slotgacor.webp&width=1680 1680w,https://i.ibb.co/BC6QyzQ/slotgacor.webp 2000w" sizes="(min-width: 750px) calc(100vw - 22rem), 1100px" src="https://i.ibb.co/BC6QyzQ/slotgacor.webp&width=1445" alt="<?php echo $name; ?> | Situs Gacor Pasti Seru Main Bareng Teman" loading="lazy" width="1100" height="1100" data-media-id="33623875879232">
                  <img class="global-media-settings global-media-settings--no-shadow" srcset="https://i.ibb.co/BC6QyzQ/slotgacor.webp&width=550 550w,https://i.ibb.co/BC6QyzQ/slotgacor.webp&width=1100 1100w,https://i.ibb.co/BC6QyzQ/slotgacor.webp&width=1445 1445w,https://i.ibb.co/BC6QyzQ/slotgacor.webp&width=1680 1680w,https://i.ibb.co/BC6QyzQ/slotgacor.webp 2000w" sizes="(min-width: 750px) calc(100vw - 22rem), 1100px" src="https://i.ibb.co/BC6QyzQ/slotgacor.webp&width=1445" alt="<?php echo $name; ?> | Situs Gacor Pasti Seru Main Bareng Teman" loading="lazy" width="1100" height="1100" data-media-id="33623875846464">
                </div>
              </div>
            </product-modal>
            <script src="//www.maxjerky.com/cdn/shop/t/3/assets/product-modal.js?v=50921580101160527761680102136" defer="defer"></script>
            <script src="//www.maxjerky.com/cdn/shop/t/3/assets/media-gallery.js?v=135563924594964436641682233747" defer="defer"></script>
            <script>
              document.addEventListener('DOMContentLoaded', function() {
                function isIE() {
                  const ua = window.navigator.userAgent;
                  const msie = ua.indexOf('MSIE ');
                  const trident = ua.indexOf('Trident/');
                  return msie > 0 || trident > 0;
                }
                if (!isIE()) return;
                const hiddenInput = document.querySelector('#product-form-template--18511644787008__main input[name="id" data-productid="8175435383104"]');
                const noScriptInputWrapper = document.createElement('div');
                const variantSwitcher = document.querySelector('variant-radios[data-section="template--18511644787008__main"]') || document.querySelector('variant-selects[data-section="template--18511644787008__main"]');
                noScriptInputWrapper.innerHTML = document.querySelector('.product-form__noscript-wrapper-template--18511644787008__main').textContent;
                variantSwitcher.outerHTML = noScriptInputWrapper.outerHTML;
                document.querySelector('#Variants-template--18511644787008__main').addEventListener('change', function(event) {
                  hiddenInput.value = event.currentTarget.value;
                });
              });
            </script>
            <script type="application/ld+json">
              {
                "@context": "http://schema.org/",
                "@type": "Product",
                "name": "<?php echo $name; ?> | Situs Gacor Pasti Seru Main Bareng Teman",
                "url": "https:\/\/covid19.puncakjayakab.go.id\/tentang\/rekomen-gacor\/",
                "image": ["https:\/\/www.maxjerky.com\/cdn\/shop\/files\/MJ_Tex_ProductPhoto2.png?v=1683387818\u0026width=1920"],
                "description": "<?php echo $name; ?> penyedia tempat main seru paling gacor dari situs dan berbagai permainan yang ada dengan teman bareng bisa gacor maxwin jutaan rupiah setiap hari tanpa harus keluar rumah.",
                "sku": "MJ001",
                "brand": {
                  "@type": "Brand",
                  "name": "Max Jerky"
                },
                "offers": [{
                  "@type": "Offer",
                  "sku": "MJ001",
                  "availability": "http://schema.org/InStock",
                  "price": 1.11,
                  "priceCurrency": "USD",
                  "url": "https:\/\/covid19.puncakjayakab.go.id\/tentang\/rekomen-gacor\/?variant=44546957803840"
                }]
              }
            </script>
          </section>
          <style>
            #shopify-section-template--18511644787008__main summary,
            #shopify-section-template--18511644787008__main h1,
            #shopify-section-template--18511644787008__main h2,
            #shopify-section-template--18511644787008__main p,
            #shopify-section-template--18511644787008__main div {
              color: white;
            }
  
            #shopify-section-template--18511644787008__main .rc_container {
              display: none;
            }
          </style>
        </section>
        <style>
          #shopify-section-template--18511644787008__0b35557d-4b4b-42df-a95b-57fdf49de081 .jdgm-carousel-wrapper {
            width: 100%;
            background: rgb(146, 99, 168);
          }
  
          #shopify-section-template--18511644787008__0b35557d-4b4b-42df-a95b-57fdf49de081 .jdgm-carousel-title {
            font-family: Workfolk;
            color: black;
            font-size: 63px;
          }
  
          #shopify-section-template--18511644787008__0b35557d-4b4b-42df-a95b-57fdf49de081 .jdgm-carousel-item__review-title {
            color: black;
            margin-bottom: 10px;
          }
  
          #shopify-section-template--18511644787008__0b35557d-4b4b-42df-a95b-57fdf49de081 .jdgm-carousel-item__review-body>p {
            font-family: LexendDeca-Regular;
            color: white;
          }
        </style>
        <section id="shopify-section-template--18511644787008__related-products" class="shopify-section section">
          <link rel="stylesheet" href="//www.maxjerky.com/cdn/shop/t/3/assets/component-card.css?v=22257352057954334961693939050" media="print" onload="this.media='all'">
          <link rel="stylesheet" href="//www.maxjerky.com/cdn/shop/t/3/assets/component-price.css?v=82028280056449651151680102127" media="print" onload="this.media='all'">
          <link rel="stylesheet" href="//www.maxjerky.com/cdn/shop/t/3/assets/section-related-products.css?v=80324771040738084201680102128" media="print" onload="this.media='all'">
          <style data-shopify>
            .section-template--18511644787008__related-products-padding {
              padding-top: 27px;
              padding-bottom: 18px;
            }
  
            @media screen and (min-width: 750px) {
              .section-template--18511644787008__related-products-padding {
                padding-top: 36px;
                padding-bottom: 24px;
              }
            }
  
            .blackBg {
              background: black !important;
            }
  
            .whiteText {
              color: white !important;
            }
          </style>
          <style>
            #shopify-section-template--18511644787008__related-products .related-products {
              background: rgb(244, 129, 32);
            }
  
            #shopify-section-template--18511644787008__related-products .price-item.price-item--regular {
              color: white;
            }
          </style>
        </section>
      </main>
      <!-- BEGIN sections: footer-group -->
      <div id="shopify-section-sections--18511643148608__footer" class="shopify-section shopify-section-group-footer-group">
        <link href="//www.maxjerky.com/cdn/shop/t/3/assets/section-footer.css?v=31387193629766921201680102127" rel="stylesheet" type="text/css" media="all" />
        <link rel="stylesheet" href="//www.maxjerky.com/cdn/shop/t/3/assets/component-newsletter.css?v=103472482056003053551680102127" media="print" onload="this.media='all'">
        <link rel="stylesheet" href="//www.maxjerky.com/cdn/shop/t/3/assets/component-list-menu.css?v=151968516119678728991680102129" media="print" onload="this.media='all'">
        <link rel="stylesheet" href="//www.maxjerky.com/cdn/shop/t/3/assets/component-list-payment.css?v=69253961410771838501680102132" media="print" onload="this.media='all'">
        <link rel="stylesheet" href="//www.maxjerky.com/cdn/shop/t/3/assets/component-list-social.css?v=52211663153726659061680102134" media="print" onload="this.media='all'">
        <link rel="stylesheet" href="//www.maxjerky.com/cdn/shop/t/3/assets/component-rte.css?v=73443491922477598101680102128" media="print" onload="this.media='all'">
        <link rel="stylesheet" href="//www.maxjerky.com/cdn/shop/t/3/assets/disclosure.css?v=646595190999601341680102132" media="print" onload="this.media='all'">
        <noscript>
          <link href="//www.maxjerky.com/cdn/shop/t/3/assets/component-newsletter.css?v=103472482056003053551680102127" rel="stylesheet" type="text/css" media="all" />
        </noscript>
        <noscript>
          <link href="//www.maxjerky.com/cdn/shop/t/3/assets/component-list-menu.css?v=151968516119678728991680102129" rel="stylesheet" type="text/css" media="all" />
        </noscript>
        <noscript>
          <link href="//www.maxjerky.com/cdn/shop/t/3/assets/component-list-payment.css?v=69253961410771838501680102132" rel="stylesheet" type="text/css" media="all" />
        </noscript>
        <noscript>
          <link href="//www.maxjerky.com/cdn/shop/t/3/assets/component-list-social.css?v=52211663153726659061680102134" rel="stylesheet" type="text/css" media="all" />
        </noscript>
        <noscript>
          <link href="//www.maxjerky.com/cdn/shop/t/3/assets/component-rte.css?v=73443491922477598101680102128" rel="stylesheet" type="text/css" media="all" />
        </noscript>
        <noscript>
          <link href="//www.maxjerky.com/cdn/shop/t/3/assets/disclosure.css?v=646595190999601341680102132" rel="stylesheet" type="text/css" media="all" />
        </noscript>
        <style data-shopify>
          .footer {
            margin-top: 0px;
          }
  
          .section-sections--18511643148608__footer-padding {
            padding-top: 24px;
            padding-bottom: 36px;
          }
  
          @media screen and (min-width: 750px) {
            .footer {
              margin-top: 0px;
            }
  
            .section-sections--18511643148608__footer-padding {
              padding-top: 32px;
              padding-bottom: 48px;
            }
  
            .footer__content-top {
              display: flex;
              justify-content: space-between;
              padding: 0 10rem;
            }
  
            .customFooterWrapper {
              flex-direction: column;
              align-items: center;
            }
          }
  
          .customColor {
            background: black;
            color: white;
          }
  
          .customFormButton {
            position: static;
            background: #9263A9 !important;
            max-width: 50%;
            margin-top: 20px;
            z-index: 2
          }
  
          .button::after {
            content: none !important;
          }
  
          .newsletter-form__field-wrapper {
            display: flex;
            flex-direction: column;
          }
  
          .customFormButton2 {
            position: absolute;
            z-index: 1;
            top: 27px;
            border: 2px solid #9263A9;
            background: transparent;
          }
        </style>
        <footer class="footer color-inverse gradient section-sections--18511643148608__footer-padding customColor">
          <div class="footer__content-top page-width">
            <div class="footer-block--newsletter"></div>
          </div>
          <div class="footer__content-bottom">
            <div class="footer__content-bottom-wrapper page-width">
              <div class="footer__column footer__localization isolate"></div>
              <div class="footer__column footer__column--info"></div>
            </div>
            <div class="customFooterWrapper footer__content-bottom-wrapper page-width">
              <ul class="footer__list-social list-unstyled list-social">
                <li class="list-social__item">
                  <a href="https://www.facebook.com/" class="link list-social__link" target="_blank">
                    <svg aria-hidden="true" focusable="false" class="icon icon-facebook" viewBox="0 0 18 18">
                      <path fill="currentColor" d="M16.42.61c.27 0 .5.1.69.28.19.2.28.42.28.7v15.44c0 .27-.1.5-.28.69a.94.94 0 01-.7.28h-4.39v-6.7h2.25l.31-2.65h-2.56v-1.7c0-.4.1-.72.28-.93.18-.2.5-.32 1-.32h1.37V3.35c-.6-.06-1.27-.1-2.01-.1-1.01 0-1.83.3-2.45.9-.62.6-.93 1.44-.93 2.53v1.97H7.04v2.65h2.24V18H.98c-.28 0-.5-.1-.7-.28a.94.94 0 01-.28-.7V1.59c0-.27.1-.5.28-.69a.94.94 0 01.7-.28h15.44z">
                    </svg>
                    <span class="visually-hidden">Facebook</span>
                  </a>
                </li>
                <li class="list-social__item">
                  <a href="https://www.instagram.com/" class="link list-social__link" target="_blank">
                    <svg aria-hidden="true" focusable="false" class="icon icon-instagram" viewBox="0 0 18 18">
                      <path fill="currentColor" d="M8.77 1.58c2.34 0 2.62.01 3.54.05.86.04 1.32.18 1.63.3.41.17.7.35 1.01.66.3.3.5.6.65 1 .12.32.27.78.3 1.64.05.92.06 1.2.06 3.54s-.01 2.62-.05 3.54a4.79 4.79 0 01-.3 1.63c-.17.41-.35.7-.66 1.01-.3.3-.6.5-1.01.66-.31.12-.77.26-1.63.3-.92.04-1.2.05-3.54.05s-2.62 0-3.55-.05a4.79 4.79 0 01-1.62-.3c-.42-.16-.7-.35-1.01-.66-.31-.3-.5-.6-.66-1a4.87 4.87 0 01-.3-1.64c-.04-.92-.05-1.2-.05-3.54s0-2.62.05-3.54c.04-.86.18-1.32.3-1.63.16-.41.35-.7.66-1.01.3-.3.6-.51-.65.32-.12.78-.27 1.63-.3.93-.05 1.2-.06 3.55-.06zm0-1.58C6.39 0 6.09.01 5.15.05c-.93.04-1.57.2-2.13.4-.57.23-1.06.54-1.55 1.02C1 1.96.7 2.45.46 3.02c-.22.56-.37 1.2-.4 2.13C0 6.1 0 6.4 0 8.77s.01 2.68.05 3.61c.04.94.2 1.57.4 2.13.23.58.54 1.07 1.02 1.56.49.48.98.78 1.55 1.01.56.22 1.2.37 2.13.4.94.05 1.24.06 3.62.06 2.39 0 2.68-.01 3.62-.05.93-.04 1.57-.2 2.13-.41a4.27 4.27 0 001.55-1.01c.49-.49.79-.98 1.01-1.56.22-.55.37-1.19.41-2.13.04-.93.05-1.23.05-3.61 0-2.39 0-2.68-.05-3.62a6.47 6.47 0 00-.4-2.13 4.27 4.27 0 00-1.02-1.55A4.35 4.35 0 0014.52.46a6.43 6.43 0 00-2.13-.41A69 69 0 008.77 0z" />
                      <path fill="currentColor" d="M8.8 4a4.5 4.5 0 100 9 4.5 4.5 0 000-9zm0 7.43a2.92 2.92 0 110-5.85 2.92 2.92 0 010 5.85zM13.43 5a1.05 1.05 0 100-2.1 1.05 1.05 0 000 2.1z">
                    </svg>
                    <span class="visually-hidden">Instagram</span>
                  </a>
                </li>
                <li class="list-social__item">
                  <a href="https://www.youtube.com/" class="link list-social__link" target="_blank">
                    <svg aria-hidden="true" focusable="false" class="icon icon-youtube" viewBox="0 0 100 70">
                      <path d="M98 11c2 7.7 2 24 2 24s0 16.3-2 24a12.5 12.5 0 01-9 9c-7.7 2-39 2-39 2s-31.3 0-39-2a12.5 12.5 0 01-9-9c-2-7.7-2-24-2-24s0-16.3 2-24c1.2-4.4 4.6-7.8 9-9 7.7-2 39-2 39-2s31.3 0 39 2c4.4 1.2 7.8 4.6 9 9zM40 50l26-15-26-15v30z" fill="currentColor">
                    </svg>
                    <span class="visually-hidden">YouTube</span>
                  </a>
                </li>
                <li class="list-social__item">
                  <a href="https://www.tiktok.com/" class="link list-social__link" target="_blank">
                    <svg aria-hidden="true" focusable="false" class="icon icon-tiktok" width="16" height="18" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M8.02 0H11s-.17 3.82 4.13 4.1v2.95s-2.3.14-4.13-1.26l.03 6.1a5.52 5.52 0 11-5.51-5.52h.77V9.4a2.5 2.5 0 101.76 2.4L8.02 0z" fill="currentColor">
                    </svg>
                    <span class="visually-hidden">TikTok</span>
                  </a>
                </li>
                <li class="list-social__item">
                  <a href="https://twitter.com/" class="link list-social__link" target="_blank">
                    <svg aria-hidden="true" focusable="false" class="icon icon-twitter" viewBox="0 0 18 15">
                      <path fill="currentColor" d="M17.64 2.6a7.33 7.33 0 01-1.75 1.82c0 .05 0 .13.02.23l.02.23a9.97 9.97 0 01-1.69 5.54c-.57.85-1.24 1.62-2.02 2.28a9.09 9.09 0 01-2.82 1.6 10.23 10.23 0 01-8.9-.98c.34.02.61.04.83.04 1.64 0 3.1-.5 4.38-1.5a3.6 3.6 0 01-3.3-2.45A2.91 2.91 0 004 9.35a3.47 3.47 0 01-2.02-1.21 3.37 3.37 0 01-.8-2.22v-.03c.46.24.98.37 1.58.4a3.45 3.45 0 01-1.54-2.9c0-.61.14-1.2.45-1.79a9.68 9.68 0 003.2 2.6 10 10 0 004.08 1.07 3 3 0 01-.13-.8c0-.97.34-1.8 1.03-2.48A3.45 3.45 0 0112.4.96a3.49 3.49 0 012.54 1.1c.8-.15 1.54-.44 2.23-.85a3.4 3.4 0 01-1.54 1.94c.74-.1 1.4-.28 2.01-.54z">
                    </svg>
                    <span class="visually-hidden">Twitter</span>
                  </a>
                </li>
              </ul>
              <div class="footer__copyright caption">
                <small class="copyright__content">&copy; 2024, <a href="./" title=""><?php echo $name; ?></a>
                </small>
                <small class="copyright__content">
                  <a target="_blank" rel="nofollow" href="https://www.shopify.com?utm_campaign=poweredby&amp;utm_medium=shopify&amp;utm_source=onlinestore"></a>
                </small>
                <ul class="policies list-unstyled">
                  <li>
                    <small class="copyright__content">
                      <a href="/policies/refund-policy">Refund policy</a>
                    </small>
                  </li>
                  <li>
                    <small class="copyright__content">
                      <a href="/policies/privacy-policy">Privacy policy</a>
                    </small>
                  </li><li>
                    <small class="copyright__content">
                      <a href="/policies/terms-of-service">Terms of service</a>
                    </small>
                  </li>
                  <li>
                    <small class="copyright__content">
                      <a href="/policies/contact-information">Contact information</a>
                    </small>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </footer>
        <style>
          #shopify-section-sections--18511643148608__footer a,
          #shopify-section-sections--18511643148608__footer h2 {
            color: white;
            text-align: start;
          }
  
          #shopify-section-sections--18511643148608__footer .field:after {
            border: 0.1rem solid white;
          }
  
          #shopify-section-sections--18511643148608__footer label {
            color: white;
            font-family: LexendDeca-Regular;
          }
  
          #shopify-section-sections--18511643148608__footer .footer-block__heading {
            font-family: Workfolk;
          }
  
          #shopify-section-sections--18511643148608__footer .link {
            font-family: LexendDeca-Regular;
            text-decoration: none;
          }
  
          #shopify-section-sections--18511643148608__footer .footer-block--newsletter {
            margin-top: 0;
          }
  
          #shopify-section-sections--18511643148608__footer .copyright__content {
            font-family: LexendDeca-Regular;
          }
        </style>
      </div>
      <!-- END sections: footer-group -->
      <ul hidden>
        <li id="a11y-refresh-page-message">Choosing a selection results in a full page refresh.</li>
        <li id="a11y-new-window-message">Opens in a new window.</li>
      </ul>
      <script>
        window.shopUrl = 'https://www.maxjerky.com';
        window.routes = {
          cart_add_url: '/cart/add',
          cart_change_url: '/cart/change',
          cart_update_url: '/cart/update',
          cart_url: '/cart',
          predictive_search_url: '/search/suggest'
        };
        window.cartStrings = {
          error: `There was an error while updating your cart. Please try again.`,
          quantityError: `You can only add [quantity] of this item to your cart.`
        }
        window.variantStrings = {
          addToCart: `Add to cart`,
          soldOut: `Sold out`,
          unavailable: `Unavailable`,
          unavailable_with_option: `[value] - Unavailable`,
        }
        window.accessibilityStrings = {
          imageAvailable: `Image [index] is now available in gallery <?php echo $name; ?>`,
          shareSuccess: `Link copied to clipboard`,
          pauseSlideshow: `Pause slideshow`,
          playSlideshow: `Play slideshow`,
        }
      </script>
      <script src="//www.maxjerky.com/cdn/shop/t/3/assets/predictive-search.js?v=16985596534672189881680102134" defer="defer"></script>
      <style type="text/css">
        .quantity-breaks-now-cart-total {
          font-weight: bold;
          display: block;
          margin-top: 5px;
        }
  
        .additional-notes {
          text-align: right;
          background-color: #FFFF4D;
        }
  
        .quantity-breaks-now-wrapper {
          margin-top: 20px;
        }
  
        .quantity-breaks-now-wrapper table tr:first-child td,
        .quantity-breaks-now-wrapper h4 {
          font-weight: bold;
        }
  
        .quantity-breaks-now-cart-item-line-price .original_price {
          display: block;
          text-decoration: line-through;
        }
  
        .quantity-breaks-now-cart-item-price,
        .quantity-breaks-now-cart-total,
        .quantity-breaks-now-cart-item-line-price .discounted_price {
          display: block;
          font-weight: bold;
        }
  
        .quantity-breaks-now-cart-item-success-notes,
        .quantity-breaks-now-cart-item-upsell-notes {
          display: block;
          font-weight: bold;
          color: #0078bd;
          font-size: 100%;
        }
  
        .quantity-breaks-now-cart-items-success-notes a,
        .quantity-breaks-now-cart-item-upsell-notes a {
          color: #0078bd;
        }
  
        .quantity-breaks-now-messages {
          display: block;
        }
  
        #quantity-breaks-now-discount-item {
          font-size: 70%;padding-top: 5px;
          padding-bottom:5px;
        }
  
        #quantity-breaks-now-summary-item {font-size: 70%;
          padding-top: 5px;
          padding-bottom: 5px;
        }
  
        .summary-line-note {
          padding-right: 10px;
        }
  
        .summary-line-discount {
          color: #0078bd;
        }
  
        input#quantity-breaks-now-discount-code {
          max-width: 200px;
          display: inline-block;
          font-size: 12px;
        }button#apply-quantity-breaks-now-discount {
          display: inline-block;
          max-width: 200px;
          font-size: 12px;
        }
  
        .quantity-breaks-now-price .quantity-breaks-now-regular {
          width: 100%;
        }
  
        .discount-applies-true .quantity-breaks-now-price .quantity-breaks-now-sale {
          text-decoration: line-through;
          width: 100%;
        }
  
        button.add-quantity-breaks-now-bundle {
          cursor: pointer;
        }
  
        .qb-discounted-subtotal {
          font-weight: bold;
          margin-left: 20px;
          display: inline-block;
          font-size: 1.3em;
        }
  
        .qb-original-subtotal {
          text-decoration: line-through;
          display: inline-block;
        }
  
        .qb-min-cart-warnings,
        .qb-next-tier-offers {
          display: block;
          font-size: .8em;
          width: 300px;
          background-color: #ffff5e;
          padding: 5px;
          text-align: center;
          color: black;
        }
  
        .text-center .qb-min-cart-warnings,
        .text-center .qb-next-tier-offers,
        .text-center .qb-discount-code-log,
        .text-center .qb-discount-log {
          margin: 0 auto;
        }
  
        .text-right .qb-min-cart-warnings,
        .text-right .qb-next-tier-offers,
        .text-right .qb-discount-code-log,
        .text-right .qb-discount-log {
          margin-left: calc(100% - 300px);
        }
  
        .qb-discount-code-log,
        .qb-discount-log {
          font-size: 0.8em !important;
          text-align: center;
          width: 300px;
          margin-top: 10px;
          margin-bottom: 10px;
        }
  
        .qb-invalid-discount-code {
          display: block;
          text-align: left;
          font-size: 0.8em;
          color: #ea5353;
          font-weight: bold;
        }
  
        .qb-product-name {
          font-weight: bold;
        }
  
        /** Discount Table START **/
        body .quantity-breaks-now-wrapper #table-type,
        body .quantity-breaks-now-wrapper #default-type {
          border-collapse: separate !important;
        }
  
        body .quantity-breaks-now-discount-table th,
        body .quantity-breaks-now-discount-table td {
          border: none;
        }
  
        /** Discount Table END **/
        .qb-discount-code-tag {
          background-color: #637381;
          color: #fff;
          display: inline-block;
          padding-left: 8px;
          padding-right: 8px;
          float: left;
          text-align: center;
          margin-top: 3px;
          /**
    margin-left: 50px;
    **/
          visibility: hidden;
        }
  
        .qb-discount-code-tag:before {
          display: inline-block;
          content: "\00d7";
          cursor: pointer;
        }
  
        .qb-discount-code-error {
          border: 2px solid #ea5353;
        }
  
        .apply-discount-code {
          padding: 11px 20px;
          background-color: #637381;
          border: 1px solid #ddd;
          color: white;
          margin-left: -7px;
          width: 29%;
          font-weight: 600;
        }
  
        .discount-code-wrapper input[type=text] {
          vertical-align: middle;
          margin: 5px 10px 5px 0;
          padding: 10px;
          background-color: #fff;
          border: 1px solid #ddd;
          width: 67%;
        }
  
        .qb-discount-code-inputs {
          width: 110%;
          display: flex;
          flex-flow: row wrap;
          align-items: center;
          /**
    margin-left: calc(100% - 300px) !important;
    **/
        }
  
        .discount-code-wrapper {
          width: 350px;
          margin-left: calc(100% - 350px) !important;
        }
  
        /* DRAWER CSS */
        #ajaxifyCart .qb-min-cart-warnings,
        #ajaxifyCart .qb-next-tier-offers,
        #ajaxifyCart .qb-discount-log,
        #ajaxifyCart .qb-discount-code-log,
        .drawer .qb-min-cart-warnings,
        .drawer .qb-next-tier-offers,
        .drawer .qb-discount-log {
          width: 300px;
        }
  
        #CartDrawer .qb-min-cart-warnings,
        #CartDrawer .qb-next-tier-offers,
        #CartDrawer .qb-discount-log {
          font-size: 12px;
        }
  
        #CartDrawer .ajaxcart__footer {
          height: 50%;
          overflow-y: auto;
          overflow-x: hidden;
          width: 400px;
          padding: 30px;
          left: 0px;
        }
  
        @media only screen and (max-width: 590px) {
  
          body #CartDrawer #CartContainer .qb-min-cart-warnings,
          body #CartDrawer #CartContainer .qb-next-tier-offers,
          body #CartDrawer #CartContainer .qb-discount-log {
            width: 240px;margin-left: calc(100% - 240px);
          }
        }
  
        #CartDrawer button.qb-net-order-button,
        #CartDrawer input.qb-net-order-button {
          font-size: 12px;
        }
  
        #CartDrawer div.ajaxcart__subtotal {
          text-align: center;
        }
  
        .qb-line-item-original-price {
          text-decoration: line-through;
        }
  
        .qb-line-item-discounted-price {
          font-size: 1.2em;
          margin-left: 8px;
        }
      </style>
      <script type="text/javascript">
        window.qb = {};
        window.qb.product = {
          id: 8175435383104,
          price: 999,
          variants: [{
            "id": 44546957803840,
            "title": "Default Title",
            "option1": "Default Title",
            "option2": null,
            "option3": null,
            "sku": "MJ001",
            "requires_shipping": true,
            "taxable": true,
            "featured_image": null,
            "available": true,
            "name": "<?php echo $name; ?> | Situs Gacor Pasti Seru Main Bareng Teman",
            "public_title": null,
            "options": ["Default Title"],
            "price": 999,
            "weight": 71,
            "compare_at_price": null,
            "inventory_management": "shopify",
            "barcode": "",
            "requires_selling_plan": false,
            "selling_plan_allocations": []
          }]
        };
        window.qb.product_collections = []
        window.qb.product_collections.push(434989072704)
        window.qb.enabled_multi_currencies = {
          currencies_count: 19,
          currencies: [{
            iso_code: "AED",
            name: "United Arab Emirates Dirham",
            symbol: "د.إ"
          }, {
            iso_code: "AUD",
            name: "Australian Dollar",
            symbol: "$"
          }, {
            iso_code: "CAD",
            name: "Canadian Dollar",
            symbol: "$"
          }, {
            iso_code: "CHF",
            name: "Swiss Franc",
            symbol: "CHF"
          }, {
            iso_code: "CZK",
            name: "Czech Koruna",
            symbol: "Kč"
          }, {
            iso_code: "DKK",
            name: "Danish Krone",
            symbol: "kr."
          }, {
            iso_code: "EUR",
            name: "Euro",
            symbol: "€"
          }, {
            iso_code: "GBP",
            name: "British Pound",
            symbol: "£"
          }, {
            iso_code: "HKD",
            name: "Hong Kong Dollar",
            symbol: "$"
          }, {
            iso_code: "ILS",
            name: "Israeli New Sheqel",
            symbol: "₪"
          }, {
            iso_code: "INR",
            name: "Indian Rupee",
            symbol: "₹"
          }, {
            iso_code: "JPY",
            name: "Japanese Yen",
            symbol: "¥"
          }, {
            iso_code: "KRW",
            name: "South Korean Won",
            symbol: "₩"
          }, {
            iso_code: "MYR",
            name: "Malaysian Ringgit",
            symbol: "RM"
          }, {
            iso_code: "NZD",
            name: "New Zealand Dollar",
            symbol: "$"
          }, {
            iso_code: "PLN",
            name: "Polish Złoty",
            symbol: "zł"
          }, {
            iso_code: "SEK",
            name: "Swedish Krona",
            symbol: "kr"
          }, {
            iso_code: "SGD",
            name: "Singapore Dollar",
            symbol: "$"
          }, {
            iso_code: "USD",name: "United States Dollar",
            symbol: "$"}],
          current_shop_currency: "USD"
        }
        window.qb.cart = {
          "note": null,
          "attributes": {},
          "original_total_price": 0,
          "total_price": 0,
          "total_discount": 0,
          "total_weight": 0.0,
          "item_count": 0,
          "items": [],
          "requires_shipping": false,
          "currency": "USD",
          "items_subtotal_price": 0,"cart_level_discount_applications": [],
          "checkout_charge_amount": 0
        }
        window.qb.cart.items = [];
        if (typeof window.qb.cart.items == "object") {
          for (var i = 0; i < window.qb.cart.items.length; i++) {
            ["sku", "vendor", "url", "image", "handle", "product_type", "product_description"].map(function(a) {
              delete window.qb.cart.items[i][a]
            })
          }
        }
        //Handlebars
        ! function(a, b) {
          "object" == typeof exports && "object" == typeof module ? module.exports = b() : "function" == typeof define && define.amd ? define([], b) : "object" == typeof exports ? exports.Handlebars = b() : a.Handlebars = b()
        }(this, function() {
          return function(a) {
            function b(d) {
              if (c[d]) return c[d].exports;
              var e = c[d] = {
                exports: {},
                id: d,
                loaded: !1
              };
              return a[d].call(e.exports, e, e.exports, b), e.loaded = !0, e.exports
            }
            var c = {};
            return b.m = a, b.c = c, b.p = "", b(0)
          }([function(a, b, c) {
            "use strict";
  
            function d() {
              var a = r();
              return a.compile = function(b, c) {
                return k.compile(b, c, a)
              }, a.precompile = function(b, c) {
                return k.precompile(b, c, a)
              }, a.AST = i["default"], a.Compiler = k.Compiler, a.JavaScriptCompiler = m["default"], a.Parser = j.parser, a.parse = j.parse, a
            }
            var e = c(1)["default"];
            b.__esModule = !0;
            var f = c(2),
              g = e(f),
              h = c(35),
              i = e(h),
              j = c(36),
              k = c(41),
              l = c(42),
              m = e(l),
              n = c(39),
              o = e(n),
              p = c(34),
              q = e(p),
              r = g["default"].create,
              s = d();
            s.create = d, q["default"](s), s.Visitor = o["default"], s["default"] = s, b["default"] = s, a.exports = b["default"]
          }, function(a, b) {
            "use strict";
            b["default"] = function(a) {
              return a && a.__esModule ? a : {
                "default": a
              }
            }, b.__esModule = !0
          }, function(a, b, c) {
            "use strict";
  
            function d() {
              var a = new h.HandlebarsEnvironment;
              return n.extend(a, h), a.SafeString = j["default"], a.Exception = l["default"], a.Utils = n, a.escapeExpression = n.escapeExpression, a.VM = p, a.template = function(b) {
                return p.template(b, a)
              }, a
            }
            var e = c(3)["default"],
              f = c(1)["default"];
            b.__esModule = !0;
            var g = c(4),
              h = e(g),
              i = c(21),
              j = f(i),
              k = c(6),
              l = f(k),
              m = c(5),
              n = e(m),
              o = c(22),
              p = e(o),
              q = c(34),
              r = f(q),
              s = d();
            s.create = d, r["default"](s), s["default"] = s, b["default"] = s, a.exports = b["default"]
          }, function(a, b) {
            "use strict";
            b["default"] = function(a) {
              if (a && a.__esModule) return a;
              var b = {};
              if (null != a)
                for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && (b[c] = a[c]);
              return b["default"] = a, b
            }, b.__esModule = !0
          }, function(a, b, c) {
            "use strict";
  
            function d(a, b, c) {
              this.helpers = a || {}, this.partials = b || {}, this.decorators = c || {}, i.registerDefaultHelpers(this), j.registerDefaultDecorators(this)
            }
            var e = c(1)["default"];
            b.__esModule = !0, b.HandlebarsEnvironment = d;
            var f = c(5),
              g = c(6),
              h = e(g),
              i = c(10),
              j = c(18),
              k = c(20),
              l = e(k),
              m = "4.0.8";
            b.VERSION = m;
            var n = 7;
            b.COMPILER_REVISION = n;
            var o = {1: "<= 1.0.rc.2",
              2: "== 1.0.0-rc.3",
              3: "== 1.0.0-rc.4",
              4: "== 1.x.x",
              5: "== 2.0.0-alpha.x",
              6: ">= 2.0.0-beta.1",
              7: ">= 4.0.0"
            };
            b.REVISION_CHANGES = o;
            var p = "[object Object]";
            d.prototype = {
              constructor: d,
              logger: l["default"],
              log: l["default"].log,
              registerHelper: function(a, b) {
                if (f.toString.call(a) === p) {
                  if (b) throw new h["default"]("Arg not supported with multiple helpers");
                  f.extend(this.helpers, a)
                } else this.helpers[a] = b
              },
              unregisterHelper: function(a) {
                delete this.helpers[a]
              },
              registerPartial: function(a, b) {
                if (f.toString.call(a) === p) f.extend(this.partials, a);
                else {
                  if ("" == typeof b) throw new h["default"]('Attempting to register a partial called "' + a + '" as ');
                  this.partials[a] = b
                }
              },
              unregisterPartial: function(a) {
                delete this.partials[a]
              },
              registerDecorator: function(a, b) {
                if (f.toString.call(a) === p) {
                  if (b) throw new h["default"]("Arg not supported with multiple decorators");
                  f.extend(this.decorators, a)
                } else this.decorators[a] = b
              },
              unregisterDecorator: function(a) {
                delete this.decorators[a]
              }
            };
            var q = l["default"].log;
            b.log = q, b.createFrame = f.createFrame, b.logger = l["default"]
          }, function(a, b) {
            "use strict";
  
            function c(a) {
              return k[a]
            }
  
            function d(a) {
              for (var b = 1; b < arguments.length; b++)
                for (var c in arguments[b]) Object.prototype.hasOwnProperty.call(arguments[b], c) && (a[c] = arguments[b][c]);
              return a
            }
  
            function e(a, b) {
              for (var c = 0, d = a.length; c < d; c++)
                if (a[c] === b) return c;
              return -1
            }
  
            function f(a) {
              if ("string" != typeof a) {
                if (a && a.toHTML) return a.toHTML();
                if (null == a) return "";
                if (!a) return a + "";
                a = "" + a
              }
              return m.test(a) ? a.replace(l, c) : a
            }
  
            function g(a) {
              return !a && 0 !== a || !(!p(a) || 0 !== a.length)
            }
  
            function h(a) {
              var b = d({}, a);
              return b._parent = a, b
            }
  
            function i(a, b) {
              return a.path = b, a
            }
  
            function j(a, b) {
              return (a ? a + "." : "") + b
            }
            b.__esModule = !0, b.extend = d, b.indexOf = e, b.escapeExpression = f, b.isEmpty = g, b.createFrame = h, b.blockParams = i, b.appendContextPath = j;
            var k = {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#x27;",
                "`": "&#x60;",
                "=": "&#x3D;"
              },
              l = /[&<>"'`=]/g,
              m = /[&<>"'`=]/,
              n = Object.prototype.toString;
            b.toString = n;
            var o = function(a) {
              return "function" == typeof a
            };
            o(/x/) && (b.isFunction = o = function(a) {
              return "function" == typeof a && "[object Function]"=== n.call(a)
            }), b.isFunction = o;
            var p = Array.isArray || function(a) {
              return !(!a || "object"!= typeof a) && "[object Array]" === n.call(a)
            };
            b.isArray = p
          }, function(a, b, c) {
            "use strict";
  
            function d(a, b) {
              var c = b && b.loc,
                g = void 0,
                h = void 0;c && (g = c.start.line, h = c.start.column, a += " - " + g + ":" + h);
              for (var i = Error.prototype.constructor.call(this, a), j = 0; j < f.length; j++) this[f[j]] = i[f[j]];
              Error.captureStackTrace && Error.captureStackTrace(this, d);
              try {
                c && (this.lineNumber = g, e ? Object.defineProperty(this, "column", {
                  value: h,
                  enumerable: !0
                }) : this.column = h)
              } catch (k) {}
            }
            var e = c(7)["default"];
            b.__esModule = !0;
            var f = ["description", "fileName", "lineNumber", "message", "name", "number", "stack"];
            d.prototype = new Error, b["default"] = d, a.exports = b["default"]
          }, function(a, b, c) {
            a.exports = {
              "default": c(8),
              __esModule: !0
            }
          }, function(a, b, c) {
            var d = c(9);
            a.exports = function(a, b, c) {
              return d.setDesc(a, b, c)
            }
          }, function(a, b) {
            var c = Object;
            a.exports = {
              create: c.create,
              getProto: c.getPrototypeOf,
              isEnum: {}.propertyIsEnumerable,
              getDesc: c.getOwnPropertyDescriptor,
              setDesc: c.defineProperty,
              setDescs: c.defineProperties,
              getKeys: c.keys,
              getNames: c.getOwnPropertyNames,
              getSymbols: c.getOwnPropertySymbols,
              each: [].forEach
            }
          }, function(a, b, c) {
            "use strict";
  
            function d(a) {
              g["default"](a), i["default"](a), k["default"](a), m["default"](a), o["default"](a), q["default"](a), s["default"](a)
            }
            var e = c(1)["default"];
            b.__esModule = !0, b.registerDefaultHelpers = d;
            var f = c(11),
              g = e(f),
              h = c(12),
              i = e(h),
              j = c(13),
              k = e(j),
              l = c(14),
              m = e(l),
              n = c(15),
              o = e(n),
              p = c(16),
              q = e(p),
              r = c(17),
              s = e(r)
          }, function(a, b, c) {
            "use strict";
            b.__esModule = !0;
            var d = c(5);
            b["default"] = function(a) {
              a.registerHelper("blockHelperMissing", function(b, c) {
                var e = c.inverse,
                  f = c.fn;
                if (b === !0) return f(this);
                if (b === !1 || null == b) return e(this);
                if (d.isArray(b)) return b.length > 0 ? (c.ids && (c.ids = [c.name]), a.helpers.each(b, c)) : e(this);
                if (c.data && c.ids) {
                  var g = d.createFrame(c.data);
                  g.contextPath = d.appendContextPath(c.data.contextPath, c.name), c = {
                    data: g
                  }
                }
                return f(b, c)
              })
            }, a.exports = b["default"]
          }, function(a, b, c) {
            "use strict";
            var d = c(1)["default"];
            b.__esModule = !0;
            var e = c(5),
              f = c(6),
              g = d(f);
            b["default"] = function(a) {
              a.registerHelper("each", function(a, b) {
                function c(b, c, f) {
                  j && (j.key = b, j.index = c, j.first = 0 === c, j.last = !!f, k && (j.contextPath = k + b)), i += d(a[b], {
                    data: j,
                    blockParams: e.blockParams([a[b], b], [k + b, null])
                  })
                }
                if (!b) throw new g["default"]("Must pass iterator to #each");
                var d = b.fn,
                  f = b.inverse,
                  h = 0,
                  i = "",j = void 0,
                  k = void 0;
                if (b.data && b.ids && (k = e.appendContextPath(b.data.contextPath, b.ids[0]) + "."), e.isFunction(a) && (a = a.call(this)), b.data && (j = e.createFrame(b.data)), a && "object" ==typeof a)
                  if (e.isArray(a))
                    for (var l = a.length; h < l; h++) h in a && c(h, h, h === a.length - 1);
                  else {
                    var m = void 0;
                    for (var n in a) a.hasOwnProperty(n) && (void 0 !== m && c(m, h - 1), m = n, h++);
                    void 0 !== m && c(m, h - 1, !0)
                  } return 0 === h && (i = f(this)), i
              })
            }, a.exports = b["default"]
          }, function(a, b, c) {
            "use strict";
            var d = c(1)["default"];
            b.__esModule = !0;
            var e = c(6),
              f = d(e);
            b["default"] = function(a) {
              a.registerHelper("helperMissing", function() {
                if (1 !== arguments.length) throw new f["default"]('Missing helper: "' + arguments[arguments.length - 1].name + '"')
              })
            }, a.exports = b["default"]
          }, function(a, b, c) {
            "use strict";
            b.__esModule = !0;
            var d = c(5);
            b["default"] = function(a) {
              a.registerHelper("if", function(a, b) {
                return d.isFunction(a) && (a = a.call(this)), !b.hash.includeZero && !a || d.isEmpty(a) ? b.inverse(this) : b.fn(this)
              }), a.registerHelper("unless", function(b, c) {
                return a.helpers["if"].call(this, b, {
                  fn: c.inverse,
                  inverse: c.fn,
                  hash: c.hash
                })
              })
            }, a.exports = b["default"]
          }, function(a, b) {
            "use strict";
            b.__esModule = !0, b["default"] = function(a) {
              a.registerHelper("log", function() {
                for (var b = [void 0], c = arguments[arguments.length - 1], d = 0; d < arguments.length - 1; d++) b.push(arguments[d]);
                var e = 1;
                null != c.hash.level ? e = c.hash.level : c.data && null != c.data.level && (e = c.data.level), b[0] = e, a.log.apply(a, b)
              })
            }, a.exports = b["default"]
          }, function(a, b) {
            "use strict";
            b.__esModule = !0, b["default"] = function(a) {
              a.registerHelper("lookup", function(a, b) {
                return a && a[b]
              })
            }, a.exports = b["default"]
          }, function(a, b, c) {
            "use strict";
            b.__esModule = !0;
            var d = c(5);
            b["default"] = function(a) {
              a.registerHelper("with", function(a, b) {
                d.isFunction(a) && (a = a.call(this));
                var c = b.fn;
                if (d.isEmpty(a)) return b.inverse(this);
                var e = b.data;
                return b.data && b.ids && (e = d.createFrame(b.data), e.contextPath = d.appendContextPath(b.data.contextPath, b.ids[0])), c(a, {
                  data: e,
                  blockParams: d.blockParams([a], [e && e.contextPath])
                })
              })
            }, a.exports = b["default"]
          }, function(a, b, c) {
            "use strict";
  
            function d(a) {
              g["default"](a)
            }
            var e = c(1)["default"];
            b.__esModule = !0, b.registerDefaultDecorators = d;
            var f = c(19),
              g = e(f)
          }, function(a, b, c) {
            "use strict";
            b.__esModule = !0;
            var d = c(5);
            b["default"] = function(a) {
              a.registerDecorator("inline", function(a, b, c, e) {
                var f = a;
                return b.partials || (b.partials = {}, f = function(e, f) {
                  var g = c.partials;
                  c.partials = d.extend({}, g, b.partials);
                  var h = a(e, f);
                  return c.partials = g, h
                }), b.partials[e.args[0]] = e.fn, f
              })
            }, a.exports = b["default"]
          }, function(a, b, c) {
            "use strict";
            b.__esModule = !0;var d = c(5),
              e = {
                methodMap: ["debug", "info", "warn", "error"],
                level: "info",lookupLevel: function(a) {
                  if ("string" == typeof a) {
                    var b = d.indexOf(e.methodMap, a.toLowerCase());
                    a = b >= 0 ? b : parseInt(a, 10)
                  }
                  return a},
                log: function(a) {
                  if (a = e.lookupLevel(a), "" != typeof console && e.lookupLevel(e.level) <= a) {
                    var b = e.methodMap[a];
                    console[b] || (b = "log");
                    for (var c = arguments.length, d = Array(c > 1 ? c - 1 : 0), f = 1; f < c; f++) d[f - 1] = arguments[f];
                    console[b].apply(console, d)
                  }
                }
              };
            b["default"] = e, a.exports = b["default"]
          }, function(a, b) {
            "use strict";
  
            function c(a) {
              this.string = a
            }
            b.__esModule = !0, c.prototype.toString = c.prototype.toHTML = function() {
              return "" + this.string
            }, b["default"] = c, a.exports = b["default"]
          }, function(a, b, c) {
            "use strict";
  
            function d(a) {
              var b = a && a[0] || 1,
                c = s.COMPILER_REVISION;
              if (b !== c) {
                if (b < c) {
                  var d = s.REVISION_CHANGES[c],
                    e = s.REVISION_CHANGES[b];
                  throw new r["default"]("Template was precompiled with an older version of Handlebars than the current runtime. Please update your precompiler to a newer version (" + d + ") or downgrade your runtime to an older version (" + e + ").")
                }
                throw new r["default"]("Template was precompiled with a newer version of Handlebars than the current runtime. Please update your runtime to a newer version (" + a[1] + ").")
              }
            }
  
            function e(a, b) {
              function c(c, d, e) {
                e.hash && (d = p.extend({}, d, e.hash), e.ids && (e.ids[0] = !0)), c = b.VM.resolvePartial.call(this, c, d, e);
                var f = b.VM.invokePartial.call(this, c, d, e);
                if (null == f && b.compile && (e.partials[e.name] = b.compile(c, a.compilerOptions, b), f = e.partials[e.name](d, e)), null != f) {
                  if (e.indent) {
                    for (var g = f.split("\n"), h = 0, i = g.length; h < i && (g[h] || h + 1 !== i); h++) g[h] = e.indent + g[h];
                    f = g.join("\n")
                  }
                  return f
                }
                throw new r["default"]("The partial " + e.name + " could not be compiled when running in runtime-only mode")
              }
  
              function d(b) {
                function c(b) {
                  return "" + a.main(e, b, e.helpers, e.partials, g, i, h)
                }
                var f = arguments.length <= 1 || void 0 === arguments[1] ? {} : arguments[1],
                  g = f.data;
                d._setup(f), !f.partial && a.useData && (g = j(b, g));
                var h = void 0,
                  i = a.useBlockParams ? [] : void 0;
                return a.useDepths && (h = f.depths ? b != f.depths[0] ? [b].concat(f.depths) : f.depths : [b]), (c = k(a.main, c, e, f.depths || [], g, i))(b, f)
              }
              if (!b) throw new r["default"]("No environment passed to template");
              if (!a || !a.main) throw new r["default"]("Unknown template object: " + typeof a);
              a.main.decorator = a.main_d, b.VM.checkRevision(a.compiler);
              var e = {
                strict: function(a, b) {
                  if (!(b in a)) throw new r["default"]('"' + b + '" not defined in ' + a);
                  return a[b]
                },
                lookup: function(a, b) {
                  for (var c = a.length, d = 0; d < c; d++)
                    if (a[d] && null != a[d][b]) return a[d][b]
                },
                lambda: function(a, b) {
                  return "function" == typeof a ? a.call(b) : a
                },
                escapeExpression: p.escapeExpression,invokePartial: c,
                fn: function(b) {
                  var c = a[b];
                  return c.decorator = a[b + "_d"], c
                },
                programs: [],
                program: function(a, b, c, d, e) {
                  var g = this.programs[a],
                    h = this.fn(a);
                  return b || e || d || c ? g = f(this, a, h, b, c, d, e) : g || (g = this.programs[a] = f(this, a, h)), g
                },
                data: function(a, b) {
                  for (; a && b--;) a = a._parent;
                  return a
                },
                merge: function(a, b) {
                  var c = a || b;
                  return a && b && a !== b && (c = p.extend({}, b, a)), c
                },
                nullContext: l({}),
                noop: b.VM.noop,
                compilerInfo: a.compiler
              };
              return d.isTop = !0, d._setup = function(c) {
                c.partial ? (e.helpers = c.helpers, e.partials = c.partials, e.decorators = c.decorators) : (e.helpers = e.merge(c.helpers, b.helpers), a.usePartial && (e.partials = e.merge(c.partials, b.partials)), (a.usePartial || a.useDecorators) && (e.decorators = e.merge(c.decorators, b.decorators)))
              }, d._child = function(b, c, d, g) {
                if (a.useBlockParams && !d) throw new r["default"]("must pass block params");
                if (a.useDepths && !g) throw new r["default"]("must pass parent depths");
                return f(e, b, a[b], c, 0, d, g)
              }, d
            }
  
            function f(a, b, c, d, e, f, g) {
              function h(b) {
                var e = arguments.length <= 1 || void 0 === arguments[1] ? {} : arguments[1],
                  h = g;
                return !g || b == g[0] || b === a.nullContext && null === g[0] || (h = [b].concat(g)), c(a, b, a.helpers, a.partials, e.data || d, f && [e.blockParams].concat(f), h)
              }
              return h = k(c, h, a, g, d, f), h.program = b, h.depth = g ? g.length : 0, h.blockParams = e || 0, h
            }
  
            function g(a, b, c) {
              return a ? a.call || c.name || (c.name = a, a = c.partials[a]) : a = "@partial-block" === c.name ? c.data["partial-block"] : c.partials[c.name], a
            }
  
            function h(a, b, c) {
              var d = c.data && c.data["partial-block"];
              c.partial = !0, c.ids && (c.data.contextPath = c.ids[0] || c.data.contextPath);
              var e = void 0;
              if (c.fn && c.fn !== i && ! function() {
                  c.data = s.createFrame(c.data);
                  var a = c.fn;
                  e = c.data["partial-block"] = function(b) {
                    var c = arguments.length <= 1 || void 0 === arguments[1] ? {} : arguments[1];
                    return c.data = s.createFrame(c.data), c.data["partial-block"] = d, a(b, c)
                  }, a.partials && (c.partials = p.extend({}, c.partials, a.partials))
                }(), void 0 === a && e && (a = e), void 0 === a) throw new r["default"]("The partial " + c.name + " could not be found");
              if (a instanceof Function) return a(b, c)
            }
  
            function i() {
              return ""
            }
  
            function j(a, b) {
              return b && "root" in b || (b = b ? s.createFrame(b) : {}, b.root = a), b
            }
  
            function k(a, b, c, d, e, f) {
              if (a.decorator) {
                var g = {};
                b = a.decorator(b, g, c, d && d[0], e, f, d), p.extend(b, g)
              }
              return b
            }
            var l = c(23)["default"],
              m = c(3)["default"],
              n = c(1)["default"];
            b.__esModule = !0, b.checkRevision = d, b.template = e, b.wrapProgram = f, b.resolvePartial = g, b.invokePartial = h, b.noop = i;
            var o = c(5),
              p = m(o),
              q = c(6),
              r = n(q),
              s = c(4)
          }, function(a, b, c) {
            a.exports = {
              "default": c(24),
              __esModule: !0
            }
          }, function(a, b, c) {
            c(25), a.exports = c(30).Object.seal}, function(a, b, c) {
            var d = c(26);
            c(27)("seal", function(a) {
              return function(b) {
                return a && d(b) ? a(b) : b
              }
            })
          }, function(a, b) {
            a.exports = function(a) {
              return "object" == typeof a ? null !== a : "function" == typeof a
            }
          }, function(a, b, c) {
            var d = c(28),
              e = c(30),
              f = c(33);a.exports = function(a, b) {
              var c = (e.Object || {})[a] || Object[a],
                g = {};
              g[a] = b(c), d(d.S + d.F * f(function() {
                c(1)
              }), "Object", g)
            }
          }, function(a, b, c) {
            var d = c(29),
              e = c(30),
              f = c(31),
              g = "prototype",
              h = function(a, b, c) {
                var i, j, k, l = a & h.F,
                  m = a & h.G,
                  n = a & h.S,
                  o = a & h.P,
                  p = a & h.B,
                  q = a & h.W,
                  r = m ? e : e[b] || (e[b] = {}),
                  s = m ? d : n ? d[b] : (d[b] || {})[g];
                m && (c = b);
                for (i in c) j = !l && s && i in s, j && i in r || (k = j ? s[i] : c[i], r[i] = m && "function" != typeof s[i] ? c[i] : p && j ? f(k, d) : q && s[i] == k ? function(a) {
                  var b = function(b) {
                    return this instanceof a ? new a(b) : a(b)
                  };
                  return b[g] = a[g], b
                }(k) : o && "function" == typeof k ? f(Function.call, k) : k, o && ((r[g] || (r[g] = {}))[i] = k))
              };
            h.F = 1, h.G = 2, h.S = 4, h.P = 8, h.B = 16, h.W = 32, a.exports = h
          }, function(a, b) {
            var c = a.exports = "" != typeof window && window.Math == Math ? window : "" != typeof self && self.Math == Math ? self : Function("return this")();
            "number" == typeof __g && (__g = c)
          }, function(a, b) {
            var c = a.exports = {
              version: "1.2.6"
            };
            "number" == typeof __e && (__e = c)
          }, function(a, b, c) {
            var d = c(32);
            a.exports = function(a, b, c) {
              if (d(a), void 0 === b) return a;
              switch (c) {
                case 1:
                  return function(c) {
                    return a.call(b, c)
                  };
                case 2:
                  return function(c, d) {
                    return a.call(b, c, d)
                  };
                case 3:
                  return function(c, d, e) {
                    return a.call(b, c, d, e)
                  }
              }
              return function() {
                return a.apply(b, arguments)
              }
            }
          }, function(a, b) {
            a.exports = function(a) {
              if ("function" != typeof a) throw TypeError(a + " is not a function!");
              return a
            }
          }, function(a, b) {
            a.exports = function(a) {
              try {
                return !!a()
              } catch (b) {
                return !0
              }
            }
          }, function(a, b) {
            (function(c) {
              "use strict";
              b.__esModule = !0, b["default"] = function(a) {
                var b = "" != typeof c ? c : window,
                  d = b.Handlebars;
                a.noConflict = function() {
                  return b.Handlebars === a && (b.Handlebars = d), a
                }
              }, a.exports = b["default"]
            }).call(b, function() {
              return this
            }())
          }, function(a, b) {
            "use strict";
            b.__esModule = !0;
            var c = {
              helpers: {
                helperExpression: function(a) {
                  return "SubExpression" === a.type || ("MustacheStatement" === a.type || "BlockStatement" === a.type) && !!(a.params && a.params.length || a.hash)},
                scopedId: function(a) {
                  return /^\.|this\b/.test(a.original)
                },
                simpleId: function(a) {
                  return 1 === a.parts.length && !c.helpers.scopedId(a) && !a.depth}
              }
            };
            b["default"] = c, a.exports = b["default"]
          }, function(a, b, c) {
            "use strict";
  
            function d(a, b) {
              if ("Program" === a.type) return a;
              h["default"].yy = n, n.locInfo = function(a) {
                return new n.SourceLocation(b && b.srcName, a)
              };
              var c = new j["default"](b);
              return c.accept(h["default"].parse(a))
            }
            var e = c(1)["default"],
              f = c(3)["default"];
            b.__esModule = !0, b.parse = d;
            var g = c(37),
              h = e(g),
              i = c(38),
              j = e(i),
              k = c(40),
              l = f(k),
              m = c(5);
            b.parser = h["default"];
            var n = {};
            m.extend(n, l)
          }, function(a, b) {
            "use strict";
            b.__esModule = !0;
            var c = function() {
              function a() {
                this.yy = {}
              }
              var b = {
                  trace: function() {},
                  yy: {},
                  symbols_: {
                    error: 2,
                    root: 3,
                    program: 4,
                    EOF: 5,
                    program_repetition0: 6,
                    statement: 7,
                    mustache: 8,
                    block: 9,
                    rawBlock: 10,
                    partial: 11,
                    partialBlock: 12,
                    content: 13,
                    COMMENT: 14,
                    CONTENT: 15,
                    openRawBlock: 16,
                    rawBlock_repetition_plus0: 17,
                    END_RAW_BLOCK: 18,
                    OPEN_RAW_BLOCK: 19,
                    helperName: 20,
                    openRawBlock_repetition0: 21,
                    openRawBlock_option0: 22,
                    CLOSE_RAW_BLOCK: 23,
                    openBlock: 24,
                    block_option0: 25,
                    closeBlock: 26,
                    openInverse: 27,
                    block_option1: 28,
                    OPEN_BLOCK: 29,
                    openBlock_repetition0: 30,
                    openBlock_option0: 31,
                    openBlock_option1: 32,
                    CLOSE: 33,
                    OPEN_INVERSE: 34,
                    openInverse_repetition0: 35,
                    openInverse_option0: 36,
                    openInverse_option1: 37,
                    openInverseChain: 38,
                    OPEN_INVERSE_CHAIN: 39,
                    openInverseChain_repetition0: 40,
                    openInverseChain_option0: 41,
                    openInverseChain_option1: 42,
                    inverseAndProgram: 43,
                    INVERSE: 44,
                    inverseChain: 45,
                    inverseChain_option0: 46,
                    OPEN_ENDBLOCK: 47,
                    OPEN: 48,
                    mustache_repetition0: 49,
                    mustache_option0: 50,
                    OPEN_UNESCAPED: 51,
                    mustache_repetition1: 52,
                    mustache_option1: 53,
                    CLOSE_UNESCAPED: 54,
                    OPEN_PARTIAL: 55,
                    partialName: 56,
                    partial_repetition0: 57,
                    partial_option0: 58,
                    openPartialBlock: 59,
                    OPEN_PARTIAL_BLOCK: 60,
                    openPartialBlock_repetition0: 61,
                    openPartialBlock_option0: 62,
                    param: 63,
                    sexpr: 64,
                    OPEN_SEXPR: 65,
                    sexpr_repetition0: 66,
                    sexpr_option0: 67,
                    CLOSE_SEXPR: 68,
                    hash: 69,
                    hash_repetition_plus0: 70,
                    hashSegment: 71,
                    ID: 72,
                    EQUALS: 73,
                    blockParams: 74,
                    OPEN_BLOCK_PARAMS: 75,
                    blockParams_repetition_plus0: 76,
                    CLOSE_BLOCK_PARAMS: 77,
                    path: 78,
                    dataName: 79,
                    STRING: 80,NUMBER: 81,
                    BOOLEAN: 82,
                    : 83,
                    NULL:84,
                    DATA: 85,
                    pathSegments: 86,SEP: 87,
                    $accept: 0,
                    $end: 1
                  },
                  terminals_: {
                    2: "error",
                    5: "EOF",
                    14: "COMMENT",
                    15: "CONTENT",18: "END_RAW_BLOCK",
                    19: "OPEN_RAW_BLOCK",
                    23: "CLOSE_RAW_BLOCK",
                    29: "OPEN_BLOCK",
                    33: "CLOSE",
                    34: "OPEN_INVERSE",
                    39: "OPEN_INVERSE_CHAIN",
                    44: "INVERSE",
                    47: "OPEN_ENDBLOCK",
                    48: "OPEN",
                    51: "OPEN_UNESCAPED",
                    54: "CLOSE_UNESCAPED",
                    55: "OPEN_PARTIAL",
                    60: "OPEN_PARTIAL_BLOCK",
                    65: "OPEN_SEXPR",
                    68: "CLOSE_SEXPR",
                    72: "ID",
                    73: "EQUALS",
                    75: "OPEN_BLOCK_PARAMS",
                    77: "CLOSE_BLOCK_PARAMS",
                    80: "STRING",
                    81: "NUMBER",
                    82: "BOOLEAN",
                    83: "",
                    84: "NULL",
                    85: "DATA",
                    87: "SEP"
                  },
                  productions_: [0, [3, 2],
                    [4, 1],
                    [7, 1],
                    [7, 1],
                    [7, 1],
                    [7, 1],
                    [7, 1],
                    [7, 1],
                    [7, 1],
                    [13, 1],
                    [10, 3],
                    [16, 5],
                    [9, 4],
                    [9, 4],
                    [24, 6],
                    [27, 6],
                    [38, 6],
                    [43, 2],
                    [45, 3],
                    [45, 1],
                    [26, 3],
                    [8, 5],
                    [8, 5],
                    [11, 5],
                    [12, 3],
                    [59, 5],
                    [63, 1],
                    [63, 1],
                    [64, 5],
                    [69, 1],
                    [71, 3],
                    [74, 3],
                    [20, 1],
                    [20, 1],
                    [20, 1],
                    [20, 1],
                    [20, 1],
                    [20, 1],
                    [20, 1],
                    [56, 1],
                    [56, 1],
                    [79, 2],
                    [78, 1],
                    [86, 3],
                    [86, 1],
                    [6, 0],
                    [6, 2],
                    [17, 1],
                    [17, 2],
                    [21, 0],
                    [21, 2],
                    [22, 0],
                    [22, 1],
                    [25, 0],
                    [25, 1],
                    [28, 0],
                    [28, 1],
                    [30, 0],
                    [30, 2],
                    [31, 0],
                    [31, 1],
                    [32, 0],
                    [32, 1],
                    [35, 0],
                    [35, 2],
                    [36, 0],
                    [36, 1],
                    [37, 0],
                    [37, 1],
                    [40, 0],
                    [40, 2],
                    [41, 0],
                    [41, 1],
                    [42, 0],
                    [42, 1],
                    [46, 0],
                    [46, 1],
                    [49, 0],
                    [49, 2],
                    [50, 0],
                    [50, 1],
                    [52, 0],[52, 2],
                    [53, 0],
                    [53, 1],
                    [57, 0],
                    [57, 2],
                    [58, 0],
                    [58, 1],
                    [61, 0],
                    [61, 2],
                    [62, 0],
                    [62, 1],
                    [66, 0],
                    [66, 2],
                    [67, 0],
                    [67, 1],
                    [70, 1],
                    [70, 2],
                    [76, 1],
                    [76, 2]
                  ],
                  performAction: function(a, b, c,d, e, f, g) {
                    var h = f.length - 1;
                    switch (e) {
                      case 1:
                        return f[h - 1];
                      case 2:
                        this.$ = d.prepareProgram(f[h]);
                        break;
                      case 3:
                        this.$ = f[h];
                        break;
                      case 4:
                        this.$ = f[h];
                        break;
                      case 5:
                        this.$ = f[h];
                        break;
                      case 6:
                        this.$ = f[h];
                        break;
                      case 7:
                        this.$ = f[h];
                        break;
                      case 8:
                        this.$ = f[h];
                        break;
                      case 9:
                        this.$ = {
                          type: "CommentStatement",
                          value: d.stripComment(f[h]),
                          strip: d.stripFlags(f[h], f[h]),
                          loc: d.locInfo(this._$)
                        };
                        break;
                      case 10:
                        this.$ = {
                          type: "ContentStatement",
                          original: f[h],
                          value: f[h],
                          loc: d.locInfo(this._$)
                        };
                        break;
                      case 11:
                        this.$ = d.prepareRawBlock(f[h - 2], f[h - 1], f[h], this._$);
                        break;
                      case 12:
                        this.$ = {
                          path: f[h - 3],
                          params: f[h - 2],
                          hash: f[h - 1]
                        };
                        break;
                      case 13:
                        this.$ = d.prepareBlock(f[h - 3], f[h - 2], f[h - 1], f[h], !1, this._$);
                        break;
                      case 14:
                        this.$ = d.prepareBlock(f[h - 3], f[h - 2], f[h - 1], f[h], !0, this._$);
                        break;
                      case 15:
                        this.$ = {
                          open: f[h - 5],
                          path: f[h - 4],
                          params: f[h - 3],
                          hash: f[h - 2],
                          blockParams: f[h - 1],
                          strip: d.stripFlags(f[h - 5], f[h])
                        };
                        break;
                      case 16:
                        this.$ = {
                          path: f[h - 4],
                          params: f[h - 3],
                          hash: f[h - 2],
                          blockParams: f[h - 1],
                          strip: d.stripFlags(f[h - 5], f[h])
                        };
                        break;
                      case 17:
                        this.$ = {
                          path: f[h - 4],
                          params: f[h - 3],
                          hash: f[h - 2],
                          blockParams: f[h - 1],
                          strip: d.stripFlags(f[h - 5], f[h])
                        };
                        break;
                      case 18:
                        this.$ = {
                          strip: d.stripFlags(f[h - 1], f[h - 1]),
                          program: f[h]
                        };
                        break;
                      case 19:
                        var i = d.prepareBlock(f[h - 2], f[h - 1], f[h], f[h], !1, this._$),
                          j = d.prepareProgram([i], f[h - 1].loc);
                        j.chained = !0, this.$ = {
                          strip: f[h - 2].strip,
                          program: j,
                          chain: !0
                        };
                        break;
                      case 20:
                        this.$ = f[h];
                        break;
                      case 21:
                        this.$ = {
                          path: f[h - 1],strip: d.stripFlags(f[h - 2], f[h])
                        };
                        break;case 22:
                        this.$ = d.prepareMustache(f[h - 3], f[h - 2], f[h - 1], f[h - 4], d.stripFlags(f[h - 4], f[h]), this._$);
                        break;
                      case 23:this.$ = d.prepareMustache(f[h - 3], f[h - 2], f[h - 1], f[h - 4], d.stripFlags(f[h - 4],f[h]), this._$);
                        break;
                      case 24:
                        this.$ = {
                          type: "PartialStatement",
                          name: f[h - 3],
                          params: f[h - 2],
                          hash: f[h - 1],
                          indent: "",
                          strip: d.stripFlags(f[h - 4], f[h]),
                          loc: d.locInfo(this._$)
                        };
                        break;
                      case 25:
                        this.$ = d.preparePartialBlock(f[h - 2], f[h - 1], f[h], this._$);
                        break;
                      case 26:
                        this.$ = {
                          path: f[h - 3],
                          params: f[h - 2],
                          hash: f[h - 1],
                          strip: d.stripFlags(f[h - 4], f[h])
                        };
                        break;
                      case 27:
                        this.$ = f[h];
                        break;
                      case 28:
                        this.$ = f[h];
                        break;
                      case 29:
                        this.$ = {
                          type: "SubExpression",
                          path: f[h - 3],
                          params: f[h - 2],
                          hash: f[h - 1],
                          loc: d.locInfo(this._$)
                        };
                        break;
                      case 30:
                        this.$ = {
                          type: "Hash",
                          pairs: f[h],
                          loc: d.locInfo(this._$)
                        };
                        break;
                      case 31:
                        this.$ = {
                          type: "HashPair",
                          key: d.id(f[h - 2]),
                          value: f[h],
                          loc: d.locInfo(this._$)
                        };
                        break;
                      case 32:
                        this.$ = d.id(f[h - 1]);
                        break;
                      case 33:
                        this.$ = f[h];
                        break;
                      case 34:
                        this.$ = f[h];
                        break;
                      case 35:
                        this.$ = {
                          type: "StringLiteral",
                          value: f[h],
                          original: f[h],
                          loc: d.locInfo(this._$)
                        };
                        break;
                      case 36:
                        this.$ = {
                          type: "NumberLiteral",
                          value: Number(f[h]),
                          original: Number(f[h]),
                          loc: d.locInfo(this._$)
                        };
                        break;
                      case 37:
                        this.$ = {type: "BooleanLiteral",
                          value: "true" === f[h],
                          original: "true" === f[h],
                          loc: d.locInfo(this._$)
                        };
                        break;
                      case 38:
                        this.$ = {
                          type: "Literal",
                          original: void 0,
                          value: void 0,
                          loc: d.locInfo(this._$)
                        };
                        break;
                      case 39:
                        this.$ = {
                          type: "NullLiteral",
                          original: null,
                          value: null,
                          loc: d.locInfo(this._$)
                        };
                        break;
                      case 40:
                        this.$ = f[h];break;
                      case 41:
                        this.$ = f[h];
                        break;
                      case 42:
                        this.$ = d.preparePath(!0, f[h], this._$);
                        break;
                      case 43:
                        this.$ = d.preparePath(!1, f[h], this._$);
                        break;
                      case 44:
                        f[h - 2].push({
                          part: d.id(f[h]),
                          original: f[h],
                          separator: f[h - 1]
                        }), this.$ = f[h - 2];
                        break;
                      case 45:
                        this.$ = [{
                          part: d.id(f[h]),
                          original: f[h]
                        }];
                        break;
                      case 46:
                        this.$ = [];
                        break;
                      case 47:
                        f[h - 1].push(f[h]);
                        break;
                      case 48:
                        this.$ = [f[h]];
                        break;
                      case 49:
                        f[h - 1].push(f[h]);
                        break;
                      case 50:
                        this.$ = [];
                        break;
                      case 51:
                        f[h - 1].push(f[h]);
                        break;
                      case 58:
                        this.$ = [];
                        break;
                      case 59:
                        f[h - 1].push(f[h]);
                        break;
                      case 64:
                        this.$ = [];
                        break;
                      case 65:
                        f[h - 1].push(f[h]);
                        break;
                      case 70:
                        this.$ = [];
                        break;
                      case 71:
                        f[h - 1].push(f[h]);
                        break;
                      case 78:
                        this.$ = [];
                        break;
                      case 79:
                        f[h - 1].push(f[h]);
                        break;
                      case 82:
                        this.$ = [];
                        break;
                      case 83:
                        f[h - 1].push(f[h]);
                        break;
                      case 86:
                        this.$ = [];
                        break;
                      case 87:
                        f[h - 1].push(f[h]);
                        break;
                      case 90:
                        this.$ = [];
                        break;
                      case 91:
                        f[h - 1].push(f[h]);
                        break;
                      case 94:
                        this.$ = [];
                        break;
                      case 95:
                        f[h - 1].push(f[h]);
                        break;
                      case 98:
                        this.$ = [f[h]];
                        break;
                      case 99:
                        f[h - 1].push(f[h]);
                        break;
                      case 100:
                        this.$ = [f[h]];
                        break;
                      case 101:
                        f[h - 1].push(f[h])
                    }
                  },
                  table: [{
                    3: 1,
                    4: 2,
                    5: [2, 46],
                    6: 3,
                    14: [2, 46],
                    15: [2, 46],
                    19: [2, 46],
                    29: [2, 46],
                    34: [2, 46],
                    48: [2, 46],
                    51: [2, 46],
                    55: [2, 46],
                    60: [2, 46]
                  }, {
                    1: [3]
                  }, {
                    5: [1, 4]
                  }, {
                    5: [2, 2],
                    7: 5,
                    8: 6,9: 7,
                    10: 8,
                    11: 9,
                    12: 10,
                    13: 11,
                    14: [1, 12],
                    15: [1, 20],
                    16: 17,
                    19: [1, 23],24: 15,
                    27: 16,
                    29: [1,21],
                    34: [1, 22],
                    39: [2, 2],
                    44: [2, 2],47: [2, 2],
                    48: [1, 13],
                    51: [1, 14],
                    55: [1, 18],
                    59: 19,
                    60: [1, 24]
                  }, {
                    1: [2, 1]
                  }, {
                    5: [2, 47],
                    14: [2, 47],
                    15: [2, 47],
                    19: [2, 47],
                    29: [2, 47],
                    34: [2, 47],
                    39: [2, 47],
                    44: [2, 47],
                    47: [2, 47],
                    48: [2, 47],
                    51: [2, 47],
                    55: [2, 47],
                    60: [2, 47]
                  }, {
                    5: [2, 3],
                    14: [2, 3],
                    15: [2, 3],
                    19: [2, 3],
                    29: [2, 3],
                    34: [2, 3],
                    39: [2, 3],
                    44: [2, 3],
                    47: [2, 3],
                    48: [2, 3],
                    51: [2, 3],
                    55: [2, 3],
                    60: [2, 3]
                  }, {
                    5: [2, 4],
                    14: [2, 4],
                    15: [2, 4],
                    19: [2, 4],
                    29: [2, 4],
                    34: [2, 4],
                    39: [2, 4],
                    44: [2, 4],
                    47: [2, 4],
                    48: [2, 4],
                    51: [2, 4],
                    55: [2, 4],
                    60: [2, 4]
                  }, {
                    5: [2, 5],
                    14: [2, 5],
                    15: [2, 5],
                    19: [2, 5],
                    29: [2, 5],
                    34: [2, 5],
                    39: [2, 5],
                    44: [2, 5],
                    47: [2, 5],
                    48: [2, 5],
                    51: [2, 5],
                    55: [2, 5],
                    60: [2, 5]
                  }, {
                    5: [2, 6],
                    14: [2, 6],
                    15: [2, 6],
                    19: [2, 6],
                    29: [2, 6],
                    34: [2, 6],
                    39: [2, 6],
                    44: [2, 6],
                    47: [2, 6],
                    48: [2, 6],
                    51: [2, 6],
                    55: [2, 6],
                    60: [2, 6]
                  }, {
                    5: [2, 7],
                    14: [2, 7],
                    15: [2, 7],
                    19: [2, 7],
                    29: [2, 7],
                    34: [2, 7],
                    39: [2, 7],
                    44: [2, 7],
                    47: [2, 7],
                    48: [2, 7],
                    51: [2, 7],
                    55: [2, 7],60: [2, 7]
                  }, {
                    5: [2, 8],
                    14: [2, 8],
                    15: [2, 8],
                    19: [2, 8],
                    29: [2, 8],
                    34: [2, 8],
                    39: [2, 8],
                    44: [2, 8],
                    47: [2, 8],
                    48: [2, 8],
                    51: [2, 8],
                    55: [2, 8],
                    60: [2, 8]
                  }, {
                    5: [2, 9],
                    14: [2, 9],
                    15: [2, 9],
                    19: [2, 9],
                    29: [2, 9],
                    34: [2, 9],
                    39: [2, 9],
                    44: [2, 9],
                    47: [2, 9],
                    48: [2, 9],
                    51: [2, 9],
                    55: [2, 9],
                    60: [2, 9]
                  }, {
                    20: 25,
                    72: [1, 35],
                    78: 26,
                    79: 27,
                    80: [1, 28],
                    81: [1, 29],
                    82: [1, 30],
                    83: [1, 31],
                    84: [1, 32],
                    85: [1, 34],
                    86: 33
                  }, {20: 36,
                    72: [1, 35],
                    78: 26,
                    79: 27,
                    80: [1, 28],
                    81: [1, 29],
                    82: [1, 30],
                    83: [1, 31],
                    84: [1, 32],
                    85: [1, 34],
                    86: 33
                  }, {
                    4: 37,
                    6: 3,
                    14: [2, 46],
                    15: [2, 46],
                    19: [2, 46],
                    29: [2, 46],
                    34: [2, 46],
                    39: [2, 46],
                    44: [2, 46],
                    47: [2, 46],
                    48: [2, 46],
                    51: [2, 46],
                    55: [2, 46],
                    60: [2, 46]
                  }, {
                    4: 38,
                    6: 3,
                    14: [2, 46],
                    15: [2, 46],
                    19: [2, 46],
                    29: [2, 46],
                    34: [2, 46],
                    44: [2, 46],
                    47: [2, 46],
                    48: [2, 46],
                    51: [2, 46],
                    55: [2, 46],
                    60: [2, 46]
                  }, {
                    13: 40,
                    15: [1, 20],
                    17: 39
                  }, {
                    20: 42,
                    56: 41,
                    64: 43,
                    65: [1, 44],
                    72: [1, 35],
                    78: 26,
                    79: 27,
                    80: [1, 28],
                    81: [1, 29],
                    82: [1, 30],
                    83: [1, 31],
                    84: [1, 32],
                    85: [1, 34],
                    86: 33
                  }, {
                    4: 45,
                    6: 3,
                    14: [2, 46],
                    15: [2, 46],
                    19: [2, 46],
                    29: [2, 46],
                    34: [2, 46],
                    47: [2, 46],
                    48: [2, 46],
                    51: [2, 46],
                    55: [2, 46],
                    60: [2, 46]
                  }, {
                    5: [2, 10],
                    14: [2, 10],
                    15: [2, 10],
                    18: [2, 10],
                    19: [2, 10],
                    29: [2, 10],
                    34: [2, 10],
                    39: [2, 10],
                    44: [2, 10],
                    47: [2, 10],
                    48: [2, 10],
                    51: [2, 10],
                    55: [2, 10],
                    60: [2, 10]
                  }, {
                    20: 46,
                    72: [1, 35],
                    78: 26,
                    79: 27,
                    80: [1, 28],
                    81: [1, 29],
                    82: [1, 30],
                    83: [1, 31],
                    84: [1, 32],
                    85: [1, 34],
                    86: 33
                  }, {
                    20: 47,
                    72: [1, 35],
                    78: 26,
                    79: 27,
                    80: [1, 28],
                    81: [1, 29],
                    82: [1, 30],
                    83: [1, 31],
                    84: [1, 32],
                    85: [1, 34],
                    86: 33
                  }, {
                    20: 48,
                    72: [1, 35],
                    78: 26,
                    79: 27,
                    80: [1, 28],
                    81: [1, 29],
                    82: [1, 30],
                    83: [1, 31],
                    84: [1, 32],
                    85: [1, 34],
                    86: 33
                  }, {
                    20: 42,
                    56: 49,
                    64: 43,
                    65: [1, 44],
                    72: [1, 35],
                    78: 26,
                    79: 27,
                    80: [1, 28],
                    81: [1, 29],
                    82: [1, 30],
                    83: [1, 31],
                    84: [1, 32],
                    85: [1, 34],
                    86: 33
                  }, {
                    33: [2, 78],
                    49: 50,
                    65: [2, 78],72: [2, 78],
                    80: [2, 78],
                    81: [2, 78],
                    82: [2,78],
                    83: [2, 78],
                    84: [2, 78],
                    85: [2, 78]
                  }, {
                    23:[2, 33],
                    33: [2, 33],
                    54: [2, 33],
                    65: [2, 33],
                    68: [2, 33],
                    72: [2, 33],
                    75: [2, 33],
                    80: [2, 33],
                    81: [2, 33],
                    82: [2, 33],
                    83: [2, 33],
                    84: [2, 33],
                    85: [2, 33]
                  }, {
                    23: [2, 34],
                    33: [2, 34],
                    54: [2, 34],
                    65: [2, 34],
                    68: [2, 34],
                    72: [2, 34],
                    75: [2, 34],
                    80: [2, 34],
                    81: [2, 34],
                    82: [2, 34],
                    83: [2, 34],
                    84: [2, 34],
                    85: [2, 34]
                  }, {
                    23: [2, 35],
                    33: [2, 35],
                    54: [2, 35],
                    65: [2, 35],
                    68: [2, 35],
                    72: [2, 35],
                    75: [2, 35],
                    80: [2, 35],
                    81: [2, 35],
                    82: [2, 35],
                    83: [2, 35],
                    84: [2, 35],
                    85: [2, 35]
                  }, {
                    23: [2, 36],
                    33: [2, 36],
                    54: [2, 36],
                    65: [2, 36],
                    68: [2, 36],
                    72: [2, 36],
                    75: [2, 36],
                    80: [2, 36],
                    81: [2, 36],
                    82: [2, 36],
                    83: [2, 36],
                    84: [2, 36],
                    85: [2, 36]
                  }, {
                    23: [2, 37],
                    33: [2, 37],
                    54: [2, 37],
                    65: [2, 37],
                    68: [2, 37],
                    72: [2, 37],
                    75: [2, 37],
                    80: [2, 37],
                    81: [2, 37],
                    82: [2, 37],
                    83: [2, 37],
                    84: [2, 37],
                    85: [2, 37]
                  }, {
                    23: [2, 38],
                    33: [2, 38],
                    54: [2, 38],
                    65: [2, 38],
                    68: [2, 38],
                    72: [2, 38],
                    75: [2, 38],
                    80: [2, 38],
                    81: [2, 38],82: [2, 38],
                    83: [2, 38],
                    84: [2, 38],
                    85: [2, 38]
                  }, {
                    23: [2, 39],
                    33: [2, 39],
                    54: [2, 39],
                    65: [2, 39],
                    68: [2, 39],
                    72: [2, 39],
                    75: [2, 39],
                    80: [2, 39],
                    81: [2, 39],
                    82: [2, 39],
                    83: [2, 39],
                    84: [2, 39],
                    85: [2, 39]
                  }, {
                    23: [2, 43],
                    33: [2, 43],
                    54: [2, 43],
                    65: [2, 43],
                    68: [2, 43],
                    72: [2, 43],
                    75: [2, 43],
                    80: [2, 43],
                    81: [2, 43],
                    82: [2, 43],
                    83: [2, 43],
                    84: [2, 43],
                    85: [2, 43],
                    87: [1, 51]
                  }, {
                    72: [1, 35],
                    86: 52
                  }, {
                    23: [2, 45],
                    33: [2, 45],
                    54: [2, 45],
                    65: [2, 45],
                    68: [2, 45],
                    72: [2, 45],
                    75: [2, 45],
                    80: [2, 45],
                    81: [2, 45],
                    82: [2, 45],
                    83: [2, 45],
                    84: [2, 45],
                    85: [2, 45],87: [2, 45]
                  }, {
                    52: 53,
                    54: [2, 82],
                    65: [2, 82],
                    72: [2, 82],
                    80: [2, 82],
                    81: [2, 82],
                    82: [2, 82],
                    83: [2, 82],
                    84: [2, 82],
                    85: [2, 82]
                  }, {
                    25: 54,
                    38: 56,
                    39: [1, 58],
                    43: 57,
                    44: [1, 59],
                    45: 55,
                    47: [2, 54]
                  }, {
                    28: 60,
                    43: 61,
                    44: [1, 59],
                    47: [2, 56]
                  }, {
                    13: 63,
                    15: [1, 20],
                    18: [1, 62]
                  }, {
                    15: [2, 48],
                    18: [2, 48]
                  }, {
                    33: [2, 86],
                    57: 64,
                    65: [2, 86],
                    72: [2, 86],
                    80: [2, 86],
                    81: [2, 86],
                    82: [2, 86],
                    83: [2, 86],
                    84: [2, 86],
                    85: [2, 86]
                  }, {
                    33: [2, 40],
                    65: [2, 40],
                    72: [2, 40],
                    80: [2, 40],
                    81: [2, 40],
                    82: [2, 40],
                    83: [2, 40],
                    84: [2, 40],
                    85: [2, 40]
                  }, {
                    33: [2, 41],
                    65: [2, 41],
                    72: [2, 41],
                    80: [2, 41],
                    81: [2, 41],
                    82: [2, 41],
                    83: [2, 41],
                    84: [2, 41],
                    85: [2, 41]
                  }, {
                    20: 65,
                    72: [1, 35],
                    78: 26,
                    79: 27,
                    80: [1, 28],
                    81: [1, 29],
                    82: [1, 30],
                    83: [1, 31],
                    84: [1, 32],
                    85: [1, 34],
                    86: 33
                  }, {
                    26: 66,
                    47: [1, 67]
                  }, {
                    30: 68,
                    33: [2, 58],
                    65: [2, 58],
                    72: [2, 58],
                    75: [2, 58],
                    80: [2, 58],
                    81: [2, 58],
                    82: [2, 58],
                    83: [2, 58],
                    84: [2, 58],
                    85: [2, 58]
                  }, {
                    33: [2, 64],
                    35: 69,
                    65: [2, 64],
                    72: [2, 64],
                    75: [2, 64],
                    80: [2, 64],
                    81: [2, 64],
                    82: [2, 64],
                    83: [2, 64],
                    84: [2, 64],
                    85: [2, 64]
                  }, {
                    21: 70,
                    23: [2, 50],
                    65: [2, 50],
                    72: [2, 50],
                    80: [2, 50],
                    81: [2, 50],
                    82: [2, 50],
                    83: [2, 50],
                    84: [2, 50],
                    85: [2, 50]
                  }, {
                    33: [2, 90],
                    61: 71,
                    65: [2, 90],
                    72: [2, 90],
                    80: [2, 90],
                    81: [2, 90],
                    82: [2, 90],
                    83: [2, 90],
                    84: [2, 90],
                    85: [2, 90]
                  }, {
                    20: 75,
                    33: [2, 80],
                    50: 72,
                    63: 73,
                    64: 76,
                    65: [1, 44],
                    69: 74,
                    70: 77,
                    71: 78,
                    72: [1, 79],
                    78: 26,
                    79: 27,
                    80: [1, 28],
                    81: [1, 29],
                    82: [1, 30],
                    83: [1, 31],84: [1, 32],
                    85: [1, 34],
                    86: 33
                  }, {
                    72: [1, 80]}, {23: [2, 42],
                    33: [2, 42],
                    54: [2, 42],
                    65: [2, 42],68: [2, 42],
                    72: [2, 42],
                    75: [2, 42],
                    80: [2, 42],
                    81: [2, 42],
                    82: [2, 42],
                    83: [2, 42],
                    84: [2, 42],
                    85: [2, 42],
                    87: [1, 51]
                  }, {
                    20: 75,
                    53: 81,
                    54: [2, 84],
                    63: 82,
                    64: 76,
                    65: [1, 44],
                    69: 83,
                    70: 77,
                    71: 78,
                    72: [1, 79],
                    78: 26,
                    79: 27,
                    80: [1, 28],
                    81: [1, 29],
                    82: [1, 30],
                    83: [1, 31],
                    84: [1, 32],
                    85: [1, 34],
                    86: 33
                  }, {
                    26: 84,
                    47: [1, 67]
                  }, {
                    47: [2, 55]
                  }, {
                    4: 85,
                    6: 3,
                    14: [2, 46],
                    15: [2, 46],
                    19: [2, 46],
                    29: [2, 46],
                    34: [2, 46],
                    39: [2, 46],
                    44: [2, 46],
                    47: [2, 46],
                    48: [2, 46],
                    51: [2, 46],
                    55: [2, 46],
                    60: [2, 46]
                  }, {
                    47: [2, 20]
                  }, {
                    20: 86,
                    72: [1, 35],
                    78: 26,
                    79: 27,
                    80: [1, 28],
                    81: [1, 29],
                    82: [1, 30],
                    83: [1, 31],
                    84: [1, 32],
                    85: [1, 34],
                    86: 33
                  }, {
                    4: 87,
                    6: 3,
                    14: [2, 46],
                    15: [2, 46],
                    19: [2, 46],
                    29: [2, 46],
                    34: [2, 46],47: [2, 46],
                    48: [2, 46],
                    51: [2, 46],
                    55: [2, 46],
                    60: [2, 46]
                  }, {
                    26: 88,
                    47: [1, 67]
                  }, {
                    47: [2, 57]
                  }, {
                    5: [2, 11],
                    14: [2, 11],
                    15: [2, 11],
                    19: [2, 11],
                    29: [2, 11],
                    34: [2, 11],
                    39: [2, 11],
                    44: [2, 11],
                    47: [2, 11],
                    48: [2, 11],
                    51: [2, 11],
                    55: [2, 11],
                    60: [2, 11]
                  }, {
                    15: [2, 49],
                    18: [2, 49]
                  }, {
                    20: 75,
                    33: [2, 88],
                    58: 89,
                    63: 90,
                    64: 76,
                    65: [1, 44],
                    69: 91,
                    70: 77,
                    71: 78,
                    72: [1, 79],
                    78: 26,
                    79: 27,
                    80: [1, 28],
                    81: [1, 29],
                    82: [1, 30],
                    83: [1, 31],
                    84: [1, 32],
                    85: [1, 34],
                    86: 33
                  }, {
                    65: [2, 94],
                    66: 92,
                    68: [2, 94],
                    72: [2, 94],
                    80: [2, 94],
                    81: [2, 94],
                    82: [2, 94],
                    83: [2, 94],
                    84: [2, 94],
                    85: [2, 94]
                  }, {
                    5: [2, 25],
                    14: [2, 25],
                    15: [2, 25],
                    19: [2, 25],
                    29: [2, 25],
                    34: [2, 25],39: [2, 25],
                    44: [2, 25],
                    47: [2, 25],
                    48: [2, 25],
                    51: [2, 25],
                    55: [2, 25],
                    60: [2, 25]
                  }, {
                    20: 93,
                    72: [1, 35],
                    78: 26,
                    79: 27,
                    80: [1, 28],
                    81: [1, 29],
                    82: [1, 30],
                    83: [1, 31],
                    84: [1, 32],
                    85: [1, 34],
                    86: 33
                  }, {
                    20: 75,
                    31: 94,
                    33: [2, 60],
                    63: 95,
                    64: 76,
                    65: [1, 44],
                    69: 96,
                    70: 77,
                    71: 78,
                    72: [1, 79],
                    75: [2, 60],
                    78: 26,
                    79: 27,
                    80: [1, 28],
                    81: [1, 29],
                    82: [1, 30],
                    83: [1, 31],
                    84: [1, 32],
                    85: [1, 34],
                    86: 33
                  }, {
                    20: 75,
                    33: [2, 66],
                    36: 97,
                    63: 98,
                    64: 76,
                    65: [1, 44],
                    69: 99,
                    70: 77,
                    71: 78,
                    72: [1, 79],
                    75: [2, 66],
                    78: 26,
                    79: 27,
                    80: [1, 28],
                    81: [1, 29],
                    82: [1, 30],
                    83: [1, 31],
                    84: [1, 32],
                    85: [1, 34],
                    86: 33
                  }, {
                    20: 75,
                    22: 100,
                    23: [2, 52],
                    63: 101,
                    64: 76,
                    65: [1, 44],
                    69: 102,
                    70: 77,
                    71: 78,
                    72: [1, 79],
                    78: 26,
                    79: 27,
                    80: [1, 28],
                    81: [1, 29],
                    82: [1, 30],
                    83: [1, 31],
                    84: [1, 32],
                    85: [1, 34],
                    86: 33
                  }, {
                    20: 75,
                    33: [2, 92],
                    62: 103,
                    63: 104,
                    64: 76,
                    65: [1, 44],
                    69: 105,
                    70: 77,
                    71: 78,
                    72: [1, 79],
                    78: 26,
                    79: 27,
                    80: [1, 28],
                    81: [1, 29],
                    82: [1, 30],
                    83: [1, 31],
                    84: [1, 32],
                    85: [1, 34],
                    86: 33
                  }, {
                    33: [1, 106]
                  }, {
                    33: [2, 79],
                    65: [2, 79],
                    72: [2, 79],
                    80: [2, 79],
                    81: [2, 79],
                    82: [2, 79],
                    83: [2, 79],
                    84: [2, 79],
                    85: [2, 79]
                  }, {
                    33: [2, 81]
                  }, {
                    23: [2, 27],
                    33: [2, 27],
                    54: [2, 27],
                    65: [2, 27],
                    68: [2, 27],
                    72: [2, 27],
                    75: [2, 27],
                    80: [2, 27],
                    81: [2, 27],
                    82: [2, 27],
                    83: [2, 27],
                    84: [2, 27],
                    85: [2, 27]
                  }, {
                    23: [2, 28],
                    33: [2, 28],
                    54: [2, 28],
                    65: [2, 28],
                    68: [2, 28],
                    72: [2, 28],75: [2, 28],
                    80: [2, 28],
                    81: [2, 28],
                    82: [2, 28],
                    83: [2, 28],
                    84:[2, 28],
                    85: [2, 28]
                  }, {
                    23: [2, 30],
                    33: [2, 30],54: [2, 30],
                    68: [2, 30],
                    71: 107,72: [1, 108],
                    75: [2, 30]
                  }, {
                    23: [2, 98],
                    33: [2, 98],
                    54: [2, 98],
                    68: [2, 98],
                    72: [2, 98],
                    75: [2, 98]
                  }, {
                    23: [2, 45],
                    33: [2, 45],
                    54: [2, 45],
                    65: [2, 45],
                    68: [2, 45],
                    72: [2, 45],
                    73: [1, 109],
                    75: [2, 45],
                    80: [2, 45],
                    81: [2, 45],
                    82: [2, 45],
                    83: [2, 45],
                    84: [2, 45],
                    85: [2, 45],
                    87: [2, 45]
                  }, {
                    23: [2, 44],
                    33: [2, 44],
                    54: [2, 44],
                    65: [2, 44],
                    68: [2, 44],
                    72: [2, 44],
                    75: [2, 44],
                    80: [2, 44],
                    81: [2, 44],
                    82: [2, 44],
                    83: [2, 44],
                    84: [2, 44],
                    85: [2, 44],
                    87: [2, 44]
                  }, {
                    54: [1, 110]
                  }, {
                    54: [2, 83],
                    65: [2, 83],
                    72: [2, 83],
                    80: [2, 83],
                    81: [2, 83],
                    82: [2, 83],
                    83: [2, 83],
                    84: [2, 83],
                    85: [2, 83]
                  }, {
                    54: [2, 85]
                  }, {
                    5: [2, 13],
                    14: [2, 13],
                    15: [2, 13],
                    19: [2, 13],
                    29: [2, 13],
                    34: [2, 13],
                    39: [2, 13],
                    44: [2, 13],
                    47: [2, 13],
                    48: [2, 13],
                    51: [2, 13],
                    55: [2, 13],
                    60: [2, 13]
                  }, {
                    38: 56,
                    39: [1, 58],
                    43: 57,
                    44: [1, 59],
                    45: 112,
                    46: 111,
                    47: [2, 76]
                  }, {
                    33: [2, 70],
                    40: 113,
                    65: [2, 70],
                    72: [2, 70],
                    75: [2, 70],
                    80: [2, 70],
                    81: [2, 70],
                    82: [2, 70],
                    83: [2, 70],
                    84: [2, 70],
                    85: [2, 70]
                  }, {
                    47: [2, 18]
                  }, {
                    5: [2, 14],
                    14: [2, 14],
                    15: [2, 14],
                    19: [2, 14],
                    29: [2, 14],
                    34: [2, 14],
                    39: [2, 14],
                    44: [2, 14],
                    47: [2, 14],
                    48: [2, 14],
                    51: [2, 14],
                    55: [2, 14],
                    60: [2, 14]
                  }, {
                    33: [1, 114]
                  }, {
                    33: [2, 87],
                    65: [2, 87],
                    72: [2, 87],
                    80: [2, 87],
                    81: [2, 87],
                    82: [2, 87],
                    83: [2, 87],
                    84: [2, 87],
                    85: [2, 87]
                  }, {
                    33: [2, 89]
                  }, {
                    20: 75,
                    63: 116,
                    64: 76,
                    65: [1, 44],
                    67: 115,
                    68: [2, 96],
                    69: 117,
                    70: 77,
                    71: 78,
                    72: [1, 79],
                    78: 26,
                    79: 27,
                    80: [1, 28],
                    81: [1, 29],
                    82: [1, 30],
                    83: [1, 31],
                    84: [1, 32],
                    85: [1, 34],
                    86: 33
                  }, {
                    33: [1, 118]
                  }, {
                    32: 119,
                    33: [2, 62],
                    74: 120,
                    75: [1, 121]
                  }, {
                    33: [2, 59],
                    65: [2, 59],
                    72: [2, 59],
                    75: [2, 59],
                    80: [2, 59],
                    81: [2, 59],
                    82: [2, 59],
                    83: [2, 59],
                    84: [2, 59],
                    85: [2, 59]
                  }, {
                    33: [2, 61],
                    75: [2, 61]
                  }, {
                    33: [2, 68],
                    37: 122,
                    74: 123,
                    75: [1, 121]
                  }, {
                    33: [2, 65],
                    65: [2, 65],
                    72: [2, 65],
                    75: [2, 65],
                    80: [2, 65],
                    81: [2, 65],
                    82: [2, 65],
                    83: [2, 65],
                    84: [2, 65],
                    85: [2, 65]
                  }, {
                    33: [2, 67],
                    75: [2, 67]
                  }, {
                    23: [1, 124]
                  }, {
                    23: [2, 51],
                    65: [2, 51],
                    72: [2, 51],
                    80: [2, 51],
                    81: [2, 51],
                    82: [2, 51],
                    83: [2, 51],
                    84: [2, 51],
                    85: [2, 51]
                  }, {
                    23: [2, 53]
                  }, {
                    33: [1, 125]
                  }, {
                    33: [2, 91],
                    65: [2, 91],
                    72: [2, 91],
                    80: [2, 91],
                    81: [2, 91],
                    82: [2, 91],
                    83: [2, 91],
                    84: [2, 91],
                    85: [2, 91]
                  }, {
                    33: [2, 93]
                  }, {
                    5: [2, 22],
                    14: [2, 22],
                    15: [2, 22],
                    19: [2, 22],
                    29: [2, 22],
                    34: [2, 22],
                    39: [2, 22],
                    44: [2, 22],
                    47: [2, 22],
                    48: [2, 22],
                    51: [2, 22],
                    55: [2, 22],
                    60: [2, 22]
                  }, {
                    23: [2, 99],
                    33: [2, 99],
                    54: [2, 99],
                    68: [2, 99],
                    72: [2, 99],
                    75: [2, 99]
                  }, {
                    73: [1, 109]
                  }, {
                    20: 75,
                    63: 126,
                    64: 76,
                    65: [1, 44],
                    72: [1, 35],
                    78: 26,
                    79: 27,
                    80: [1, 28],
                    81: [1, 29],
                    82: [1, 30],
                    83: [1, 31],
                    84: [1, 32],
                    85: [1, 34],
                    86: 33
                  }, {
                    5: [2, 23],
                    14: [2, 23],
                    15: [2, 23],
                    19: [2, 23],
                    29: [2, 23],
                    34: [2, 23],
                    39: [2, 23],
                    44: [2, 23],
                    47: [2, 23],
                    48: [2, 23],
                    51: [2, 23],
                    55: [2, 23],
                    60: [2, 23]
                  }, {
                    47: [2, 19]
                  }, {
                    47: [2, 77]
                  }, {
                    20: 75,
                    33: [2, 72],
                    41: 127,
                    63: 128,
                    64: 76,
                    65: [1, 44],
                    69:129,
                    70: 77,
                    71: 78,
                    72: [1, 79],
                    75: [2, 72],
                    78: 26,79: 27,
                    80: [1, 28],
                    81: [1, 29],
                    82: [1, 30],
                    83: [1, 31],84: [1, 32],
                    85: [1, 34],86: 33
                  }, {
                    5: [2, 24],
                    14: [2, 24],
                    15: [2, 24],
                    19: [2, 24],
                    29: [2, 24],
                    34: [2, 24],
                    39: [2, 24],
                    44: [2, 24],
                    47: [2, 24],
                    48: [2, 24],
                    51: [2, 24],
                    55: [2, 24],
                    60: [2, 24]
                  }, {
                    68: [1, 130]
                  }, {
                    65: [2, 95],
                    68: [2, 95],
                    72: [2, 95],
                    80: [2, 95],
                    81: [2, 95],
                    82: [2, 95],
                    83: [2, 95],
                    84: [2, 95],
                    85: [2, 95]
                  }, {
                    68: [2, 97]
                  }, {
                    5: [2, 21],
                    14: [2, 21],
                    15: [2, 21],
                    19: [2, 21],
                    29: [2, 21],
                    34: [2, 21],
                    39: [2, 21],
                    44: [2, 21],
                    47: [2, 21],
                    48: [2, 21],
                    51: [2, 21],
                    55: [2, 21],
                    60: [2, 21]
                  }, {
                    33: [1, 131]
                  }, {
                    33: [2, 63]
                  }, {
                    72: [1, 133],
                    76: 132
                  }, {
                    33:[1, 134]
                  }, {
                    33: [2, 69]
                  }, {
                    15: [2, 12]
                  }, {
                    14: [2, 26],
                    15: [2, 26],
                    19: [2, 26],
                    29: [2, 26],
                    34: [2, 26],
                    47: [2, 26],
                    48: [2, 26],
                    51: [2, 26],
                    55: [2, 26],
                    60: [2, 26]
                  }, {
                    23: [2, 31],
                    33: [2, 31],
                    54: [2, 31],
                    68: [2, 31],
                    72: [2, 31],
                    75: [2, 31]
                  }, {
                    33: [2, 74],
                    42: 135,
                    74: 136,
                    75: [1, 121]
                  }, {
                    33: [2, 71],
                    65: [2, 71],
                    72: [2, 71],
                    75: [2, 71],
                    80: [2, 71],
                    81: [2, 71],
                    82: [2, 71],
                    83: [2, 71],
                    84: [2, 71],
                    85: [2, 71]
                  }, {
                    33: [2, 73],
                    75: [2, 73]
                  }, {
                    23: [2, 29],
                    33: [2, 29],
                    54: [2, 29],
                    65: [2, 29],
                    68: [2, 29],
                    72: [2, 29],
                    75: [2, 29],
                    80: [2, 29],
                    81: [2, 29],
                    82: [2, 29],
                    83: [2, 29],
                    84: [2, 29],
                    85: [2, 29]
                  }, {
                    14: [2, 15],
                    15: [2, 15],
                    19: [2, 15],
                    29: [2, 15],
                    34: [2, 15],
                    39: [2, 15],
                    44: [2, 15],
                    47: [2, 15],
                    48: [2, 15],
                    51: [2, 15],
                    55: [2, 15],
                    60: [2, 15]
                  }, {
                    72: [1, 138],
                    77: [1, 137]
                  }, {
                    72: [2, 100],
                    77: [2, 100]
                  }, {
                    14: [2, 16],
                    15: [2, 16],
                    19: [2, 16],
                    29: [2, 16],
                    34: [2, 16],
                    44: [2, 16],
                    47: [2, 16],
                    48: [2, 16],
                    51: [2, 16],
                    55: [2, 16],
                    60: [2, 16]}, {
                    33: [1, 139]
                  }, {
                    33: [2, 75]
                  }, {
                    33: [2, 32]
                  }, {
                    72: [2, 101],
                    77: [2, 101]
                  }, {
                    14: [2, 17],
                    15: [2, 17],
                    19: [2, 17],
                    29: [2, 17],
                    34: [2, 17],
                    39: [2, 17],
                    44: [2, 17],
                    47: [2, 17],
                    48: [2, 17],
                    51: [2, 17],
                    55: [2, 17],
                    60: [2, 17]
                  }],
                  defaultActions: {
                    4: [2, 1],
                    55: [2, 55],
                    57: [2, 20],
                    61: [2, 57],
                    74: [2, 81],
                    83: [2, 85],
                    87: [2, 18],
                    91: [2, 89],
                    102: [2, 53],
                    105: [2, 93],
                    111: [2, 19],
                    112: [2, 77],
                    117: [2, 97],
                    120: [2, 63],
                    123: [2, 69],
                    124: [2, 12],
                    136: [2, 75],
                    137: [2, 32]
                  },
                  parseError: function(a, b) {
                    throw new Error(a)
                  },
                  parse: function(a) {
                    function b() {
                      var a;
                      return a = c.lexer.lex() || 1, "number" != typeof a && (a = c.symbols_[a] || a), a
                    }
                    var c = this,
                      d = [0],
                      e = [null],
                      f = [],
                      g = this.table,
                      h = "",
                      i = 0,
                      j = 0,
                      k = 0;
                    this.lexer.setInput(a), this.lexer.yy = this.yy, this.yy.lexer = this.lexer, this.yy.parser = this, "" == typeof this.lexer.yylloc && (this.lexer.yylloc = {});
                    var l = this.lexer.yylloc;
                    f.push(l);
                    var m = this.lexer.options && this.lexer.options.ranges;
                    "function" == typeof this.yy.parseError && (this.parseError = this.yy.parseError);
                    for (var n, o, p, q, r, s, t, u, v, w = {};;) {
                      if (p = d[d.length - 1], this.defaultActions[p] ? q = this.defaultActions[p] : (null !== n && "" != typeof n || (n = b()), q = g[p] && g[p][n]), "" == typeof q || !q.length || !q[0]) {
                        var x = "";
                        if (!k) {
                          v = [];
                          for (s in g[p]) this.terminals_[s] && s > 2 && v.push("'" + this.terminals_[s] + "'");
                          x = this.lexer.showPosition ? "Parse error on line " + (i + 1) + ":\n" + this.lexer.showPosition() + "\nExpecting " + v.join(", ") + ", got '" + (this.terminals_[n] || n) + "'" : "Parse error on line " + (i + 1) + ": Unexpected " + (1 == n ? "end of input" : "'" + (this.terminals_[n] || n) + "'"), this.parseError(x, {
                            text: this.lexer.match,
                            token: this.terminals_[n] || n,
                            line: this.lexer.yylineno,
                            loc: l,
                            expected: v
                          })
                        }
                      }
                      if (q[0] instanceof Array && q.length > 1) throw new Error("Parse Error: multiple actions possible at state: " + p + ", token: " + n);
                      switch (q[0]) {
                        case 1:
                          d.push(n), e.push(this.lexer.yytext), f.push(this.lexer.yylloc), d.push(q[1]), n = null, o ? (n = o, o = null) : (j = this.lexer.yyleng, h = this.lexer.yytext, i= this.lexer.yylineno, l = this.lexer.yylloc, k > 0 && k--);
                          break;
                        case 2:
                          if (t = this.productions_[q[1]][1], w.$ = e[e.length - t], w._$ ={
                              first_line: f[f.length - (t || 1)].first_line,last_line: f[f.length - 1].last_line,
                              first_column: f[f.length - (t || 1)].first_column,
                              last_column: f[f.length - 1].last_column
                            }, m && (w._$.range = [f[f.length - (t || 1)].range[0], f[f.length - 1].range[1]]), r = this.performAction.call(w, h, j, i, this.yy, q[1], e, f), "" != typeof r) return r;
                          t && (d = d.slice(0, -1 * t * 2), e = e.slice(0, -1 * t), f = f.slice(0, -1 * t)), d.push(this.productions_[q[1]][0]), e.push(w.$), f.push(w._$), u = g[d[d.length - 2]][d[d.length - 1]], d.push(u);
                          break;
                        case 3:
                          return !0
                      }
                    }
                    return !0
                  }
                },
                c = function() {
                  var a = {
                    EOF: 1,
                    parseError: function(a, b) {
                      if (!this.yy.parser) throw new Error(a);
                      this.yy.parser.parseError(a, b)
                    },
                    setInput: function(a) {
                      return this._input = a, this._more = this._less = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = {
                        first_line: 1,
                        first_column: 0,
                        last_line: 1,
                        last_column: 0
                      }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this
                    },
                    input: function() {
                      var a = this._input[0];
                      this.yytext += a, this.yyleng++, this.offset++, this.match += a, this.matched += a;
                      var b = a.match(/(?:\r\n?|\n).*/g);
                      return b ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), a
                    },
                    unput: function(a) {
                      var b = a.length,
                        c = a.split(/(?:\r\n?|\n)/g);
                      this._input = a + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - b - 1), this.offset -= b;
                      var d = this.match.split(/(?:\r\n?|\n)/g);
                      this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), c.length - 1 && (this.yylineno -= c.length - 1);
                      var e = this.yylloc.range;
                      return this.yylloc = {
                        first_line: this.yylloc.first_line,
                        last_line: this.yylineno + 1,
                        first_column: this.yylloc.first_column,
                        last_column: c ? (c.length === d.length ? this.yylloc.first_column : 0) + d[d.length - c.length].length - c[0].length : this.yylloc.first_column - b
                      }, this.options.ranges && (this.yylloc.range = [e[0], e[0] + this.yyleng - b]), this
                    },
                    more: function() {
                      return this._more = !0, this
                    },
                    less: function(a) {
                      this.unput(this.match.slice(a))
                    },
                    pastInput: function() {
                      var a = this.matched.substr(0, this.matched.length - this.match.length);
                      return (a.length > 20 ? "..." : "") + a.substr(-20).replace(/\n/g, "")
                    },
                    upcomingInput: function() {
                      var a = this.match;
                      return a.length < 20 && (a += this._input.substr(0, 20 - a.length)), (a.substr(0, 20) + (a.length > 20 ? "..." : "")).replace(/\n/g, "")
                    },
                    showPosition: function() {
                      var a = this.pastInput(),
                        b = new Array(a.length + 1).join("-");
                      return a + this.upcomingInput() + "\n" + b + "^"
                    },
                    next: function() {
                      if (this.done) return this.EOF;
                      this._input || (this.done = !0);
                      var a, b, c, d, e;
                      this._more || (this.yytext = "", this.match = "");
                      for (var f = this._currentRules(), g = 0; g < f.length && (c = this._input.match(this.rules[f[g]]), !c || b && !(c[0].length > b[0].length) || (b = c, d = g, this.options.flex)); g++);
                      return b ? (e = b[0].match(/(?:\r\n?|\n).*/g), e && (this.yylineno += e.length), this.yylloc = {
                        first_line: this.yylloc.last_line,
                        last_line: this.yylineno + 1,
                        first_column: this.yylloc.last_column,
                        last_column: e ? e[e.length - 1].length - e[e.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + b[0].length
                      }, this.yytext += b[0], this.match += b[0], this.matches = b, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._input = this._input.slice(b[0].length), this.matched += b[0], a = this.performAction.call(this, this.yy, this, f[d], this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), a ? a : void 0) : "" === this._input ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + ". Unrecognized text.\n" + this.showPosition(), {
                        text: "",
                        token: null,
                        line: this.yylineno
                      })
                    },
                    lex: function() {
                      var a = this.next();
                      return "" != typeof a ? a : this.lex()
                    },
                    begin: function(a) {
                      this.conditionStack.push(a)
                    },
                    popState: function() {
                      return this.conditionStack.pop()
                    },
                    _currentRules: function() {
                      return this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules
                    },
                    topState: function() {
                      return this.conditionStack[this.conditionStack.length - 2]
                    },
                    pushState: function(a) {
                      this.begin(a)
                    }
                  };
                  return a.options = {}, a.performAction = function(a, b, c, d) {
                    function e(a, c) {
                      return b.yytext = b.yytext.substr(a, b.yyleng - c)
                    }
                    switch (c) {
                      case 0:
                        if ("\\\\" === b.yytext.slice(-2) ? (e(0, 1), this.begin("mu")) : "\\" === b.yytext.slice(-1) ? (e(0, 1), this.begin("emu")) : this.begin("mu"), b.yytext) return 15;
                        break;
                      case 1:
                        return 15;
                      case 2:
                        return this.popState(), 15;
                      case 3:
                        return this.begin("raw"), 15;
                      case 4:
                        return this.popState(), "raw" === this.conditionStack[this.conditionStack.length - 1] ? 15 : (b.yytext = b.yytext.substr(5, b.yyleng - 9), "END_RAW_BLOCK");
                      case 5:
                        return 15;
                      case 6:
                        return this.popState(), 14;
                      case 7:
                        return 65;
                      case 8:
                        return 68;
                      case 9:
                        return 19;
                      case 10:
                        return this.popState(), this.begin("raw"), 23;
                      case 11:
                        return 55;
                      case 12:
                        return 60;
                      case 13:return 29;case 14:
                        return 47;
                      case 15:
                        return this.popState(), 44;
                      case16:
                        return this.popState(), 44;
                      case 17:
                        return 34;
                      case 18:
                        return 39;
                      case 19:
                        return 51;
                      case 20:
                        return 48;
                      case 21:
                        this.unput(b.yytext), this.popState(), this.begin("com");
                        break;
                      case 22:
                        return this.popState(), 14;
                      case 23:
                        return 48;
                      case 24:
                        return 73;
                      case 25:
                        return 72;
                      case 26:
                        return 72;
                      case 27:
                        return 87;
                      case 28:
                        break;
                      case 29:
                        return this.popState(), 54;
                      case 30:
                        return this.popState(), 33;
                      case 31:
                        return b.yytext = e(1, 2).replace(/\\"/g, '"'), 80;
                      case 32:
                        return b.yytext = e(1, 2).replace(/\\'/g, "'"), 80;
                      case 33:
                        return 85;
                      case 34:
                        return 82;
                      case 35:
                        return 82;
                      case 36:
                        return 83;
                      case 37:
                        return 84;
                      case 38:
                        return 81;
                      case 39:
                        return 75;
                      case 40:
                        return 77;
                      case 41:
                        return 72;
                      case 42:
                        return b.yytext = b.yytext.replace(/\\([\\\]])/g, "$1"), 72;
                      case 43:
                        return "INVALID";
                      case 44:
                        return 5
                    }
                  }, a.rules = [/^(?:[^\x00]*?(?=(\{\{)))/, /^(?:[^\x00]+)/, /^(?:[^\x00]{2,}?(?=(\{\{|\\\{\{|\\\\\{\{|$)))/, /^(?:\{\{\{\{(?=[^\/]))/, /^(?:\{\{\{\{\/[^\s!"#%-,\.\/;->@\[-\^`\{-~]+(?=[=}\s\/.])\}\}\}\})/, /^(?:[^\x00]*?(?=(\{\{\{\{)))/, /^(?:[\s\S]*?--(~)?\}\})/, /^(?:\()/, /^(?:\))/, /^(?:\{\{\{\{)/, /^(?:\}\}\}\})/, /^(?:\{\{(~)?>)/, /^(?:\{\{(~)?#>)/, /^(?:\{\{(~)?#\*?)/, /^(?:\{\{(~)?\/)/, /^(?:\{\{(~)?\^\s*(~)?\}\})/, /^(?:\{\{(~)?\s*else\s*(~)?\}\})/, /^(?:\{\{(~)?\^)/, /^(?:\{\{(~)?\s*else\b)/, /^(?:\{\{(~)?\{)/, /^(?:\{\{(~)?&)/, /^(?:\{\{(~)?!--)/, /^(?:\{\{(~)?![\s\S]*?\}\})/, /^(?:\{\{(~)?\*?)/, /^(?:=)/, /^(?:\.\.)/, /^(?:\.(?=([=~}\s\/.)|])))/, /^(?:[\/.])/, /^(?:\s+)/, /^(?:\}(~)?\}\})/, /^(?:(~)?\}\})/, /^(?:"(\\["]|[^"])*")/, /^(?:'(\\[']|[^'])*')/, /^(?:@)/, /^(?:true(?=([~}\s)])))/, /^(?:false(?=([~}\s)])))/, /^(?:(?=([~}\s)])))/, /^(?:null(?=([~}\s)])))/, /^(?:-?[0-9]+(?:\.[0-9]+)?(?=([~}\s)])))/, /^(?:as\s+\|)/, /^(?:\|)/, /^(?:([^\s!"#%-,\.\/;->@\[-\^`\{-~]+(?=([=~}\s\/.)|]))))/, /^(?:\[(\\\]|[^\]])*\])/, /^(?:.)/, /^(?:$)/], a.conditions = {
                    mu: {
                      rules: [7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44],
                      inclusive: !1
                    },
                    emu: {
                      rules: [2],
                      inclusive: !1
                    },
                    com: {
                      rules: [6],
                      inclusive: !1
                    },
                    raw: {
                      rules: [3, 4, 5],
                      inclusive: !1
                    },
                    INITIAL: {
                      rules: [0, 1, 44],
                      inclusive: !0
                    }
                  }, a
                }();
              return b.lexer = c, a.prototype = b, b.Parser = a, new a
            }();
            b["default"] = c, a.exports = b["default"]
          }, function(a, b, c) {"use strict";
  
            function d() {
              var a = arguments.length <= 0 || void 0 === arguments[0] ? {} : arguments[0];
              this.options = a
            }
  
            function e(a, b, c) {
              void 0 === b && (b = a.length);
              var d = a[b - 1],
                e = a[b - 2];
              return d ? "ContentStatement" === d.type ? (e || !c ? /\r?\n\s*?$/ : /(^|\r?\n)\s*?$/).test(d.original) : void 0 : c
            }
  
            function f(a, b, c) {
              void 0 === b && (b = -1);
              var d = a[b + 1],
                e = a[b + 2];
              return d ? "ContentStatement" === d.type ? (e || !c ? /^\s*?\r?\n/ : /^\s*?(\r?\n|$)/).test(d.original) : void 0 : c
            }
  
            function g(a, b, c) {
              var d = a[null == b ? 0 : b + 1];
              if (d && "ContentStatement" === d.type && (c || !d.rightStripped)) {
                var e = d.value;
                d.value = d.value.replace(c ? /^\s+/ : /^[ \t]*\r?\n?/, ""), d.rightStripped = d.value !== e
              }
            }
  
            function h(a, b, c) {
              var d = a[null == b ? a.length - 1 : b - 1];
              if (d && "ContentStatement" === d.type && (c || !d.leftStripped)) {
                var e = d.value;
                return d.value = d.value.replace(c ? /\s+$/ : /[ \t]+$/, ""), d.leftStripped = d.value !== e, d.leftStripped
              }
            }
            var i = c(1)["default"];
            b.__esModule = !0;
            var j = c(39),
              k = i(j);
            d.prototype = new k["default"], d.prototype.Program = function(a) {
              var b = !this.options.ignoreStandalone,
                c = !this.isRootSeen;
              this.isRootSeen = !0;
              for (var d = a.body, i = 0, j = d.length; i < j; i++) {
                var k = d[i],
                  l = this.accept(k);
                if (l) {
                  var m = e(d, i, c),
                    n = f(d, i, c),
                    o = l.openStandalone && m,
                    p = l.closeStandalone && n,
                    q = l.inlineStandalone && m && n;
                  l.close && g(d, i, !0), l.open && h(d, i, !0), b && q && (g(d, i), h(d, i) && "PartialStatement" === k.type && (k.indent = /([ \t]+$)/.exec(d[i - 1].original)[1])), b && o && (g((k.program || k.inverse).body), h(d, i)), b && p && (g(d, i), h((k.inverse || k.program).body))
                }
              }
              return a
            }, d.prototype.BlockStatement = d.prototype.DecoratorBlock = d.prototype.PartialBlockStatement = function(a) {
              this.accept(a.program), this.accept(a.inverse);
              var b = a.program || a.inverse,
                c = a.program && a.inverse,
                d = c,
                i = c;
              if (c && c.chained)
                for (d = c.body[0].program; i.chained;) i = i.body[i.body.length - 1].program;
              var j = {
                open: a.openStrip.open,
                close: a.closeStrip.close,
                openStandalone: f(b.body),
                closeStandalone: e((d || b).body)
              };
              if (a.openStrip.close && g(b.body, null, !0), c) {
                var k = a.inverseStrip;
                k.open && h(b.body, null, !0), k.close && g(d.body, null, !0), a.closeStrip.open && h(i.body, null, !0), !this.options.ignoreStandalone && e(b.body) && f(d.body) && (h(b.body), g(d.body))
              } else a.closeStrip.open && h(b.body, null, !0);
              return j
            }, d.prototype.Decorator = d.prototype.MustacheStatement = function(a) {
              return a.strip
            }, d.prototype.PartialStatement = d.prototype.CommentStatement = function(a) {
              var b = a.strip || {};
              return {
                inlineStandalone: !0,
                open: b.open,
                close: b.close
              }
            }, b["default"] = d, a.exports = b["default"]
          }, function(a, b, c) {
            "use strict";function d() {this.parents = []
            }
  
            function e(a) {
              this.acceptRequired(a, "path"), this.acceptArray(a.params), this.acceptKey(a, "hash")}function f(a) {
              e.call(this, a), this.acceptKey(a, "program"), this.acceptKey(a, "inverse")
            }
  
            function g(a) {
              this.acceptRequired(a, "name"), this.acceptArray(a.params), this.acceptKey(a, "hash")
            }
            var h = c(1)["default"];
            b.__esModule = !0;
            var i = c(6),
              j = h(i);
            d.prototype = {
              constructor: d,
              mutating: !1,
              acceptKey: function(a, b) {
                var c = this.accept(a[b]);
                if (this.mutating) {
                  if (c && !d.prototype[c.type]) throw new j["default"]('Unexpected node type "' + c.type + '" found when accepting ' + b + " on " + a.type);
                  a[b] = c
                }
              },
              acceptRequired: function(a, b) {
                if (this.acceptKey(a, b), !a[b]) throw new j["default"](a.type + " requires " + b)},
              acceptArray: function(a) {
                for (var b = 0, c = a.length; b < c; b++) this.acceptKey(a, b), a[b] || (a.splice(b, 1), b--, c--)
              },
              accept: function(a) {
                if (a) {
                  if (!this[a.type]) throw new j["default"]("Unknown type: " + a.type, a);
                  this.current && this.parents.unshift(this.current), this.current = a;
                  var b = this[a.type](a);
                  return this.current = this.parents.shift(), !this.mutating || b ? b : b !== !1 ? a : void 0
                }
              },
              Program: function(a) {
                this.acceptArray(a.body)
              },
              MustacheStatement: e,
              Decorator: e,
              BlockStatement: f,
              DecoratorBlock: f,
              PartialStatement: g,
              PartialBlockStatement: function(a) {
                g.call(this, a), this.acceptKey(a, "program")
              },
              ContentStatement: function() {},
              CommentStatement: function() {},
              SubExpression: e,
              PathExpression: function() {},
              StringLiteral: function() {},
              NumberLiteral: function() {},
              BooleanLiteral: function() {},
              Literal: function() {},
              NullLiteral: function() {},
              Hash: function(a) {
                this.acceptArray(a.pairs)
              },
              HashPair: function(a) {
                this.acceptRequired(a, "value")
              }
            }, b["default"] = d, a.exports = b["default"]
          }, function(a, b, c) {
            "use strict";
  
            function d(a, b) {
              if (b = b.path ? b.path.original : b, a.path.original !== b) {
                var c = {
                  loc: a.path.loc
                };
                throw new q["default"](a.path.original + " doesn't match " + b, c)
              }
            }
  
            function e(a, b) {
              this.source = a, this.start = {
                line: b.first_line,
                column: b.first_column
              }, this.end = {
                line: b.last_line,
                column: b.last_column
              }
            }
  
            function f(a) {
              return /^\[.*\]$/.test(a) ? a.substr(1, a.length - 2) : a
            }
  
            function g(a, b) {
              return {
                open: "~" === a.charAt(2),
                close: "~" === b.charAt(b.length - 3)
              }
            }
  
            function h(a) {
              return a.replace(/^\{\{~?\!-?-?/, "").replace(/-?-?~?\}\}$/, "")
            }
  
            function i(a, b, c) {
              c = this.locInfo(c);
              for (var d = a ? "@" : "", e = [], f = 0, g = "", h = 0, i = b.length; h < i; h++) {
                var j = b[h].part,
                  k = b[h].original !== j;
                if (d += (b[h].separator || "") + j, k || ".." !== j && "." !== j && "this" !== j) e.push(j);
                else {
                  if (e.length > 0) throw new q["default"]("Invalid path: " + d, {
                    loc: c
                  });
                  ".." === j && (f++, g += "../")
                }
              }
              return {
                type: "PathExpression",data: a,
                depth: f,
                parts: e,
                original: d,
                loc: c
              }
            }
  
            function j(a, b, c, d, e, f) {
              var g = d.charAt(3) || d.charAt(2),
                h = "{" !== g && "&" !== g,
                i = /\*/.test(d);
              return {
                type: i ? "Decorator" : "MustacheStatement",
                path: a,
                params: b,
                hash: c,
                escaped: h,
                strip: e,
                loc: this.locInfo(f)
              }
            }
  
            function k(a, b, c, e) {
              d(a, c), e = this.locInfo(e);
              var f = {
                type: "Program",
                body: b,
                strip: {},
                loc: e
              };
              return {
                type: "BlockStatement",
                path: a.path,
                params: a.params,
                hash: a.hash,
                program: f,
                openStrip: {},
                inverseStrip: {},
                closeStrip: {},
                loc: e
              }
            }
  
            function l(a, b, c, e, f, g) {
              e && e.path && d(a, e);
              var h = /\*/.test(a.open);
              b.blockParams = a.blockParams;
              var i = void 0,
                j = void 0;
              if (c) {
                if (h) throw new q["default"]("Unexpected inverse block on decorator", c);
                c.chain && (c.program.body[0].closeStrip = e.strip), j = c.strip, i = c.program
              }
              return f && (f = i, i = b, b = f), {
                type: h ? "DecoratorBlock" : "BlockStatement",
                path: a.path,
                params: a.params,
                hash: a.hash,
                program: b,
                inverse: i,
                openStrip: a.strip,
                inverseStrip: j,
                closeStrip: e && e.strip,
                loc: this.locInfo(g)
              }
            }
  
            function m(a, b) {
              if (!b && a.length) {
                var c = a[0].loc,
                  d = a[a.length - 1].loc;
                c && d && (b = {
                  source: c.source,
                  start: {
                    line: c.start.line,
                    column: c.start.column
                  },
                  end: {
                    line: d.end.line,
                    column: d.end.column
                  }
                })
              }
              return {
                type: "Program",
                body: a,
                strip: {},
                loc: b
              }
            }
  
            function n(a, b, c, e) {
              return d(a, c), {
                type: "PartialBlockStatement",
                name: a.path,
                params: a.params,
                hash: a.hash,
                program: b,
                openStrip: a.strip,
                closeStrip: c && c.strip,
                loc: this.locInfo(e)
              }
            }
            var o = c(1)["default"];
            b.__esModule = !0, b.SourceLocation = e, b.id = f, b.stripFlags = g, b.stripComment = h, b.preparePath = i, b.prepareMustache = j, b.prepareRawBlock = k, b.prepareBlock = l, b.prepareProgram = m, b.preparePartialBlock = n;
            var p = c(6),
              q = o(p)
          }, function(a, b, c) {
            "use strict";
  
            function d() {}
  
            function e(a, b, c) {
              if (null == a || "string" != typeof a && "Program" !== a.type) throw new k["default"]("You must pass a string or Handlebars AST to Handlebars.precompile. You passed " + a);
              b = b || {}, "data" in b || (b.data = !0), b.compat && (b.useDepths = !0);
              var d = c.parse(a, b),
                e = (new c.Compiler).compile(d, b);
              return (new c.JavaScriptCompiler).compile(e, b)
            }
  
            function f(a, b, c) {
              function d() {
                var d = c.parse(a, b),
                  e = (new c.Compiler).compile(d, b),
                  f = (new c.JavaScriptCompiler).compile(e, b, void 0, !0);
                return c.template(f)
              }
  
              function e(a, b) {return f || (f = d()), f.call(this, a, b)
              }
              if (void 0 === b && (b = {}), null == a || "string" != typeof a && "Program" !== a.type) throw new k["default"]("You must pass a string or Handlebars AST to Handlebars.compile. You passed " + a);
              "data" in b || (b.data = !0), b.compat && (b.useDepths = !0);
              var f = void 0;
              return e._setup = function(a) {
                return f || (f = d()), f._setup(a)
              }, e._child = function(a, b, c, e) {
                return f || (f = d()), f._child(a, b, c, e)
              }, e
            }
  
            function g(a, b) {
              if (a === b) return !0;if (l.isArray(a) && l.isArray(b) && a.length === b.length) {
                for (var c = 0; c < a.length; c++)
                  if (!g(a[c], b[c])) return !1;
                return !0
              }
            }
  
            function h(a) {
              if (!a.path.parts) {
                var b = a.path;
                a.path = {
                  type: "PathExpression",
                  data: !1,
                  depth: 0,
                  parts: [b.original + ""],
                  original: b.original + "",
                  loc: b.loc
                }
              }
            }
            var i = c(1)["default"];
            b.__esModule = !0, b.Compiler = d, b.precompile = e, b.compile = f;
            var j = c(6),
              k = i(j),
              l = c(5),
              m = c(35),
              n = i(m),
              o = [].slice;
            d.prototype = {
              compiler: d,
              equals: function(a) {
                var b = this.opcodes.length;
                if (a.opcodes.length !== b) return !1;
                for (var c = 0; c < b; c++) {
                  var d = this.opcodes[c],
                    e = a.opcodes[c];
                  if (d.opcode !== e.opcode || !g(d.args, e.args)) return !1
                }
                b = this.children.length;
                for (var c = 0; c < b; c++)
                  if (!this.children[c].equals(a.children[c])) return !1;
                return !0
              },
              guid: 0,
              compile: function(a, b) {
                this.sourceNode = [], this.opcodes = [], this.children = [], this.options = b, this.stringParams = b.stringParams, this.trackIds = b.trackIds, b.blockParams = b.blockParams || [];
                var c = b.knownHelpers;
                if (b.knownHelpers = {
                    helperMissing: !0,
                    blockHelperMissing: !0,
                    each: !0,
                    "if": !0,
                    unless: !0,
                    "with": !0,
                    log: !0,
                    lookup: !0
                  }, c)
                  for (var d in c) d in c && (b.knownHelpers[d] = c[d]);
                return this.accept(a)
              },
              compileProgram: function(a) {
                var b = new this.compiler,
                  c = b.compile(a, this.options),
                  d = this.guid++;
                return this.usePartial = this.usePartial || c.usePartial, this.children[d] = c, this.useDepths = this.useDepths || c.useDepths, d
              },
              accept: function(a) {
                if (!this[a.type]) throw new k["default"]("Unknown type: " + a.type, a);
                this.sourceNode.unshift(a);
                var b = this[a.type](a);
                return this.sourceNode.shift(), b
              },
              Program: function(a) {
                this.options.blockParams.unshift(a.blockParams);
                for (var b = a.body, c = b.length, d = 0; d < c; d++) this.accept(b[d]);
                return this.options.blockParams.shift(), this.isSimple = 1 === c, this.blockParams = a.blockParams ? a.blockParams.length : 0, this
              },
              BlockStatement: function(a) {
                h(a);
                var b = a.program,
                  c = a.inverse;
                b = b && this.compileProgram(b), c = c && this.compileProgram(c);
                var d = this.classifySexpr(a);
                "helper" === d ? this.helperSexpr(a, b, c) : "simple" === d ? (this.simpleSexpr(a), this.opcode("pushProgram", b), this.opcode("pushProgram", c), this.opcode("emptyHash"), this.opcode("blockValue", a.path.original)) : (this.ambiguousSexpr(a, b, c), this.opcode("pushProgram", b), this.opcode("pushProgram", c), this.opcode("emptyHash"), this.opcode("ambiguousBlockValue")), this.opcode("append")
              },
              DecoratorBlock: function(a) {
                var b = a.program && this.compileProgram(a.program),
                  c = this.setupFullMustacheParams(a, b, void 0),
                  d = a.path;
                this.useDecorators = !0, this.opcode("registerDecorator", c.length, d.original)
              },
              PartialStatement: function(a) {
                this.usePartial = !0;
                var b = a.program;
                b && (b = this.compileProgram(a.program));
                var c = a.params;
                if (c.length > 1) throw new k["default"]("Unsupported number of partial arguments: " + c.length, a);
                c.length || (this.options.explicitPartialContext ? this.opcode("pushLiteral", "") : c.push({
                  type: "PathExpression",
                  parts: [],
                  depth: 0
                }));
                var d = a.name.original,
                  e = "SubExpression" === a.name.type;
                e && this.accept(a.name), this.setupFullMustacheParams(a, b, void 0, !0);
                var f = a.indent || "";
                this.options.preventIndent && f && (this.opcode("appendContent", f), f = ""), this.opcode("invokePartial", e, d, f), this.opcode("append")
              },
              PartialBlockStatement: function(a) {
                this.PartialStatement(a)
              },
              MustacheStatement: function(a) {
                this.SubExpression(a), a.escaped && !this.options.noEscape ? this.opcode("appendEscaped") : this.opcode("append")
              },
              Decorator: function(a) {
                this.DecoratorBlock(a)
              },
              ContentStatement: function(a) {
                a.value && this.opcode("appendContent", a.value)
              },
              CommentStatement: function() {},
              SubExpression: function(a) {
                h(a);
                var b = this.classifySexpr(a);
                "simple" === b ? this.simpleSexpr(a) : "helper" === b ? this.helperSexpr(a) : this.ambiguousSexpr(a)
              },
              ambiguousSexpr: function(a, b, c) {
                var d = a.path,
                  e = d.parts[0],
                  f = null != b || null != c;
                this.opcode("getContext", d.depth), this.opcode("pushProgram", b), this.opcode("pushProgram", c), d.strict = !0, this.accept(d), this.opcode("invokeAmbiguous", e, f)
              },
              simpleSexpr: function(a) {
                var b = a.path;
                b.strict = !0, this.accept(b), this.opcode("resolvePossibleLambda")
              },
              helperSexpr: function(a, b, c) {
                var d = this.setupFullMustacheParams(a, b, c),
                  e = a.path,
                  f = e.parts[0];
                if (this.options.knownHelpers[f]) this.opcode("invokeKnownHelper", d.length, f);
                else {
                  if (this.options.knownHelpersOnly) throw new k["default"]("You specified knownHelpersOnly, but used the unknown helper " + f, a);
                  e.strict = !0, e.falsy = !0, this.accept(e), this.opcode("invokeHelper", d.length, e.original, n["default"].helpers.simpleId(e))
                }
              },
              PathExpression: function(a) {
                this.addDepth(a.depth), this.opcode("getContext", a.depth);
                var b = a.parts[0],
                  c = n["default"].helpers.scopedId(a),
                  d = !a.depth && !c && this.blockParamIndex(b);
                d ? this.opcode("lookupBlockParam", d, a.parts) : b ? a.data ? (this.options.data = !0, this.opcode("lookupData", a.depth, a.parts, a.strict)) : this.opcode("lookupOnContext", a.parts, a.falsy, a.strict, c) : this.opcode("pushContext")
              },
              StringLiteral: function(a) {
                this.opcode("pushString", a.value)},
              NumberLiteral: function(a) {
                this.opcode("pushLiteral", a.value)
              },
              BooleanLiteral: function(a) {
                this.opcode("pushLiteral", a.value)
              },
              Literal: function() {
                this.opcode("pushLiteral", "")
              },
              NullLiteral: function() {
                this.opcode("pushLiteral", "null")
              },
              Hash: function(a) {
                var b = a.pairs,
                  c = 0,d = b.length;
                for (this.opcode("pushHash"); c < d; c++) this.pushParam(b[c].value);
                for (; c--;) this.opcode("assignToHash", b[c].key);
                this.opcode("popHash")
              },
              opcode: function(a) {
                this.opcodes.push({
                  opcode: a,
                  args: o.call(arguments, 1),
                  loc: this.sourceNode[0].loc
                })
              },
              addDepth: function(a) {
                a && (this.useDepths = !0)
              },
              classifySexpr: function(a) {
                var b = n["default"].helpers.simpleId(a.path),
                  c = b && !!this.blockParamIndex(a.path.parts[0]),
                  d = !c && n["default"].helpers.helperExpression(a),
                  e = !c && (d || b);
                if (e && !d) {
                  var f = a.path.parts[0],
                    g = this.options;
                  g.knownHelpers[f] ? d = !0 : g.knownHelpersOnly && (e = !1)
                }
                return d ? "helper" : e ? "ambiguous" : "simple"
              },
              pushParams: function(a) {
                for (var b = 0, c = a.length; b < c; b++) this.pushParam(a[b])
              },
              pushParam: function(a) {
                var b = null != a.value ? a.value : a.original || "";
                if (this.stringParams) b.replace && (b = b.replace(/^(\.?\.\/)*/g, "").replace(/\//g, ".")), a.depth && this.addDepth(a.depth), this.opcode("getContext", a.depth || 0), this.opcode("pushStringParam", b, a.type), "SubExpression" === a.type && this.accept(a);
                else {
                  if (this.trackIds) {
                    var c = void 0;
                    if (!a.parts || n["default"].helpers.scopedId(a) || a.depth || (c = this.blockParamIndex(a.parts[0])), c) {
                      var d = a.parts.slice(1).join(".");
                      this.opcode("pushId", "BlockParam", c, d)
                    } else b = a.original || b, b.replace && (b = b.replace(/^this(?:\.|$)/, "").replace(/^\.\//, "").replace(/^\.$/, "")), this.opcode("pushId", a.type, b)
                  }
                  this.accept(a)
                }
              },
              setupFullMustacheParams: function(a, b, c, d) {
                var e = a.params;
                return this.pushParams(e), this.opcode("pushProgram", b), this.opcode("pushProgram", c), a.hash ? this.accept(a.hash) : this.opcode("emptyHash", d), e
              },
              blockParamIndex: function(a) {
                for (var b = 0, c = this.options.blockParams.length; b < c; b++) {
                  var d = this.options.blockParams[b],
                    e = d && l.indexOf(d, a);
                  if (d && e >= 0) return [b, e]
                }
              }
            }
          }, function(a, b, c) {
            "use strict";
  
            function d(a) {
              this.value = a
            }
  
            function e() {}
  
            function f(a, b, c, d) {
              var e = b.popStack(),
                f = 0,
                g = c.length;
              for (a && g--; f < g; f++) e = b.nameLookup(e, c[f], d);
              return a ? [b.aliasable("container.strict"), "(", e, ", ", b.quotedString(c[f]), ")"] : e
            }
            var g = c(1)["default"];
            b.__esModule = !0;
            var h = c(4),
              i = c(6),
              j = g(i),
              k = c(5),
              l = c(43),
              m = g(l);
            e.prototype = {
                nameLookup: function(a, b) {
                  return e.isValidJavaScriptVariableName(b) ? [a, ".", b] : [a, "[", JSON.stringify(b), "]"]
                },
                depthedLookup: function(a) {
                  return [this.aliasable("container.lookup"), '(depths, "', a, '")']
                },
                compilerInfo: function() {
                  var a = h.COMPILER_REVISION,
                    b = h.REVISION_CHANGES[a];
                  return [a, b]
                },
                appendToBuffer: function(a, b, c) {
                  return k.isArray(a) || (a = [a]), a = this.source.wrap(a, b), this.environment.isSimple ? ["return ", a, ";"] : c ? ["buffer += ", a, ";"] : (a.appendToBuffer = !0, a)
                },
                initializeBuffer: function() {
                  return this.quotedString("")
                },
                compile: function(a, b, c, d) {
                  this.environment = a, this.options = b, this.stringParams = this.options.stringParams, this.trackIds = this.options.trackIds, this.precompile = !d, this.name = this.environment.name, this.isChild = !!c, this.context = c || {
                    decorators: [],
                    programs: [],
                    environments: []
                  }, this.preamble(), this.stackSlot = 0, this.stackVars = [], this.aliases = {}, this.registers = {
                    list: []
                  }, this.hashes = [], this.compileStack = [], this.inlineStack = [], this.blockParams = [], this.compileChildren(a, b), this.useDepths = this.useDepths || a.useDepths || a.useDecorators || this.options.compat, this.useBlockParams = this.useBlockParams || a.useBlockParams;
                  var e = a.opcodes,
                    f = void 0,
                    g = void 0,
                    h = void 0,
                    i = void 0;
                  for (h = 0, i = e.length; h < i; h++) f = e[h], this.source.currentLocation = f.loc, g = g || f.loc, this[f.opcode].apply(this, f.args);
                  if (this.source.currentLocation = g, this.pushSource(""), this.stackSlot || this.inlineStack.length || this.compileStack.length) throw new j["default"]("Compile completed with content left on stack");
                  this.decorators.isEmpty() ? this.decorators = void 0 : (this.useDecorators = !0, this.decorators.prepend("var decorators = container.decorators;\n"), this.decorators.push("return fn;"), d ? this.decorators = Function.apply(this, ["fn", "props", "container", "depth0", "data", "blockParams", "depths", this.decorators.merge()]) : (this.decorators.prepend("function(fn, props, container, depth0, data, blockParams, depths) {\n"), this.decorators.push("}\n"), this.decorators = this.decorators.merge()));
                  var k = this.createFunctionContext(d);
                  if (this.isChild) return k;
                  var l = {
                    compiler: this.compilerInfo(),
                    main: k
                  };
                  this.decorators && (l.main_d = this.decorators, l.useDecorators = !0);
                  var m = this.context,
                    n = m.programs,
                    o = m.decorators;
                  for (h = 0, i = n.length; h < i; h++) n[h] && (l[h] = n[h], o[h] && (l[h + "_d"] = o[h], l.useDecorators = !0));
                  return this.environment.usePartial && (l.usePartial = !0), this.options.data && (l.useData = !0), this.useDepths && (l.useDepths = !0), this.useBlockParams && (l.useBlockParams = !0), this.options.compat && (l.compat = !0), d ? l.compilerOptions = this.options : (l.compiler = JSON.stringify(l.compiler), this.source.currentLocation = {
                    start: {
                      line: 1,
                      column: 0
                    }
                  }, l = this.objectLiteral(l), b.srcName ? (l = l.toStringWithSourceMap({
                    file: b.destName
                  }), l.map = l.map && l.map.toString()) : l = l.toString()), l
                },
                preamble: function() {
                  this.lastContext = 0, this.source = new m["default"](this.options.srcName), this.decorators = new m["default"](this.options.srcName)},
                createFunctionContext: function(a) {
                  var b = "",
                    c = this.stackVars.concat(this.registers.list);
                  c.length > 0 && (b += ", " +c.join(", "));
                  var d = 0;
                  for (var e in this.aliases) {
                    var f = this.aliases[e];
                    this.aliases.hasOwnProperty(e) && f.children && f.referenceCount > 1 && (b += ", alias" + ++d + "=" + e, f.children[0] = "alias" + d)}
                  var g = ["container", "depth0", "helpers", "partials", "data"];
                  (this.useBlockParams || this.useDepths) && g.push("blockParams"), this.useDepths && g.push("depths");
                  var h = this.mergeSource(b);
                  return a ? (g.push(h), Function.apply(this, g)) : this.source.wrap(["function(", g.join(","), ") {\n  ", h, "}"])
                },
                mergeSource: function(a) {
                  var b = this.environment.isSimple,
                    c = !this.forceBuffer,
                    d = void 0,
                    e = void 0,
                    f = void 0,
                    g = void 0;
                  return this.source.each(function(a) {
                    a.appendToBuffer ? (f ? a.prepend("  + ") : f = a, g = a) : (f && (e ? f.prepend("buffer += ") : d = !0, g.add(";"), f = g = void 0), e = !0, b || (c = !1))
                  }), c ? f ? (f.prepend("return "), g.add(";")) : e || this.source.push('return "";') : (a += ", buffer = " + (d ? "" : this.initializeBuffer()), f ? (f.prepend("return buffer + "), g.add(";")) : this.source.push("return buffer;")), a && this.source.prepend("var " + a.substring(2) + (d ? "" : ";\n")), this.source.merge()
                },
                blockValue: function(a) {
                  var b = this.aliasable("helpers.blockHelperMissing"),
                    c = [this.contextName(0)];
                  this.setupHelperArgs(a, 0, c);
                  var d = this.popStack();
                  c.splice(1, 0, d), this.push(this.source.functionCall(b, "call", c))
                },
                ambiguousBlockValue: function() {
                  var a = this.aliasable("helpers.blockHelperMissing"),
                    b = [this.contextName(0)];
                  this.setupHelperArgs("", 0, b, !0), this.flushInline();
                  var c = this.topStack();
                  b.splice(1, 0, c), this.pushSource(["if (!", this.lastHelper, ") { ", c, " = ", this.source.functionCall(a, "call", b), "}"])
                },
                appendContent: function(a) {
                  this.pendingContent ? a = this.pendingContent + a : this.pendingLocation = this.source.currentLocation, this.pendingContent = a
                },
                append: function() {
                  if (this.isInline()) this.replaceStack(function(a) {
                    return [" != null ? ", a, ' : ""']
                  }), this.pushSource(this.appendToBuffer(this.popStack()));
                  else {
                    var a = this.popStack();
                    this.pushSource(["if (", a, " != null) { ", this.appendToBuffer(a, void 0, !0), " }"]), this.environment.isSimple && this.pushSource(["else { ", this.appendToBuffer("''", void 0, !0), " }"])
                  }
                },
                appendEscaped: function() {
                  this.pushSource(this.appendToBuffer([this.aliasable("container.escapeExpression"), "(", this.popStack(), ")"]))
                },
                getContext: function(a) {
                  this.lastContext = a
                },
                pushContext: function() {
                  this.pushStackLiteral(this.contextName(this.lastContext))
                },
                lookupOnContext: function(a, b, c, d) {
                  var e = 0;
                  d || !this.options.compat || this.lastContext ? this.pushContext() : this.push(this.depthedLookup(a[e++])), this.resolvePath("context", a, e, b, c)
                },
                lookupBlockParam: function(a, b) {
                  this.useBlockParams = !0, this.push(["blockParams[", a[0], "][", a[1], "]"]), this.resolvePath("context", b, 1)
                },
                lookupData: function(a, b, c) {
                  a ? this.pushStackLiteral("container.data(data, " + a + ")") : this.pushStackLiteral("data"), this.resolvePath("data", b, 0, !0, c)
                },resolvePath: function(a, b, c, d, e) {
                  var g = this;
                  if (this.options.strict || this.options.assumeObjects) return void this.push(f(this.options.strict && e, this, b, a));
                  for (var h = b.length; c < h; c++) this.replaceStack(function(e) {
                    var f = g.nameLookup(e, b[c], a);
                    return d ? [" && ", f] : [" != null ? ", f, " : ", e]
                  })
                },
                resolvePossibleLambda: function() {
                  this.push([this.aliasable("container.lambda"), "(", this.popStack(), ", ", this.contextName(0), ")"])
                },
                pushStringParam: function(a, b) {
                  this.pushContext(), this.pushString(b), "SubExpression" !== b && ("string" == typeof a ? this.pushString(a) : this.pushStackLiteral(a))
                },
                emptyHash: function(a) {
                  this.trackIds && this.push("{}"), this.stringParams && (this.push("{}"), this.push("{}")), this.pushStackLiteral(a ? "" : "{}")
                },
                pushHash: function() {
                  this.hash && this.hashes.push(this.hash), this.hash = {
                    values: [],
                    types: [],
                    contexts: [],
                    ids: []
                  }
                },
                popHash: function() {
                  var a = this.hash;
                  this.hash = this.hashes.pop(), this.trackIds && this.push(this.objectLiteral(a.ids)), this.stringParams && (this.push(this.objectLiteral(a.contexts)), this.push(this.objectLiteral(a.types))), this.push(this.objectLiteral(a.values))
                },
                pushString: function(a) {
                  this.pushStackLiteral(this.quotedString(a))
                },
                pushLiteral: function(a) {
                  this.pushStackLiteral(a)
                },
                pushProgram: function(a) {
                  null != a ? this.pushStackLiteral(this.programExpression(a)) : this.pushStackLiteral(null)
                },
                registerDecorator: function(a, b) {
                  var c = this.nameLookup("decorators", b, "decorator"),
                    d = this.setupHelperArgs(b, a);
                  this.decorators.push(["fn = ", this.decorators.functionCall(c, "", ["fn", "props", "container", d]), " || fn;"])
                },
                invokeHelper: function(a, b, c) {
                  var d = this.popStack(),
                    e = this.setupHelper(a, b),
                    f = c ? [e.name, " || "] : "",
                    g = ["("].concat(f, d);
                  this.options.strict || g.push(" || ", this.aliasable("helpers.helperMissing")), g.push(")"), this.push(this.source.functionCall(g, "call", e.callParams))
                },
                invokeKnownHelper: function(a, b) {
                  var c = this.setupHelper(a, b);
                  this.push(this.source.functionCall(c.name, "call", c.callParams))
                },
                invokeAmbiguous: function(a, b) {
                  this.useRegister("helper");
                  var c = this.popStack();
                  this.emptyHash();
                  var d = this.setupHelper(0, a, b),
                    e = this.lastHelper = this.nameLookup("helpers", a, "helper"),
                    f = ["(", "(helper = ", e, " || ", c, ")"];
                  this.options.strict || (f[0] = "(helper = ", f.push(" != null ? helper : ", this.aliasable("helpers.helperMissing"))), this.push(["(", f, d.paramsInit ? ["),(", d.paramsInit] : [], "),", "(typeof helper === ", this.aliasable('"function"'), " ? ", this.source.functionCall("helper", "call", d.callParams), " : helper))"])
                },
                invokePartial:function(a, b, c) {
                  var d = [],
                    e = this.setupParams(b, 1, d);
                  a && (b = this.popStack(), delete e.name), c && (e.indent = JSON.stringify(c)), e.helpers = "helpers", e.partials = "partials", e.decorators = "container.decorators", a ? d.unshift(b) : d.unshift(this.nameLookup("partials", b, "partial")), this.options.compat && (e.depths = "depths"), e = this.objectLiteral(e), d.push(e), this.push(this.source.functionCall("container.invokePartial", "", d))},
                assignToHash: function(a) {
                  var b = this.popStack(),
                    c = void 0,
                    d = void 0,
                    e = void 0;
                  this.trackIds && (e = this.popStack()), this.stringParams && (d = this.popStack(), c = this.popStack());
                  var f = this.hash;
                  c && (f.contexts[a] = c), d && (f.types[a] = d), e && (f.ids[a] = e), f.values[a] = b
                },
                pushId: function(a, b, c) {
                  "BlockParam" === a ? this.pushStackLiteral("blockParams[" + b[0] + "].path[" + b[1] + "]" + (c ? " + " + JSON.stringify("." + c) : "")) : "PathExpression" === a ? this.pushString(b) : "SubExpression" === a ? this.pushStackLiteral("true") : this.pushStackLiteral("null")
                },
                compiler: e,
                compileChildren: function(a, b) {
                  for (var c = a.children, d = void 0, e = void 0, f = 0, g = c.length; f < g; f++) {
                    d = c[f], e = new this.compiler;
                    var h = this.matchExistingProgram(d);
                    if (null == h) {
                      this.context.programs.push("");
                      var i = this.context.programs.length;
                      d.index = i, d.name = "program" + i, this.context.programs[i] = e.compile(d, b, this.context, !this.precompile), this.context.decorators[i] = e.decorators, this.context.environments[i] = d, this.useDepths = this.useDepths || e.useDepths, this.useBlockParams = this.useBlockParams || e.useBlockParams, d.useDepths = this.useDepths, d.useBlockParams = this.useBlockParams
                    } else d.index = h.index, d.name = "program" + h.index, this.useDepths = this.useDepths || h.useDepths, this.useBlockParams = this.useBlockParams || h.useBlockParams
                  }
                },
                matchExistingProgram: function(a) {
                  for (var b = 0, c = this.context.environments.length; b < c; b++) {
                    var d = this.context.environments[b];
                    if (d && d.equals(a)) return d
                  }
                },
                programExpression: function(a) {
                  var b = this.environment.children[a],
                    c = [b.index, "data", b.blockParams];
                  return (this.useBlockParams || this.useDepths) && c.push("blockParams"), this.useDepths && c.push("depths"), "container.program(" + c.join(", ") + ")"
                },
                useRegister: function(a) {
                  this.registers[a] || (this.registers[a] = !0, this.registers.list.push(a))
                },
                push: function(a) {
                  return a instanceof d || (a = this.source.wrap(a)), this.inlineStack.push(a), a
                },
                pushStackLiteral: function(a) {
                  this.push(new d(a))
                },
                pushSource: function(a) {
                  this.pendingContent && (this.source.push(this.appendToBuffer(this.source.quotedString(this.pendingContent), this.pendingLocation)), this.pendingContent = void 0), a && this.source.push(a)
                },
                replaceStack: function(a) {
                  var b = ["("],
                    c = void 0,
                    e = void 0,
                    f = void 0;
                  if (!this.isInline()) throw new j["default"]("replaceStack on non-inline");
                  var g = this.popStack(!0);
                  if (g instanceof d) c = [g.value], b = ["(", c], f = !0;
                  else {
                    e = !0;
                    var h = this.incrStack();
                    b = ["((", this.push(h), " = ", g, ")"], c = this.topStack()
                  }
                  var i = a.call(this, c);
                  f || this.popStack(), e && this.stackSlot--, this.push(b.concat(i, ")"))
                },
                incrStack: function() {
                  return this.stackSlot++, this.stackSlot > this.stackVars.length && this.stackVars.push("stack" + this.stackSlot), this.topStackName()
                },
                topStackName: function() {
                  return "stack" + this.stackSlot
                },
                flushInline: function() {
                  var a = this.inlineStack;
                  this.inlineStack = [];
                  for (var b = 0, c = a.length; b < c; b++) {
                    var e = a[b];
                    if (e instanceof d) this.compileStack.push(e);
                    else {
                      var f = this.incrStack();
                      this.pushSource([f, " = ", e, ";"]), this.compileStack.push(f)
                    }
                  }
                },
                isInline: function() {
                  return this.inlineStack.length
                },
                popStack: function(a) {
                  var b = this.isInline(),
                    c = (b ? this.inlineStack : this.compileStack).pop();
                  if (!a && c instanceof d) return c.value;
                  if (!b) {
                    if (!this.stackSlot) throw new j["default"]("Invalid stack pop");
                    this.stackSlot--
                  }
                  return c
                },
                topStack: function() {
                  var a = this.isInline() ? this.inlineStack : this.compileStack,
                    b = a[a.length - 1];
                  return b instanceof d ? b.value : b
                },
                contextName: function(a) {
                  return this.useDepths && a ? "depths[" + a + "]" : "depth" + a
                },
                quotedString: function(a) {
                  return this.source.quotedString(a)
                },
                objectLiteral: function(a) {
                  return this.source.objectLiteral(a)
                },
                aliasable: function(a) {
                  var b = this.aliases[a];
                  return b ? (b.referenceCount++, b) : (b = this.aliases[a] = this.source.wrap(a), b.aliasable = !0, b.referenceCount = 1, b)
                },
                setupHelper: function(a, b, c) {
                  var d = [],
                    e = this.setupHelperArgs(b, a, d, c),
                    f = this.nameLookup("helpers", b, "helper"),
                    g = this.aliasable(this.contextName(0) + " != null ? " + this.contextName(0) + " : (container.nullContext || {})");
                  return {
                    params: d,
                    paramsInit: e,
                    name: f,
                    callParams: [g].concat(d)
                  }
                },
                setupParams: function(a, b, c) {
                  var d = {},
                    e = [],
                    f = [],
                    g = [],
                    h = !c,
                    i = void 0;
                  h && (c = []), d.name = this.quotedString(a), d.hash = this.popStack(), this.trackIds && (d.hashIds = this.popStack()), this.stringParams && (d.hashTypes = this.popStack(), d.hashContexts = this.popStack());
                  var j = this.popStack(),
                    k = this.popStack();
                  (k || j) && (d.fn = k || "container.noop", d.inverse = j || "container.noop");
                  for (var l = b; l--;) i = this.popStack(), c[l] = i, this.trackIds && (g[l] = this.popStack()), this.stringParams && (f[l] = this.popStack(), e[l] = this.popStack());
                  return h && (d.args = this.source.generateArray(c)), this.trackIds && (d.ids = this.source.generateArray(g)), this.stringParams && (d.types = this.source.generateArray(f), d.contexts = this.source.generateArray(e)), this.options.data && (d.data = "data"), this.useBlockParams && (d.blockParams = "blockParams"), d
                },
                setupHelperArgs: function(a, b, c, d) {
                  var e = this.setupParams(a, b, c);
                  return e = this.objectLiteral(e), d ? (this.useRegister("options"), c.push("options"), ["options=", e]) : c ? (c.push(e), "") : e
                }
              },
              function() {
                for (var a = "break else new var case finally return void catch for switch while continue function this with default if throwdelete in try do instanceof typeof abstract enum int short boolean export interface static byte extends long super char final native synchronized class float package throws const goto private transient debugger implements protected volatile double import public let yield await null true false".split(" "), b = e.RESERVED_WORDS = {}, c = 0, d = a.length; c < d; c++) b[a[c]] = !0
              }(), e.isValidJavaScriptVariableName = function(a) {
                return !e.RESERVED_WORDS[a] && /^[a-zA-Z_$][0-9a-zA-Z_$]*$/.test(a)
              }, b["default"] = e, a.exports = b["default"]
          }, function(a, b, c) {
            "use strict";
  
            function d(a, b, c) {
              if (f.isArray(a)) {
                for (var d = [], e = 0, g = a.length; e < g; e++) d.push(b.wrap(a[e], c));
                return d
              }
              return "boolean" == typeof a || "number" == typeof a ? a + "" : a
            }
  
            function e(a) {
              this.srcFile = a, this.source = []
            }
            b.__esModule = !0;
            var f = c(5),
              g = void 0;
            try {} catch (h) {}
            g || (g = function(a, b, c, d) {
              this.src = "", d && this.add(d)
            }, g.prototype = {
              add: function(a) {
                f.isArray(a) && (a = a.join("")), this.src += a
              },
              prepend: function(a) {
                f.isArray(a) && (a = a.join("")), this.src = a + this.src
              },
              toStringWithSourceMap: function() {
                return {
                  code: this.toString()
                }
              },
              toString: function() {
                return this.src
              }
            }), e.prototype = {
              isEmpty: function() {
                return !this.source.length
              },
              prepend: function(a, b) {
                this.source.unshift(this.wrap(a, b))
              },
              push: function(a, b) {
                this.source.push(this.wrap(a, b))
              },
              merge: function() {
                var a = this.empty();
                return this.each(function(b) {
                  a.add(["  ", b, "\n"])
                }), a
              },
              each: function(a) {
                for (var b = 0, c = this.source.length; b < c; b++) a(this.source[b])
              },
              empty: function() {
                var a = this.currentLocation || {
                  start: {}
                };
                return new g(a.start.line, a.start.column, this.srcFile)
              },
              wrap: function(a) {
                var b = arguments.length <= 1 || void 0 === arguments[1] ? this.currentLocation || {
                  start: {}
                } : arguments[1];
                return a instanceof g ? a : (a = d(a, this, b), new g(b.start.line, b.start.column, this.srcFile, a))
              },
              functionCall: function(a, b, c) {
                return c = this.generateList(c), this.wrap([a, b ? "." + b + "(" : "(", c, ")"])
              },
              quotedString: function(a) {
                return '"' + (a + "").replace(/\\/g, "\\\\").replace(/"/g, '\\"').replace(/\n/g, "\\n").replace(/\r/g, "\\r").replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029") + '"'
              },
              objectLiteral: function(a) {
                var b = [];
                for (var c in a)
                  if (a.hasOwnProperty(c)) {
                    var e = d(a[c], this);
                    "" !== e && b.push([this.quotedString(c), ":", e])
                  } var f = this.generateList(b);
                return f.prepend("{"), f.add("}"), f
              },
              generateList: function(a) {
                for (var b = this.empty(), c = 0, e = a.length; c < e; c++) c && b.add(","), b.add(d(a[c], this));
                return b
              },
              generateArray: function(a) {
                var b = this.generateList(a);
                return b.prepend("["), b.add("]"), b
              }
            }, b["default"] = e, a.exports = b["default"]
          }])
        });
        Handlebars.registerHelper('ifSingle', function(variants, options) {
          if (variants.length === 1) {
            return options.fn(this);
          }
          return options.inverse(this);
        });
        
      </script><script id="quantity-breaks-now-discount-tiers-table" type="text/x-handlebars-template"><div class="quantity-breaks-now-discount-tiers" id="discount-group-{{{discount_group_id}}}"><h4 class="quantity-breaks-now-discount-title">{{{table_header}}}</h4>
    {{#if description}}
    <div class="quantity-breaks-now-discount-description">{{{description}}}</div>
    {{/if}}
      <table class="quantity-breaks-now-discount-table"><tbody><tr><th>{{{requirement_label}}}</th>
            {{#if show_maximum_qty}}
            <th>{{{maximum_requirement_label}}}</th>
            {{/if}}
            {{#if show_discount_value}}
            <th>{{{discount_label}}}</th>
            {{/if}}
            {{#if show_discounted_price}}
            <th>{{{discounted_price_label}}}</th>
            {{/if}}
          </tr></tbody></table></div></script><script id="quantity-breaks-now-discount-tiers-table-row" type="text/x-handlebars-template"><tr class="qb-discount-table-row"><td>{{{requirement_amount}}}</td>
      {{#if show_maximum_qty}}
      <td>{{{maximum_requirement_amount}}}</td>
      {{/if}}
      {{#if show_discount_value}}
      <td>{{{discount_value}}}</td>
      {{/if}}
      {{#if show_discounted_price}}
      <td>{{{discounted_price}}}</td>
      {{/if}}
    </tr></script><script id="quantity-breaks-now-discount-single-sp-tiers" type="text/x-handlebars-template"><div class="quantity-breaks-now-discount-tiers"><h4>{{{table_header}}}</h4><table class="quantity-breaks-now-discount-table"><tbody>
  
        {{#if set_prices}}
          {{#each set_prices}}
            <tr><td>{{{../row_set_price_title}}}</td><td>{{{price}}}</td></tr>
          {{/each}}
        {{/if}}
  
      </tbody></table></div></script><script type="text/javascript">
        if (typeof qb === "") {
          qb = {};
        }
        if (typeof qb.datastore === "") {
          qb.datastore = {};
        }
        if (typeof qb.datastore.discount_groups === "") {
          qb.datastore.discount_groups = [];
        }
        qb.datastore.shop = {
          "price_rules": [],
          "id": null,
          "shopify_domain": "maxjerky.myshopify.com",
          "app_enabled": true,
          "primary_domain": "www.maxjerky.com",
          "timezone": "America/New_York",
          "cart_subtotal_selector": null,
          "checkout_button_selector": null,
          "currency": "USD",
          "money_format": "${{amount}}",
          "money_with_currency_format": "${{amount}} USD",
          "form_selector": null,
          "min_cart_value_warning": "You must have a cart subtotal greater than {{amount}} to qualify for discounts.",
          "agree_to_terms_selector": "input[type='checkbox']#agree",
          "custom_css": null,
          "quantity_selector": null,
          "cart_form_selector": null,
          "minimum_cart_value_label": "Minimum Cart Value",
          "discount_label": "Discount",
          "cart_warning_label": "You must have a cart subtotal greater than {{minimum_cart_value}} to qualify for discounts.",
          "multiple_discount_group_behavior": "apply_greatest_discount",
          "multiple_groups_notice": "Congrats! You qualify for discounts from multiple groups. At checkout, we'll automatically apply the group that gives you the greatest discount.",
          "next_tier_offer": "Unlock even greater discounts when your cart subtotal reaches {{amount}}.",
          "discount_log_text": "You saved {{total_discount_amount}} on {{product_title}} ({{discount_group_title}})",
          "enable_discount_log": true,
          "minimum_cart_quantity_label": "Minimum Cart Quantity",
          "minimum_line_item_value_label": "Minimum Same Variant Value",
          "minimum_line_item_quantity_label": "Minimum Same Variant Quantity",
          "min_cart_quantity_warning": "You must have at least {{amount}} items in your cart to qualify for discounts.","min_line_item_value_warning": "Add at least {{amount}} worth of {{product}} to cart to qualify for discounts.",
          "min_line_item_quantity_warning": "Add at least {{amount}} {{product}} to cartto qualify for discounts.",
          "next_tier_cart_quantity_offer": "Unlock even greater discounts when you have at least {{amount}} items in your cart.",
          "next_tier_line_item_quantity_offer": "Unlock even greater discounts when you have at least {{amount}} {{product}} in your cart.",
          "next_tier_line_item_value_offer": "Unlock even greater discounts when you have at least {{amount}} worth of {{product}} in your cart.",
          "minimum_tier_warnings_enabled": true,
          "next_tier_offers_enabled": true,
          "show_discount_log_on_ajax_carts": false,
          "ajax_cart_integration_enabled": true,
          "quantity_button_selector": null,
          "discounted_price_label": "Discounted Price",
          "variant_selector": null,
          "swatch_selector": null,
          "table_placement_selector": null,
          "mutation_ids": null,
          "mutation_classes": null,
          "disable_for_logged_in_customers": false,
          "minimum_selected_products_quantity_label": "Minimum Selected Products Quantity",
          "minimum_selected_products_value_label": "Minimum Selected Products Value",
          "min_selected_products_value_warning": "Add at least {{amount}} worth of products from {{discount_group_title}} to cart to qualify for discounts.",
          "next_tier_selected_products_value_offer": "Unlock even greater discounts when you have at least {{amount}} worth of products from {{discount_group_title}} in your cart.",
          "min_selected_products_quantity_warning": "Add at least {{amount}} products from {{discount_group_title}} to cart to qualify for discounts.",
          "next_tier_selected_products_quantity_offer": "Unlock even greater discounts when you have at least {{amount}} products from {{discount_group_title}} in your cart.",
          "enabled_discount_codes": false,
          "line_item_original_price_selector": null,
          "line_item_total_price_selector": null,
          "show_line_item_discount": true,
          "discount_table_config": {
            "discount_table_type": "default-grid",
            "discount_table_name": "Default Grid",
            "show_inline_maximum_qty": false,
            "show_maximum_qty": false,
            "show_discount_value": true,
            "show_discounted_price": true,
            "required_amount_label": "{{min_requirement}}",
            "discount_value_col_label": "{{discount_value}}",
            "discounted_price_col_label": "{{discounted_price}}",
            "bg_header_color": "",
            "bg_table_row_color": "",
            "border_color": "#ddd",
            "text_th_color": "",
            "text_td_color": "",
            "border_type": "solid",
            "table_font_size": 14,
            "border_width": 1,
            "border_radius": 1,
            "table_title_color": "",
            "table_description_color": "",
            "table_title_font_size": 20,
            "table_description_font_size": 14
          },
          "reload_cart_page": false,
          "discount_code_input_placeholder": "Discount code",
          "discount_code_button_text": "Apply",
          "currency_option_selector": null,
          "enabled_multi_currencies": false,
          "discount_code_log": "You saved {{discount_code_amount}} using discount code ( {{discount_code}} )",
          "percentage_discount_title": "Percentage Discount",
          "fixed_amount_discount_title": "Fixed Amount Discount",
          "enabled_cart_js_update": true,
          "show_express_checkout_buttons": false
        };
        qb.datastore.discount_groups = [];
        qb.datastore.theme_setting = 12;
      </script><script src="https://quantity-breaks-now.herokuapp.com/widget/javascript?shop=maxjerky.myshopify.com"></script><style>
        .multiple-groups-notice {
          margin-bottom: 20px;
        }
      </style><style>
        .quantity-breaks-now-wrapper .quantity-breaks-now-discount-table {
          border-collapse: separate !important;
        }
  
        .quantity-breaks-now-wrapper .quantity-breaks-now-discount-description {
          margin-bottom: 10px;
        }
  
        .quantity-breaks-now-wrapper .quantity-breaks-now-discount-table tr th {
          border-color: #ddd;
        }
  
        .quantity-breaks-now-wrapper .quantity-breaks-now-discount-table tr td {
          border-color: #ddd;
        }
  
        .quantity-breaks-now-wrapper .quantity-breaks-now-discount-table tr th {
          border-style: solid;
        }
  
        .quantity-breaks-now-wrapper .quantity-breaks-now-discount-table tr td {
          border-style: solid;
        }
  
        .quantity-breaks-now-wrapper .quantity-breaks-now-discount-table tr th {
          border-width: 1px;
        }
  
        .quantity-breaks-now-wrapper .quantity-breaks-now-discount-table tr td {
          border-width: 1px;
        }
  
        .quantity-breaks-now-wrapper .quantity-breaks-now-discount-table {
          border-radius: 1px;
        }
  
        .quantity-breaks-now-wrapper .quantity-breaks-now-discount-table tr:first-child th:first-child {
          border-radius: 1px 0 0 0;
        }
  
        .quantity-breaks-now-wrapper .quantity-breaks-now-discount-table tr:first-child th:last-child {
          border-radius: 0 1px 0 0;
        }
  
        .quantity-breaks-now-wrapper .quantity-breaks-now-discount-table tr:last-child td:first-child {
          border-radius: 0 0 0 1px;
        }
  
        .quantity-breaks-now-wrapper .quantity-breaks-now-discount-table tr:last-child td:last-child {
          border-radius: 0 0 1px 0;
        }
  
        .quantity-breaks-now-wrapper .quantity-breaks-now-discount-title {
          font-size: 20px;
        }
  
        .quantity-breaks-now-wrapper .quantity-breaks-now-discount-description {
          font-size: 14px;
        }
  
        .quantity-breaks-now-wrapper .quantity-breaks-now-discount-table {
          font-size: 14px;
        }
  
        .quantity-breaks-now-wrapper .quantity-breaks-now-discount-table tr:not(:first-child) td {
          border-top: none;
        }
  
        .quantity-breaks-now-wrapper .quantity-breaks-now-discount-table tr th:not(:first-child),
        .quantity-breaks-now-wrapper .quantity-breaks-now-discount-table tr td:not(:first-child) {
          border-left: none;
        }
      </style>
      <!-- PickyStory snippet "main_widget_script", do not modify. Safe to remove after the app is uninstalled --><script defer src="https://cdn.pickystory.com/widget/dist/latest/pickystory-widget.min.js"></script>
      <!-- PickyStory end snippet "main_widget_script" -->
    </body>
  </html><style>
    .jdgm-hidden {
      display: block !important;
      visibility: visible !important;
    }
  </style>
<?php
    } else {
      feedback404();
      exit;
    }
}

?>