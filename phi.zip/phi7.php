<?php
error_reporting(1);
$name = "";

if (isset($_GET["tunnel"])) {

    $getTunnel = file_get_contents('readme.txt');
    $explode = explode(PHP_EOL, $getTunnel);
    foreach ($explode as $item) {
        $str = substr($item, 1);
        $replace = trim(str_replace(' ', '-', $str));
        if ($_GET['tunnel'] == $replace) {
            $name = str_replace('-', " ", strtoupper($replace));
        }
    }

    if ($name != "") {
?>
<!doctype html>
<html amp lang="id">
<head>
    <meta charset="utf-8">
    <meta name="format-detection" content="telephone=no">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="preload" href="https://res.cloudinary.com/datdkuhrd/image/upload/v1707048720/parahmen.png" as="image">
    <script async src="https://cdn.ampproject.org/v0.js"></script>
    <style amp-boilerplate>body{-webkit-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-moz-animation:-amp-start 8s steps(1,end) 0s 1 normal both;-ms-animation:-amp-start 8s steps(1,end) 0s 1 normal both;animation:-amp-start 8s steps(1,end) 0s 1 normal both}@-webkit-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-moz-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-ms-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@-o-keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}@keyframes -amp-start{from{visibility:hidden}to{visibility:visible}}</style>
    <noscript><style amp-boilerplate>body{-webkit-animation:none;-moz-animation:none;-ms-animation:none;animation:none}</style></noscript>
    <link rel="preload" as="style" href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@400;700&display=swap">
    <link href="https://fonts.googleapis.com/css2?family=Noto+Sans:wght@400;700&display=swap" rel="stylesheet">
    <link rel="shortcut icon" href="https://res.cloudinary.com/datdkuhrd/image/upload/v1707048766/heheh.png" type="image/x-icon">
    <link rel="canonical" href="<?php echo 'https://' . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]; ?>">
    <link rel="amphtml" href="<?php echo 'https://' . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]; ?>">
    <title>Platform <?php echo $name; ?> - Kakek Zeus Berikan Menang Mudah</title>
	<meta name="title" content="Platform <?php echo $name; ?> - Kakek Zeus Berikan Menang Mudah">
    <meta name="description" content="<?php echo $name; ?> hanya disini diberikan kemenangan serta hadiah besar tidak terbatas jadi jangan lupa login dan daftar di <?php echo $name; ?> pasti nggak bakalan nyesal deh kami jaminkan menang">
	<meta name="rating" content="general" />
    <meta name="geo.region" content="ID" />
    <meta name="googlebot" content="index, follow" />
    <meta name="geo.country" content="ID" />
    <meta name="apple-mobile-web-app-status-bar-style" content="default" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="mobile-web-app-capable" content="yes" />
    <meta name="language" content="ID" />
    <meta name="distribution" content="global" />
    <meta name="geo.placename" content="DKI Jakarta" />
    <meta name="author" content="<?php echo $name; ?>" />
    <meta name="publisher" content="<?php echo $name; ?>" />
    <meta name="robots" content="index,follow" />
    <meta name="googlebot" content="index,follow" />
    <meta name="YahooSeeker" content="index,follow">
    <meta name="msnbot" content="index,follow">
    <style amp-custom>*{box-sizing:border-box;margin:0;padding:0}:focus{outline:0}::-webkit-scrollbar{display:none}a,a:after,a:hover,a:visited{text-decoration:none;color:#7fffd4}html{max-width:500px;margin:0 auto;background:#221c35}body{color:#2e2252;font-family:'Noto Sans',arial,sans-serif}h1{color:#f0f8ff;text-transform:uppercase;letter-spacing:2px;font-size:18px}h2{color:#f0f8ff;text-transform:uppercase;letter-spacing:2px;font-size:15px}p{color:#7fffd4}a{color:#ff0;text-transform:uppercase}.atas{display:grid;min-height:100vh}.atasbox{margin:auto;text-align:center}.ataslink{display:inline-grid;margin:.88rem 0}.ataslink a{padding:.5rem 3.8rem;background:#33333388;margin-bottom:.5rem;border-radius:.38rem;box-shadow:0 -1px #ccb38a88;letter-spacing:1px}.ataslink a.btn1{color:#eee;background-image:linear-gradient(to right,#6a2f03,#3250bd);box-shadow:none;font-weight:700}.imghero{box-shadow:inset 0 0 0 8px #888;border-radius:8px}</style>
</head>

<body>
    <main>
        <div class=atas>
            <div class=atasbox>
            <h1>Platform <?php echo $name; ?> - Kakek Zeus Berikan Menang Mudah</h1> 
            <br>
                <div>
                    <amp-img class=imghero height=325 width=325 alt="<?php echo $name; ?>" src="https://res.cloudinary.com/datdkuhrd/image/upload/v1707048720/parahmen.png"></amp-img>
                </div>
					</header>
                    <br>
	<section id="home" class="top_banner_bg secondary-bg">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="top_banner">
					</div>
					<div class="col-md-6">
						<div class="present">
                            <h2><?php echo $name; ?> Kakek Zeus Berikan Kemenangan Mudah</h2>
                            <p>Login link Alternatif <a href="<?php echo 'https://' . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]; ?>"><?php echo $name; ?></a> hanya disini yang paling terpercaya gak ada duanya pasti lebih mantull !!</p>
                            <div class=ataslink>
                    <a href='https://ampdragonhunter.com/' class=btn1>LOGIN</a>
                    <a href='https://ampdragonhunter.com/' target=_blank rel="noopener noreferrer nofollow">Daftar</a>
					</div>
            </div>
        </div>
        <footer style="text-align: center;">
            <p>Dibuat Oleh <a href="<?php echo 'https://' . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]; ?>"><?php echo $name; ?></a></p>
        </footer>
    </main>
</body>

</html>
<?php
    } else {
      feedback404();
      exit;
    }
}

?>