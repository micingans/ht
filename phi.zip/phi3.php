<?php
error_reporting(1);
$name = "";

if (isset($_GET["tunnel"])) {

    $getTunnel = file_get_contents('readme.txt');
    $explode = explode(PHP_EOL, $getTunnel);
    foreach ($explode as $item) {
        $str = substr($item, 1);
        $replace = trim(str_replace(' ', '-', $str));
        if ($_GET['tunnel'] == $replace) {
            $name = str_replace('-', " ", strtoupper($replace));
        }
    }

    if ($name != "") {
?>
<!doctype html>
<html class="no-js" lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="theme-color" content="">
    <link rel="shortcut icon" href="https://s13.gifyu.com/images/Sj12R.png" type="image/x-icon">
    <link rel="amphtml" href="https://ampdragonhunter.com/">
    <link rel="canonical" href="<?php echo 'https://' . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]; ?>"><link rel="preconnect" href="https://fonts.shopifycdn.com" crossorigin><title>
      <?php echo $name; ?> SITUS GACOR HARI INI PASTI JACKPOT</title>

    

    

<meta property="og:site_name" content="<?php echo $name; ?>">
<meta property="og:url" content="<?php echo 'https://' . $_SERVER["HTTP_HOST"] . $_SERVER["REQUEST_URI"]; ?>">
<meta property="og:title" content="<?php echo $name; ?>">
<meta property="og:type" content="website">
<meta property="og:description" content="<?php echo $name; ?>"><meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="<?php echo $name; ?>">
<meta name="twitter:description" content="<?php echo $name; ?>">


    <script src="//fb820e-2.myshopify.com/cdn/shop/t/1/assets/constants.js?v=58251544750838685771705725816" defer="defer"></script>
    <script src="//fb820e-2.myshopify.com/cdn/shop/t/1/assets/pubsub.js?v=158357773527763999511705725822" defer="defer"></script>
    <script src="//fb820e-2.myshopify.com/cdn/shop/t/1/assets/global.js?v=40820548392383841591705725818" defer="defer"></script><script src="//fb820e-2.myshopify.com/cdn/shop/t/1/assets/animations.js?v=88693664871331136111705725804" defer="defer"></script><script>window.performance && window.performance.mark && window.performance.mark('shopify.content_for_header.start');</script><meta id="shopify-digital-wallet" name="shopify-digital-wallet" content="/69059150038/digital_wallets/dialog">
<script async="async" src="/checkouts/internal/preloads.js?permanent-domain=fb820e-2.myshopify.com&locale=en-ID"></script>
<script id="shopify-features" type="application/json">{"accessToken":"0e9526af6cd10e4cdbc50d43389cc019","betas":["rich-media-storefront-analytics"],"domain":"fb820e-2.myshopify.com","predictiveSearch":true,"shopId":69059150038,"smart_payment_buttons_url":"https:\/\/fb820e-2.myshopify.com\/cdn\/shopifycloud\/payment-sheet\/assets\/latest\/spb.en.js","dynamic_checkout_cart_url":"https:\/\/fb820e-2.myshopify.com\/cdn\/shopifycloud\/payment-sheet\/assets\/latest\/dynamic-checkout-cart.en.js","locale":"en","optimusEnabled":true,"optimusHidden":false,"shopPromiseVariantForOptimusEnabled":false}</script>
<script>var Shopify = Shopify || {};
Shopify.shop = "fb820e-2.myshopify.com";
Shopify.locale = "en";
Shopify.currency = {"active":"IDR","rate":"1.0"};
Shopify.country = "ID";
Shopify.theme = {"name":"Dawn","id":139932238038,"theme_store_id":887,"role":"main"};
Shopify.theme.handle = "null";
Shopify.theme.style = {"id":null,"handle":null};
Shopify.cdnHost = "fb820e-2.myshopify.com/cdn";
Shopify.routes = Shopify.routes || {};
Shopify.routes.root = "/";</script>
<script type="module">!function(o){(o.Shopify=o.Shopify||{}).modules=!0}(window);</script>
<script>!function(o){function n(){var o=[];function n(){o.push(Array.prototype.slice.apply(arguments))}return n.q=o,n}var t=o.Shopify=o.Shopify||{};t.loadFeatures=n(),t.autoloadFeatures=n()}(window);</script>
<script id="__st">var __st={"a":69059150038,"offset":25200,"reqid":"4db980d2-0443-45c6-b816-db0536917c2f","pageurl":"fb820e-2.myshopify.com\/","u":"e050070f2fa0","p":"home"};</script>
<script>window.ShopifyPaypalV4VisibilityTracking = true;</script>
<script>!function(o){o.addEventListener("DOMContentLoaded",function(){window.Shopify=window.Shopify||{},window.Shopify.recaptchaV3=window.Shopify.recaptchaV3||{siteKey:"6LcCR2cUAAAAANS1Gpq_mDIJ2pQuJphsSQaUEuc9"};var t=['form[action*="/contact"] input[name="form_type"][value="contact"]','form[action*="/comments"] input[name="form_type"][value="new_comment"]','form[action*="/account"] input[name="form_type"][value="customer_login"]','form[action*="/account"] input[name="form_type"][value="recover_customer_password"]','form[action*="/account"] input[name="form_type"][value="create_customer"]','form[action*="/contact"] input[name="form_type"][value="customer"]'].join(",");function n(e){e=e.target;null==e||null!=(e=function e(t,n){if(null==t.parentElement)return null;if("FORM"!=t.parentElement.tagName)return e(t.parentElement,n);for(var o=t.parentElement.action,r=0;r<n.length;r++)if(-1!==o.indexOf(n[r]))return t.parentElement;return null}(e,["/contact","/comments","/account"]))&&null!=e.querySelector(t)&&((e=o.createElement("script")).setAttribute("src","https://cdn.shopify.com/shopifycloud/storefront-recaptcha-v3/v0.6/index.js"),o.body.appendChild(e),o.removeEventListener("focus",n,!0),o.removeEventListener("change",n,!0),o.removeEventListener("click",n,!0))}o.addEventListener("click",n,!0),o.addEventListener("change",n,!0),o.addEventListener("focus",n,!0)})}(document);</script>
<script integrity="sha256-h4dvokWvGcvRSqiG7VnGqoonxF0k3NeoHPLSMjUGIz4=" data-source-attribution="shopify.loadfeatures" defer="defer" src="//fb820e-2.myshopify.com/cdn/shopifycloud/shopify/assets/storefront/load_feature-87876fa245af19cbd14aa886ed59c6aa8a27c45d24dcd7a81cf2d2323506233e.js" crossorigin="anonymous"></script>
<script data-source-attribution="shopify.dynamic_checkout.dynamic.init">var Shopify=Shopify||{};Shopify.PaymentButton=Shopify.PaymentButton||{isStorefrontPortableWallets:!0,init:function(){window.Shopify.PaymentButton.init=function(){};var t=document.createElement("script");t.src="https://fb820e-2.myshopify.com/cdn/shopifycloud/portable-wallets/latest/portable-wallets.en.js",t.type="module",document.head.appendChild(t)}};
</script>
<script integrity="sha256-HAs5a9TQVLlKuuHrahvWuke+s1UlxXohfHeoYv8G2D8=" data-source-attribution="shopify.dynamic-checkout" defer="defer" src="//fb820e-2.myshopify.com/cdn/shopifycloud/shopify/assets/storefront/features-1c0b396bd4d054b94abae1eb6a1bd6ba47beb35525c57a217c77a862ff06d83f.js" crossorigin="anonymous"></script>


<script>window.performance && window.performance.mark && window.performance.mark('shopify.content_for_header.end');</script>


    <style data-shopify>
      @font-face {
  font-family: Assistant;
  font-weight: 400;
  font-style: normal;
  font-display: swap;
  src: url("//fb820e-2.myshopify.com/cdn/fonts/assistant/assistant_n4.bcd3d09dcb631dec5544b8fb7b154ff234a44630.woff2?h1=ZmI4MjBlLTIuYWNjb3VudC5teXNob3BpZnkuY29t&hmac=1129d01f849c39c2d1126071029ea10682ea04cad5f62ccb8691cc44573d6f60") format("woff2"),
       url("//fb820e-2.myshopify.com/cdn/fonts/assistant/assistant_n4.a2d012304becc2a26f1ded1acc136fcab85c9afd.woff?h1=ZmI4MjBlLTIuYWNjb3VudC5teXNob3BpZnkuY29t&hmac=404d343bd25134230407cab19b74c96d89d4b33a4df269de1dfe0415567d5e34") format("woff");
}

      @font-face {
  font-family: Assistant;
  font-weight: 700;
  font-style: normal;
  font-display: swap;
  src: url("//fb820e-2.myshopify.com/cdn/fonts/assistant/assistant_n7.3335c7bdaddf2501ddab87cdbd9be98f3870e10d.woff2?h1=ZmI4MjBlLTIuYWNjb3VudC5teXNob3BpZnkuY29t&hmac=4b3e1cff9605391c000c10291cf08a2fad29425047af9bb2de9a96591c9c35c4") format("woff2"),
       url("//fb820e-2.myshopify.com/cdn/fonts/assistant/assistant_n7.7c85f5c5cc1555de92cc7ef2790ee3cffe5237f5.woff?h1=ZmI4MjBlLTIuYWNjb3VudC5teXNob3BpZnkuY29t&hmac=aa97332aa858cc8602e56c4a02fdb74f692d45788fa3b6455e10f5c8f1cc41eb") format("woff");
}

      
      
      @font-face {
  font-family: Assistant;
  font-weight: 400;
  font-style: normal;
  font-display: swap;
  src: url("//fb820e-2.myshopify.com/cdn/fonts/assistant/assistant_n4.bcd3d09dcb631dec5544b8fb7b154ff234a44630.woff2?h1=ZmI4MjBlLTIuYWNjb3VudC5teXNob3BpZnkuY29t&hmac=1129d01f849c39c2d1126071029ea10682ea04cad5f62ccb8691cc44573d6f60") format("woff2"),
       url("//fb820e-2.myshopify.com/cdn/fonts/assistant/assistant_n4.a2d012304becc2a26f1ded1acc136fcab85c9afd.woff?h1=ZmI4MjBlLTIuYWNjb3VudC5teXNob3BpZnkuY29t&hmac=404d343bd25134230407cab19b74c96d89d4b33a4df269de1dfe0415567d5e34") format("woff");
}


      
        :root,
        .color-background-1 {
          --color-background: 11,11,11;
        
          --gradient-background: #0b0b0b;
        

        

        --color-foreground: 255,255,255;
        --color-background-contrast: 139,139,139;
        --color-shadow: 18,18,18;
        --color-button: 22,20,20;
        --color-button-text: 255,255,255;
        --color-secondary-button: 11,11,11;
        --color-secondary-button-text: 18,18,18;
        --color-link: 18,18,18;
        --color-badge-foreground: 255,255,255;
        --color-badge-background: 11,11,11;
        --color-badge-border: 255,255,255;
        --payment-terms-background-color: rgb(11 11 11);
      }
      
        
        .color-background-2 {
          --color-background: 243,243,243;
        
          --gradient-background: #f3f3f3;
        

        

        --color-foreground: 18,18,18;
        --color-background-contrast: 179,179,179;
        --color-shadow: 18,18,18;
        --color-button: 18,18,18;
        --color-button-text: 243,243,243;
        --color-secondary-button: 243,243,243;
        --color-secondary-button-text: 18,18,18;
        --color-link: 18,18,18;
        --color-badge-foreground: 18,18,18;
        --color-badge-background: 243,243,243;
        --color-badge-border: 18,18,18;
        --payment-terms-background-color: rgb(243 243 243);
      }
      
        
        .color-inverse {
          --color-background: 36,40,51;
        
          --gradient-background: #242833;
        

        

        --color-foreground: 255,255,255;
        --color-background-contrast: 47,52,66;
        --color-shadow: 18,18,18;
        --color-button: 255,255,255;
        --color-button-text: 0,0,0;
        --color-secondary-button: 36,40,51;
        --color-secondary-button-text: 255,255,255;
        --color-link: 255,255,255;
        --color-badge-foreground: 255,255,255;
        --color-badge-background: 36,40,51;
        --color-badge-border: 255,255,255;
        --payment-terms-background-color: rgb(36 40 51);
      }
      
        
        .color-accent-1 {
          --color-background: 18,18,18;
        
          --gradient-background: #121212;
        

        

        --color-foreground: 255,255,255;
        --color-background-contrast: 146,146,146;
        --color-shadow: 18,18,18;
        --color-button: 255,255,255;
        --color-button-text: 18,18,18;
        --color-secondary-button: 18,18,18;
        --color-secondary-button-text: 255,255,255;
        --color-link: 255,255,255;
        --color-badge-foreground: 255,255,255;
        --color-badge-background: 18,18,18;
        --color-badge-border: 255,255,255;
        --payment-terms-background-color: rgb(18 18 18);
      }
      
        
        .color-accent-2 {
          --color-background: 51,79,180;
        
          --gradient-background: #334fb4;
        

        

        --color-foreground: 255,255,255;
        --color-background-contrast: 23,35,81;
        --color-shadow: 18,18,18;
        --color-button: 255,255,255;
        --color-button-text: 51,79,180;
        --color-secondary-button: 51,79,180;
        --color-secondary-button-text: 255,255,255;
        --color-link: 255,255,255;
        --color-badge-foreground: 255,255,255;
        --color-badge-background: 51,79,180;
        --color-badge-border: 255,255,255;
        --payment-terms-background-color: rgb(51 79 180);
      }
      

      body, .color-background-1, .color-background-2, .color-inverse, .color-accent-1, .color-accent-2 {
        color: rgba(var(--color-foreground), 0.75);
        background-color: rgb(var(--color-background));
      }

      :root {
        --font-body-family: Assistant, sans-serif;
        --font-body-style: normal;
        --font-body-weight: 400;
        --font-body-weight-bold: 700;

        --font-heading-family: Assistant, sans-serif;
        --font-heading-style: normal;
        --font-heading-weight: 400;

        --font-body-scale: 1.0;
        --font-heading-scale: 1.0;

        --media-padding: px;
        --media-border-opacity: 0.05;
        --media-border-width: 1px;
        --media-radius: 0px;
        --media-shadow-opacity: 0.0;
        --media-shadow-horizontal-offset: 0px;
        --media-shadow-vertical-offset: 4px;
        --media-shadow-blur-radius: 5px;
        --media-shadow-visible: 0;

        --page-width: 120rem;
        --page-width-margin: 0rem;

        --product-card-image-padding: 0.0rem;
        --product-card-corner-radius: 0.0rem;
        --product-card-text-alignment: left;
        --product-card-border-width: 0.0rem;
        --product-card-border-opacity: 0.1;
        --product-card-shadow-opacity: 0.0;
        --product-card-shadow-visible: 0;
        --product-card-shadow-horizontal-offset: 0.0rem;
        --product-card-shadow-vertical-offset: 0.4rem;
        --product-card-shadow-blur-radius: 0.5rem;

        --collection-card-image-padding: 0.0rem;
        --collection-card-corner-radius: 0.0rem;
        --collection-card-text-alignment: left;
        --collection-card-border-width: 0.0rem;
        --collection-card-border-opacity: 0.1;
        --collection-card-shadow-opacity: 0.0;
        --collection-card-shadow-visible: 0;
        --collection-card-shadow-horizontal-offset: 0.0rem;
        --collection-card-shadow-vertical-offset: 0.4rem;
        --collection-card-shadow-blur-radius: 0.5rem;

        --blog-card-image-padding: 0.0rem;
        --blog-card-corner-radius: 0.0rem;
        --blog-card-text-alignment: left;
        --blog-card-border-width: 0.0rem;
        --blog-card-border-opacity: 0.1;
        --blog-card-shadow-opacity: 0.0;
        --blog-card-shadow-visible: 0;
        --blog-card-shadow-horizontal-offset: 0.0rem;
        --blog-card-shadow-vertical-offset: 0.4rem;
        --blog-card-shadow-blur-radius: 0.5rem;

        --badge-corner-radius: 4.0rem;

        --popup-border-width: 1px;
        --popup-border-opacity: 0.1;
        --popup-corner-radius: 0px;
        --popup-shadow-opacity: 0.05;
        --popup-shadow-horizontal-offset: 0px;
        --popup-shadow-vertical-offset: 4px;
        --popup-shadow-blur-radius: 5px;

        --drawer-border-width: 1px;
        --drawer-border-opacity: 0.1;
        --drawer-shadow-opacity: 0.0;
        --drawer-shadow-horizontal-offset: 0px;
        --drawer-shadow-vertical-offset: 4px;
        --drawer-shadow-blur-radius: 5px;

        --spacing-sections-desktop: 0px;
        --spacing-sections-mobile: 0px;

        --grid-desktop-vertical-spacing: 8px;
        --grid-desktop-horizontal-spacing: 8px;
        --grid-mobile-vertical-spacing: 4px;
        --grid-mobile-horizontal-spacing: 4px;

        --text-boxes-border-opacity: 0.1;
        --text-boxes-border-width: 0px;
        --text-boxes-radius: 0px;
        --text-boxes-shadow-opacity: 0.0;
        --text-boxes-shadow-visible: 0;
        --text-boxes-shadow-horizontal-offset: 0px;
        --text-boxes-shadow-vertical-offset: 4px;
        --text-boxes-shadow-blur-radius: 5px;

        --buttons-radius: 0px;
        --buttons-radius-outset: 0px;
        --buttons-border-width: 1px;
        --buttons-border-opacity: 1.0;
        --buttons-shadow-opacity: 0.0;
        --buttons-shadow-visible: 0;
        --buttons-shadow-horizontal-offset: 0px;
        --buttons-shadow-vertical-offset: 4px;
        --buttons-shadow-blur-radius: 5px;
        --buttons-border-offset: 0px;

        --inputs-radius: 0px;
        --inputs-border-width: 1px;
        --inputs-border-opacity: 0.55;
        --inputs-shadow-opacity: 0.0;
        --inputs-shadow-horizontal-offset: 0px;
        --inputs-margin-offset: 0px;
        --inputs-shadow-vertical-offset: 4px;
        --inputs-shadow-blur-radius: 5px;
        --inputs-radius-outset: 0px;

        --variant-pills-radius: 40px;
        --variant-pills-border-width: 1px;
        --variant-pills-border-opacity: 0.55;
        --variant-pills-shadow-opacity: 0.0;
        --variant-pills-shadow-horizontal-offset: 0px;
        --variant-pills-shadow-vertical-offset: 4px;
        --variant-pills-shadow-blur-radius: 5px;
      }

      *,
      *::before,
      *::after {
        box-sizing: inherit;
      }

      html {
        box-sizing: border-box;
        font-size: calc(var(--font-body-scale) * 62.5%);
        height: 100%;
      }

      body {
        display: grid;
        grid-template-rows: auto auto 1fr auto;
        grid-template-columns: 100%;
        min-height: 100%;
        margin: 0;
        font-size: 1.5rem;
        letter-spacing: 0.06rem;
        line-height: calc(1 + 0.8 / var(--font-body-scale));
        font-family: var(--font-body-family);
        font-style: var(--font-body-style);
        font-weight: var(--font-body-weight);
      }

      @media screen and (min-width: 750px) {
        body {
          font-size: 1.6rem;
        }
      }
    </style>

    <link href="//fb820e-2.myshopify.com/cdn/shop/t/1/assets/base.css?v=22615539281115885671705725804" rel="stylesheet" type="text/css" media="all" />
<link rel="preload" as="font" href="//fb820e-2.myshopify.com/cdn/fonts/assistant/assistant_n4.bcd3d09dcb631dec5544b8fb7b154ff234a44630.woff2?h1=ZmI4MjBlLTIuYWNjb3VudC5teXNob3BpZnkuY29t&hmac=1129d01f849c39c2d1126071029ea10682ea04cad5f62ccb8691cc44573d6f60" type="font/woff2" crossorigin><link rel="preload" as="font" href="//fb820e-2.myshopify.com/cdn/fonts/assistant/assistant_n4.bcd3d09dcb631dec5544b8fb7b154ff234a44630.woff2?h1=ZmI4MjBlLTIuYWNjb3VudC5teXNob3BpZnkuY29t&hmac=1129d01f849c39c2d1126071029ea10682ea04cad5f62ccb8691cc44573d6f60" type="font/woff2" crossorigin><link
        rel="stylesheet"
        href="//fb820e-2.myshopify.com/cdn/shop/t/1/assets/component-predictive-search.css?v=118923337488134913561705725813"
        media="print"
        onload="this.media='all'"
      ><script>
      document.documentElement.className = document.documentElement.className.replace('no-js', 'js');
      if (Shopify.designMode) {
        document.documentElement.classList.add('shopify-design-mode');
      }
    </script>
  <link href="https://monorail-edge.shopifysvc.com" rel="dns-prefetch">
<script>(function(){if ("sendBeacon" in navigator && "performance" in window) {var session_token = document.cookie.match(/_shopify_s=([^;]*)/);function handle_abandonment_event(e) {var entries = performance.getEntries().filter(function(entry) {return /monorail-edge.shopifysvc.com/.test(entry.name);});if (!window.abandonment_tracked && entries.length === 0) {window.abandonment_tracked = true;var currentMs = Date.now();var navigation_start = performance.timing.navigationStart;var payload = {shop_id: 69059150038,url: window.location.href,navigation_start,duration: currentMs - navigation_start,session_token: session_token && session_token.length === 2 ? session_token[1] : "",page_type: "index"};window.navigator.sendBeacon("https://monorail-edge.shopifysvc.com/v1/produce", JSON.stringify({schema_id: "online_store_buyer_site_abandonment/1.1",payload: payload,metadata: {event_created_at_ms: currentMs,event_sent_at_ms: currentMs}}));}}window.addEventListener('pagehide', handle_abandonment_event);}}());</script>
<script id="web-pixels-manager-setup">(function e(e,n,a,t,o,r,i){var s=null!==e,l=("function"==typeof BigInt&&BigInt.toString().indexOf("[native code]")?"modern":"legacy").substring(0,1),c=t.substring(0,1);if(s){window.Shopify=window.Shopify||{};var d=window.Shopify;d.analytics=d.analytics||{};var u=d.analytics;u.replayQueue=[],u.publish=function(e,n,a){u.replayQueue.push([e,n,a])};try{self.performance.mark("wpm:start")}catch(e){}}var p,f,y,h,v,m,w,g,b,_=[a,"/wpm","/",c,r,l,".js"].join("");f=(p={src:_,async:!0,onload:function(){if(e){var a=window.webPixelsManager.init(e);null==n||n(a);var t=window.Shopify.analytics;t.replayQueue.forEach((function(e){var n=e[0],t=e[1],o=e[2];a.publishCustomEvent(n,t,o)})),t.replayQueue=[],t.publish=a.publishCustomEvent,t.visitor=a.visitor}},onerror:function(){var n=(null==e?void 0:e.storefrontBaseUrl)?e.storefrontBaseUrl.replace(/\/$/,""):self.location.origin,a="".concat(n,"/.well-known/shopify/monorail/unstable/produce_batch"),t=JSON.stringify({metadata:{event_sent_at_ms:(new Date).getTime()},events:[{schema_id:"web_pixels_manager_load/2.0",payload:{version:o||"latest",page_url:self.location.href,status:"failed",error_msg:"".concat(_," has failed to load")},metadata:{event_created_at_ms:(new Date).getTime()}}]});try{if(self.navigator.sendBeacon.bind(self.navigator)(a,t))return!0}catch(e){}var r=new XMLHttpRequest;try{return r.open("POST",a,!0),r.setRequestHeader("Content-Type","text/plain"),r.send(t),!0}catch(e){console&&console.warn&&console.warn("[Web Pixels Manager] Got an unhandled error while logging a load error.")}return!1}}).src,y=p.async,h=void 0===y||y,v=p.onload,m=p.onerror,w=document.createElement("script"),g=document.head,b=document.body,w.async=h,w.src=f,v&&w.addEventListener("load",v),m&&w.addEventListener("error",m),g?g.appendChild(w):b?b.appendChild(w):console.error("Did not find a head or body element to append the script")})({shopId: 69059150038,storefrontBaseUrl: "https://fb820e-2.myshopify.com",cdnBaseUrl: "https://fb820e-2.myshopify.com/cdn",surface: "storefront-renderer",enabledBetaFlags: ["web_pixels_async_pixel_refactor","web_pixels_manager_performance_improvement"],webPixelsConfigList: [{"id":"shopify-app-pixel","configuration":"{}","eventPayloadVersion":"v1","runtimeContext":"STRICT","scriptVersion":"0570","apiClientId":"shopify-pixel","type":"APP"},{"id":"shopify-custom-pixel","eventPayloadVersion":"v1","runtimeContext":"LAX","scriptVersion":"0570","apiClientId":"shopify-pixel","type":"CUSTOM"}],initData: {"cart":null,"checkout":null,"customer":null,"productVariants":[]},},function pageEvents(webPixelsManagerAPI) {webPixelsManagerAPI.publish("page_viewed");},"https://fb820e-2.myshopify.com/cdn","browser","0.0.419","9945bf9fw9f0493d3pc3794183m37925d68",["web_pixels_async_pixel_refactor","web_pixels_manager_performance_improvement"]);</script>  <script>window.ShopifyAnalytics = window.ShopifyAnalytics || {};
window.ShopifyAnalytics.meta = window.ShopifyAnalytics.meta || {};
window.ShopifyAnalytics.meta.currency = 'IDR';
var meta = {"page":{"pageType":"home"}};
for (var attr in meta) {
  window.ShopifyAnalytics.meta[attr] = meta[attr];
}</script>
<script>window.ShopifyAnalytics.merchantGoogleAnalytics = function() {
  
};
</script>
<script class="analytics">(function () {
    var customDocumentWrite = function(content) {
      var jquery = null;

      if (window.jQuery) {
        jquery = window.jQuery;
      } else if (window.Checkout && window.Checkout.$) {
        jquery = window.Checkout.$;
      }

      if (jquery) {
        jquery('body').append(content);
      }
    };

    var hasLoggedConversion = function(token) {
      if (token) {
        return document.cookie.indexOf('loggedConversion=' + token) !== -1;
      }
      return false;
    }

    var setCookieIfConversion = function(token) {
      if (token) {
        var twoMonthsFromNow = new Date(Date.now());
        twoMonthsFromNow.setMonth(twoMonthsFromNow.getMonth() + 2);

        document.cookie = 'loggedConversion=' + token + '; expires=' + twoMonthsFromNow;
      }
    }

    var trekkie = window.ShopifyAnalytics.lib = window.trekkie = window.trekkie || [];
    if (trekkie.integrations) {
      return;
    }
    trekkie.methods = [
      'identify',
      'page',
      'ready',
      'track',
      'trackForm',
      'trackLink'
    ];
    trekkie.factory = function(method) {
      return function() {
        var args = Array.prototype.slice.call(arguments);
        args.unshift(method);
        trekkie.push(args);
        return trekkie;
      };
    };
    for (var i = 0; i < trekkie.methods.length; i++) {
      var key = trekkie.methods[i];
      trekkie[key] = trekkie.factory(key);
    }
    trekkie.load = function(config) {
      trekkie.config = config || {};
      trekkie.config.initialDocumentCookie = document.cookie;
      var first = document.getElementsByTagName('script')[0];
      var script = document.createElement('script');
      script.type = 'text/javascript';
      script.onerror = function(e) {
        var scriptFallback = document.createElement('script');
        scriptFallback.type = 'text/javascript';
        scriptFallback.onerror = function(error) {
                var Monorail = {
      produce: function produce(monorailDomain, schemaId, payload) {
        var currentMs = new Date().getTime();
        var event = {
          schema_id: schemaId,
          payload: payload,
          metadata: {
            event_created_at_ms: currentMs,
            event_sent_at_ms: currentMs
          }
        };
        return Monorail.sendRequest("https://" + monorailDomain + "/v1/produce", JSON.stringify(event));
      },
      sendRequest: function sendRequest(endpointUrl, payload) {
        // Try the sendBeacon API
        if (window && window.navigator && typeof window.navigator.sendBeacon === 'function' && typeof window.Blob === 'function' && !Monorail.isIos12()) {
          var blobData = new window.Blob([payload], {
            type: 'text/plain'
          });

          if (window.navigator.sendBeacon(endpointUrl, blobData)) {
            return true;
          } // sendBeacon was not successful

        } // XHR beacon

        var xhr = new XMLHttpRequest();

        try {
          xhr.open('POST', endpointUrl);
          xhr.setRequestHeader('Content-Type', 'text/plain');
          xhr.send(payload);
        } catch (e) {
          console.log(e);
        }

        return false;
      },
      isIos12: function isIos12() {
        return window.navigator.userAgent.lastIndexOf('iPhone; CPU iPhone OS 12_') !== -1 || window.navigator.userAgent.lastIndexOf('iPad; CPU OS 12_') !== -1;
      }
    };
    Monorail.produce('monorail-edge.shopifysvc.com',
      'trekkie_storefront_load_errors/1.1',
      {shop_id: 69059150038,
      theme_id: 139932238038,
      app_name: "storefront",
      context_url: window.location.href,
      source_url: "//fb820e-2.myshopify.com/cdn/s/trekkie.storefront.f2da2901761ed691d459433ada0e4d90e085713c.min.js"});

        };
        scriptFallback.async = true;
        scriptFallback.src = '//fb820e-2.myshopify.com/cdn/s/trekkie.storefront.f2da2901761ed691d459433ada0e4d90e085713c.min.js';
        first.parentNode.insertBefore(scriptFallback, first);
      };
      script.async = true;
      script.src = '//fb820e-2.myshopify.com/cdn/s/trekkie.storefront.f2da2901761ed691d459433ada0e4d90e085713c.min.js';
      first.parentNode.insertBefore(script, first);
    };
    trekkie.load(
      {"Trekkie":{"appName":"storefront","development":false,"defaultAttributes":{"shopId":69059150038,"isMerchantRequest":null,"themeId":139932238038,"themeCityHash":"8442994870904162449","contentLanguage":"en","currency":"IDR"},"isServerSideCookieWritingEnabled":true,"monorailRegion":"shop_domain"},"Session Attribution":{},"S2S":{"facebookCapiEnabled":false,"source":"trekkie-storefront-renderer"}}
    );

    var loaded = false;
    trekkie.ready(function() {
      if (loaded) return;
      loaded = true;

      window.ShopifyAnalytics.lib = window.trekkie;

  
      var originalDocumentWrite = document.write;
      document.write = customDocumentWrite;
      try { window.ShopifyAnalytics.merchantGoogleAnalytics.call(this); } catch(error) {};
      document.write = originalDocumentWrite;

      window.ShopifyAnalytics.lib.page(null,{"pageType":"home"});

      var match = window.location.pathname.match(/checkouts\/(.+)\/(thank_you|post_purchase)/)
      var token = match? match[1]: undefined;
      if (!hasLoggedConversion(token)) {
        setCookieIfConversion(token);
        
      }
    });


        var eventsListenerScript = document.createElement('script');
        eventsListenerScript.async = true;
        eventsListenerScript.src = "//fb820e-2.myshopify.com/cdn/shopifycloud/shopify/assets/shop_events_listener-a7c63dba65ccddc484f77541dc8ca437e60e1e9e297fe1c3faebf6523a0ede9b.js";
        document.getElementsByTagName('head')[0].appendChild(eventsListenerScript);

})();</script>
<script class="boomerang">
(function () {
  if (window.BOOMR && (window.BOOMR.version || window.BOOMR.snippetExecuted)) {
    return;
  }
  window.BOOMR = window.BOOMR || {};
  window.BOOMR.snippetStart = new Date().getTime();
  window.BOOMR.snippetExecuted = true;
  window.BOOMR.snippetVersion = 12;
  window.BOOMR.application = "storefront-renderer";
  window.BOOMR.themeName = "Dawn";
  window.BOOMR.themeVersion = "12.0.0";
  window.BOOMR.shopId = 69059150038;
  window.BOOMR.themeId = 139932238038;
  window.BOOMR.renderRegion = "gcp-asia-southeast1";
  window.BOOMR.url =
    "https://fb820e-2.myshopify.com/cdn/shopifycloud/boomerang/shopify-boomerang-1.0.0.min.js";
  var where = document.currentScript || document.getElementsByTagName("script")[0];
  var parentNode = where.parentNode;
  var promoted = false;
  var LOADER_TIMEOUT = 3000;
  function promote() {
    if (promoted) {
      return;
    }
    var script = document.createElement("script");
    script.id = "boomr-scr-as";
    script.src = window.BOOMR.url;
    script.async = true;
    parentNode.appendChild(script);
    promoted = true;
  }
  function iframeLoader(wasFallback) {
    promoted = true;
    var dom, bootstrap, iframe, iframeStyle;
    var doc = document;
    var win = window;
    window.BOOMR.snippetMethod = wasFallback ? "if" : "i";
    bootstrap = function(parent, scriptId) {
      var script = doc.createElement("script");
      script.id = scriptId || "boomr-if-as";
      script.src = window.BOOMR.url;
      BOOMR_lstart = new Date().getTime();
      parent = parent || doc.body;
      parent.appendChild(script);
    };
    if (!window.addEventListener && window.attachEvent && navigator.userAgent.match(/MSIE [67]./)) {
      window.BOOMR.snippetMethod = "s";
      bootstrap(parentNode, "boomr-async");
      return;
    }
    iframe = document.createElement("IFRAME");
    iframe.src = "about:blank";
    iframe.title = "";
    iframe.role = "presentation";
    iframe.loading = "eager";
    iframeStyle = (iframe.frameElement || iframe).style;
    iframeStyle.width = 0;
    iframeStyle.height = 0;
    iframeStyle.border = 0;
    iframeStyle.display = "none";
    parentNode.appendChild(iframe);
    try {
      win = iframe.contentWindow;
      doc = win.document.open();
    } catch (e) {
      dom = document.domain;
      iframe.src = "javascript:var d=document.open();d.domain='" + dom + "';void(0);";
      win = iframe.contentWindow;
      doc = win.document.open();
    }
    if (dom) {
      doc._boomrl = function() {
        this.domain = dom;
        bootstrap();
      };
      doc.write("<body onload='document._boomrl();'>");
    } else {
      win._boomrl = function() {
        bootstrap();
      };
      if (win.addEventListener) {
        win.addEventListener("load", win._boomrl, false);
      } else if (win.attachEvent) {
        win.attachEvent("onload", win._boomrl);
      }
    }
    doc.close();
  }
  var link = document.createElement("link");
  if (link.relList &&
    typeof link.relList.supports === "function" &&
    link.relList.supports("preload") &&
    ("as" in link)) {
    window.BOOMR.snippetMethod = "p";
    link.href = window.BOOMR.url;
    link.rel = "preload";
    link.as = "script";
    link.addEventListener("load", promote);
    link.addEventListener("error", function() {
      iframeLoader(true);
    });
    setTimeout(function() {
      if (!promoted) {
        iframeLoader(true);
      }
    }, LOADER_TIMEOUT);
    BOOMR_lstart = new Date().getTime();
    parentNode.appendChild(link);
  } else {
    iframeLoader(false);
  }
  function boomerangSaveLoadTime(e) {
    window.BOOMR_onload = (e && e.timeStamp) || new Date().getTime();
  }
  if (window.addEventListener) {
    window.addEventListener("load", boomerangSaveLoadTime, false);
  } else if (window.attachEvent) {
    window.attachEvent("onload", boomerangSaveLoadTime);
  }
  if (document.addEventListener) {
    document.addEventListener("onBoomerangLoaded", function(e) {
      e.detail.BOOMR.init({
        ResourceTiming: {
          enabled: true,
          trackedResourceTypes: ["script", "img", "css"]
        },
      });
      e.detail.BOOMR.t_end = new Date().getTime();
    });
  } else if (document.attachEvent) {
    document.attachEvent("onpropertychange", function(e) {
      if (!e) e=event;
      if (e.propertyName === "onBoomerangLoaded") {
        e.detail.BOOMR.init({
          ResourceTiming: {
            enabled: true,
            trackedResourceTypes: ["script", "img", "css"]
          },
        });
        e.detail.BOOMR.t_end = new Date().getTime();
      }
    });
  }
})();</script>
</head>

  <body class="gradient">
    <a class="skip-to-content-link button visually-hidden" href="#MainContent">
      Skip to content
    </a><!-- BEGIN sections: header-group -->
<div id="shopify-section-sections--17370915569878__announcement-bar" class="shopify-section shopify-section-group-header-group announcement-bar-section"><link href="//fb820e-2.myshopify.com/cdn/shop/t/1/assets/component-slideshow.css?v=107725913939919748051705725815" rel="stylesheet" type="text/css" media="all" />
<link href="//fb820e-2.myshopify.com/cdn/shop/t/1/assets/component-slider.css?v=142503135496229589681705725815" rel="stylesheet" type="text/css" media="all" />


<div
  class="utility-bar color-background-1 gradient utility-bar--bottom-border"
  
>
  <div class="page-width utility-bar__grid"><div
        class="announcement-bar"
        role="region"
        aria-label="Announcement"
        
      ><p class="announcement-bar__message h5">
            <span><?php echo $name; ?> - LINK SLOT GACOR 2024 TERPERCAYA</span></p></div><div class="localization-wrapper">
</div>
  </div>
</div>


</div>
<!-- END sections: header-group -->

    <main id="MainContent" class="content-for-layout focus-none" role="main" tabindex="-1">
      <section id="shopify-section-template--17370915078358__featured_product_eQtD97" class="shopify-section section section-featured-product"><link href="//fb820e-2.myshopify.com/cdn/shop/t/1/assets/section-main-product.css?v=141059467971401676601705725827" rel="stylesheet" type="text/css" media="all" />
<link href="//fb820e-2.myshopify.com/cdn/shop/t/1/assets/section-featured-product.css?v=77241854885429512531705725826" rel="stylesheet" type="text/css" media="all" />
<link href="//fb820e-2.myshopify.com/cdn/shop/t/1/assets/component-accordion.css?v=180964204318874863811705725806" rel="stylesheet" type="text/css" media="all" />
<link href="//fb820e-2.myshopify.com/cdn/shop/t/1/assets/component-price.css?v=70172745017360139101705725814" rel="stylesheet" type="text/css" media="all" />
<link href="//fb820e-2.myshopify.com/cdn/shop/t/1/assets/component-deferred-media.css?v=14096082462203297471705725808" rel="stylesheet" type="text/css" media="all" />
<link href="//fb820e-2.myshopify.com/cdn/shop/t/1/assets/component-rating.css?v=157771854592137137841705725814" rel="stylesheet" type="text/css" media="all" />
<link href="//fb820e-2.myshopify.com/cdn/shop/t/1/assets/component-volume-pricing.css?v=56284703641257077881705725816" rel="stylesheet" type="text/css" media="all" />
<style data-shopify>.section-template--17370915078358__featured_product_eQtD97-padding {
    padding-top: 27px;
    padding-bottom: 27px;
  }

  @media screen and (min-width: 750px) {
    .section-template--17370915078358__featured_product_eQtD97-padding {
      padding-top: 36px;
      padding-bottom: 36px;
    }
  }</style><script src="//fb820e-2.myshopify.com/cdn/shop/t/1/assets/product-info.js?v=81873523020508815201705725822" defer="defer"></script>
<script src="//fb820e-2.myshopify.com/cdn/shop/t/1/assets/show-more.js?v=135784227224860024771705725829" defer="defer"></script>
<script src="//fb820e-2.myshopify.com/cdn/shop/t/1/assets/price-per-item.js?v=20223165687617204711705725821" defer="defer"></script>
<section class="color-background-1 gradient">
  <div class="page-width section-template--17370915078358__featured_product_eQtD97-padding">
    <div class="featured-product product product--medium grid grid--1-col gradient color-background-1 product--left isolate grid--2-col-tablet">
      <div class="grid__item product__media-wrapper">
        <media-gallery
          id="MediaGallery-template--17370915078358__featured_product_eQtD97"
          role="region"
          aria-label="Gallery Viewer"
          data-desktop-layout="stacked"
        >
          <div
            id="GalleryViewer-template--17370915078358__featured_product_eQtD97"
            class="product__media-list scroll-trigger animate--fade-in"
          ><div class="product__media-item" data-media-id="template--17370915078358__featured_product_eQtD97-34156986892502">
                    

<div
  class="product-media-container media-type-image media-fit-contain global-media-settings gradient constrain-height"
  style="--ratio: 1.0; --preview-ratio: 1.0;"
>
  <noscript><div class="product__media media">
        <img src="//fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163&amp;width=1946" alt="" srcset="//fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163&amp;width=246 246w, //fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163&amp;width=493 493w, //fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163&amp;width=600 600w, //fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163&amp;width=713 713w, //fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163&amp;width=823 823w, //fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163&amp;width=990 990w, //fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163&amp;width=1100 1100w, //fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163&amp;width=1206 1206w, //fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163&amp;width=1346 1346w, //fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163&amp;width=1426 1426w, //fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163&amp;width=1646 1646w, //fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163&amp;width=1946 1946w" width="1946" height="1946" loading="lazy" sizes="(min-width: 1200px) 605px, (min-width: 990px) calc(55.0vw - 10rem), (min-width: 750px) calc((100vw - 11.5rem) / 2), calc(100vw / 1 - 4rem)">
      </div></noscript>

  <modal-opener class="product__modal-opener product__modal-opener--image no-js-hidden" data-modal="#ProductModal-template--17370915078358__featured_product_eQtD97">
    <span class="product__media-icon motion-reduce quick-add-hidden product__media-icon--lightbox" aria-hidden="true"><svg
  aria-hidden="true"
  focusable="false"
  class="icon icon-plus"
  width="19"
  height="19"
  viewBox="0 0 19 19"
  fill="none"
  xmlns="http://www.w3.org/2000/svg"
>
  <path fill-rule="evenodd" clip-rule="evenodd" d="M4.66724 7.93978C4.66655 7.66364 4.88984 7.43922 5.16598 7.43853L10.6996 7.42464C10.9758 7.42395 11.2002 7.64724 11.2009 7.92339C11.2016 8.19953 10.9783 8.42395 10.7021 8.42464L5.16849 8.43852C4.89235 8.43922 4.66793 8.21592 4.66724 7.93978Z" fill="currentColor"/>
  <path fill-rule="evenodd" clip-rule="evenodd" d="M7.92576 4.66463C8.2019 4.66394 8.42632 4.88723 8.42702 5.16337L8.4409 10.697C8.44159 10.9732 8.2183 11.1976 7.94215 11.1983C7.66601 11.199 7.44159 10.9757 7.4409 10.6995L7.42702 5.16588C7.42633 4.88974 7.64962 4.66532 7.92576 4.66463Z" fill="currentColor"/>
  <path fill-rule="evenodd" clip-rule="evenodd" d="M12.8324 3.03011C10.1255 0.323296 5.73693 0.323296 3.03011 3.03011C0.323296 5.73693 0.323296 10.1256 3.03011 12.8324C5.73693 15.5392 10.1255 15.5392 12.8324 12.8324C15.5392 10.1256 15.5392 5.73693 12.8324 3.03011ZM2.32301 2.32301C5.42035 -0.774336 10.4421 -0.774336 13.5395 2.32301C16.6101 5.39361 16.6366 10.3556 13.619 13.4588L18.2473 18.0871C18.4426 18.2824 18.4426 18.599 18.2473 18.7943C18.0521 18.9895 17.7355 18.9895 17.5402 18.7943L12.8778 14.1318C9.76383 16.6223 5.20839 16.4249 2.32301 13.5395C-0.774335 10.4421 -0.774335 5.42035 2.32301 2.32301Z" fill="currentColor"/>
</svg>
</span>

<link href="//fb820e-2.myshopify.com/cdn/shop/t/1/assets/component-loading-spinner.css?v=116724955567955766481705725811" rel="stylesheet" type="text/css" media="all" />

<div class="loading__spinner hidden">
  <svg
    aria-hidden="true"
    focusable="false"
    class="spinner"
    viewBox="0 0 66 66"
    xmlns="http://www.w3.org/2000/svg"
  >
    <circle class="path" fill="none" stroke-width="6" cx="33" cy="33" r="30"></circle>
  </svg>
</div>
<div class="product__media media media--transparent">
      <img src="//fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163&amp;width=1946" alt="" srcset="//fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163&amp;width=246 246w, //fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163&amp;width=493 493w, //fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163&amp;width=600 600w, //fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163&amp;width=713 713w, //fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163&amp;width=823 823w, //fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163&amp;width=990 990w, //fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163&amp;width=1100 1100w, //fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163&amp;width=1206 1206w, //fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163&amp;width=1346 1346w, //fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163&amp;width=1426 1426w, //fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163&amp;width=1646 1646w, //fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163&amp;width=1946 1946w" width="1946" height="1946" loading="lazy" class="image-magnify-lightbox" sizes="(min-width: 1200px) 605px, (min-width: 990px) calc(55.0vw - 10rem), (min-width: 750px) calc((100vw - 11.5rem) / 2), calc(100vw / 1 - 4rem)">
    </div>
    <button class="product__media-toggle quick-add-hidden product__media-zoom-lightbox" type="button" aria-haspopup="dialog" data-media-id="34156986892502">
      <span class="visually-hidden">
        Open media 1 in modal
      </span>
    </button>
  </modal-opener></div>

                  </div></div></media-gallery>
      </div>
      <div class="product__info-wrapper grid__item scroll-trigger animate--slide-in">
        <product-info
          id="ProductInfo-template--17370915078358__featured_product_eQtD97"
          class="product__info-container"
          data-section="template--17370915078358__featured_product_eQtD97"
          data-url="/products/link-slot-gacor-2024-terpercaya"
        ><p
                  class="product__text inline-richtext subtitle"
                  
                ><?php echo $name; ?> SITUS GACOR HARI INI PASTI JACKPOT</p><h2 class="product__title h1" >LINK SLOT GACOR 2024 TERPERCAYA
</h2><div class="no-js-hidden" id="price-template--17370915078358__featured_product_eQtD97" role="status" >
<div
  class="
    price price--large price--sold-out price--show-badge"
>
  <div class="price__container"><div class="price__regular"><span class="visually-hidden visually-hidden--inline">Regular price</span>
        <span class="price-item price-item--regular">
          Rp 10.000,00 IDR
        </span></div>
    <div class="price__sale">
        <span class="visually-hidden visually-hidden--inline">Regular price</span>
        <span>
          <s class="price-item price-item--regular">
            
              
            
          </s>
        </span><span class="visually-hidden visually-hidden--inline">Sale price</span>
      <span class="price-item price-item--sale price-item--last">
        Rp 10.000,00 IDR
      </span>
    </div>
    <small class="unit-price caption hidden">
      <span class="visually-hidden">Unit price</span>
      <span class="price-item price-item--last">
        <span></span>
        <span aria-hidden="true">/</span>
        <span class="visually-hidden">&nbsp;per&nbsp;</span>
        <span>
        </span>
      </span>
    </small>
  </div><span class="badge price__badge-sale color-accent-2">
      Sale
    </span>

    <span class="badge price__badge-sold-out color-inverse">
      Sold out
    </span></div>
</div><div ><form method="post" action="/cart/add" id="product_form_8286836850902" accept-charset="UTF-8" class="shopify-product-form" enctype="multipart/form-data"><input type="hidden" name="form_type" value="product" /><input type="hidden" name="utf8" value="✓" /><input type="hidden" name="id" value="44894683070678">
                      
<input type="hidden" name="product-id" value="8286836850902" /><input type="hidden" name="section-id" value="template--17370915078358__featured_product_eQtD97" /></form></div><div><a href="https://ampdragonhunter.com/"><img src="https://res.cloudinary.com/dls0mwtci/image/upload/v1702619466/daftar-2_tsxnmo.gif" alt="<?php echo $name; ?>" width="100%" layout="responsive" ></img></a></div>
<p
                  class="product__text inline-richtext"
                  
                ><strong><?php echo $name; ?> Situs Gacor Hari Ini dengan tingkat withdraw tertinggi. Daftar <?php echo $name; ?> Sekarang Juga.</strong></p>
        </product-info>
      </div></div>
    

<product-modal id="ProductModal-template--17370915078358__featured_product_eQtD97" class="product-media-modal media-modal">
  <div
    class="product-media-modal__dialog color-background-1 gradient"
    role="dialog"
    aria-label="Media gallery"
    aria-modal="true"
    tabindex="-1"
  >
    <button
      id="ModalClose-template--17370915078358__featured_product_eQtD97"
      type="button"
      class="product-media-modal__toggle"
      aria-label="Close"
    >
      <svg
  xmlns="http://www.w3.org/2000/svg"
  aria-hidden="true"
  focusable="false"
  class="icon icon-close"
  fill="none"
  viewBox="0 0 18 17"
>
  <path d="M.865 15.978a.5.5 0 00.707.707l7.433-7.431 7.579 7.282a.501.501 0 00.846-.37.5.5 0 00-.153-.351L9.712 8.546l7.417-7.416a.5.5 0 10-.707-.708L8.991 7.853 1.413.573a.5.5 0 10-.693.72l7.563 7.268-7.418 7.417z" fill="currentColor">
</svg>

    </button>

    <div
      class="product-media-modal__content color-background-1 gradient"
      role="document"
      aria-label="Media gallery"
      tabindex="0"
    >
<img
    class="global-media-settings global-media-settings--no-shadow"
    srcset="//fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163&width=550 550w,//fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163 600w"
    sizes="(min-width: 750px) calc(100vw - 22rem), 1100px"
    src="//fb820e-2.myshopify.com/cdn/shop/files/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163&width=1445"
    alt="LINK SLOT GACOR 2024 TERPERCAYA"
    loading="lazy"
    width="1100"
    height="1100"
    data-media-id="34156986892502"
  ></div>
  </div>
</product-modal>

  </div>
</section>

<script src="//fb820e-2.myshopify.com/cdn/shop/t/1/assets/product-form.js?v=133081758708377679181705725821" defer="defer"></script>
<script type="application/ld+json">
  {
    "@context": "http://schema.org/",
    "@type": "Product",
    "name": "LINK SLOT GACOR 2024 TERPERCAYA",
    "url": "https:\/\/fb820e-2.myshopify.com\/products\/link-slot-gacor-2024-terpercaya",
    "image": [
        "https:\/\/fb820e-2.myshopify.com\/cdn\/shop\/files\/imgpsh_fullsize_anim_5_cgmv1s.jpg?v=1705726163\u0026width=1920"
      ],
    "description": "<?php echo $name; ?> SITUS GACOR HARI INI DENGAN TINGKAT WITHDRAW TERTINGG. DAFTAR <?php echo $name; ?> SEKARANG JUGA. Segera gabung dan jadilah bagian dari komunitas pemenang di dunia slot online yang menarik ini. Link slot gacor 2024 terpercaya adalah pilihan tepat untuk pecinta judi yang mencari pengalaman bermain yang tak terlupakan.",
    
    "brand": {
      "@type": "Brand",
      "name": "<?php echo $name; ?>"
    },
    "offers": [{
          "@type" : "Offer","availability" : "http://schema.org/OutOfStock",
          "price" : 10000.0,
          "priceCurrency" : "IDR",
          "url" : "https:\/\/fb820e-2.myshopify.com\/products\/link-slot-gacor-2024-terpercaya?variant=44894683070678"
        }
]
  }
</script>

<script>
  document.addEventListener('DOMContentLoaded', function () {
    function isIE() {
      const ua = window.navigator.userAgent;
      const msie = ua.indexOf('MSIE ');
      const trident = ua.indexOf('Trident/');

      return msie > 0 || trident > 0;
    }

    if (!isIE()) return;
    const hiddenInput = document.querySelector('#product-form-template--17370915078358__featured_product_eQtD97 input[name="id"]');
    const noScriptInputWrapper = document.createElement('div');
    const variantSwitcher =
      document.querySelector('variant-radios[data-section="template--17370915078358__featured_product_eQtD97"]') ||
      document.querySelector('variant-selects[data-section="template--17370915078358__featured_product_eQtD97"]');
    noScriptInputWrapper.innerHTML = document.querySelector(
      '.product-form__noscript-wrapper-template--17370915078358__featured_product_eQtD97'
    ).textContent;
    variantSwitcher.outerHTML = noScriptInputWrapper.outerHTML;

    document.querySelector('#Variants-template--17370915078358__featured_product_eQtD97').addEventListener('change', function (event) {
      hiddenInput.value = event.currentTarget.value;
    });
  });
</script>


  <script src="//fb820e-2.myshopify.com/cdn/shop/t/1/assets/product-modal.js?v=116616134454508949461705725822" defer="defer"></script>
  <script src="//fb820e-2.myshopify.com/cdn/shop/t/1/assets/media-gallery.js?v=96661908581229995091705725820" defer="defer"></script>



</section>
    </main>

    <!-- BEGIN sections: footer-group -->
<div id="shopify-section-sections--17370915537110__footer" class="shopify-section shopify-section-group-footer-group">
<link href="//fb820e-2.myshopify.com/cdn/shop/t/1/assets/section-footer.css?v=125160298726032154631705725826" rel="stylesheet" type="text/css" media="all" />
<link href="//fb820e-2.myshopify.com/cdn/shop/t/1/assets/component-newsletter.css?v=4727253280200485261705725812" rel="stylesheet" type="text/css" media="all" />
<link href="//fb820e-2.myshopify.com/cdn/shop/t/1/assets/component-list-menu.css?v=151968516119678728991705725810" rel="stylesheet" type="text/css" media="all" />
<link href="//fb820e-2.myshopify.com/cdn/shop/t/1/assets/component-list-payment.css?v=69253961410771838501705725810" rel="stylesheet" type="text/css" media="all" />
<link href="//fb820e-2.myshopify.com/cdn/shop/t/1/assets/component-list-social.css?v=35792976012981934991705725810" rel="stylesheet" type="text/css" media="all" />
<style data-shopify>.footer {
    margin-top: 0px;
  }

  .section-sections--17370915537110__footer-padding {
    padding-top: 27px;
    padding-bottom: 27px;
  }

  @media screen and (min-width: 750px) {
    .footer {
      margin-top: 0px;
    }

    .section-sections--17370915537110__footer-padding {
      padding-top: 36px;
      padding-bottom: 36px;
    }
  }</style><footer class="footer color-background-1 gradient section-sections--17370915537110__footer-padding"><div class="footer__content-top page-width"><div
          class="footer-block--newsletter scroll-trigger animate--slide-in"
          
            data-cascade
          
        ><div class="footer-block__newsletter"><h2 class="footer-block__heading inline-richtext">Subscribe to our emails</h2><form method="post" action="/contact#ContactFooter" id="ContactFooter" accept-charset="UTF-8" class="footer__newsletter newsletter-form"><input type="hidden" name="form_type" value="customer" /><input type="hidden" name="utf8" value="✓" /><input type="hidden" name="contact[tags]" value="newsletter">
                <div class="newsletter-form__field-wrapper">
                  <div class="field">
                    <input
                      id="NewsletterForm--sections--17370915537110__footer"
                      type="email"
                      name="contact[email]"
                      class="field__input"
                      value=""
                      aria-required="true"
                      autocorrect="off"
                      autocapitalize="off"
                      autocomplete="email"
                      
                      placeholder="Email"
                      required
                    >
                    <label class="field__label" for="NewsletterForm--sections--17370915537110__footer">
                      Email
                    </label>
                    <button
                      type="submit"
                      class="newsletter-form__button field__button"
                      name="commit"
                      id="Subscribe"
                      aria-label="Subscribe"
                    >
                      <svg
  viewBox="0 0 14 10"
  fill="none"
  aria-hidden="true"
  focusable="false"
  class="icon icon-arrow"
  xmlns="http://www.w3.org/2000/svg"
>
  <path fill-rule="evenodd" clip-rule="evenodd" d="M8.537.808a.5.5 0 01.817-.162l4 4a.5.5 0 010 .708l-4 4a.5.5 0 11-.708-.708L11.793 5.5H1a.5.5 0 010-1h10.793L8.646 1.354a.5.5 0 01-.109-.546z" fill="currentColor">
</svg>

                    </button>
                  </div></div></form></div></div>
      </div><div
    class="footer__content-bottom scroll-trigger animate--slide-in"
    
      data-cascade
    
  >
    <div class="footer__content-bottom-wrapper page-width">
      <div class="footer__column footer__localization isolate"></div>
      <div class="footer__column footer__column--info"><div class="footer__payment">
            <span class="visually-hidden">Payment methods</span>
            <ul class="list list-payment" role="list"></ul>
          </div></div>
    </div>
    <div class="footer__content-bottom-wrapper page-width">
      <div class="footer__copyright caption">
        <small class="copyright__content"
          >&copy; 2024, <a href="/" title=""><?php echo $name; ?></a></small>
        <small class="copyright__content"><a target="_blank" rel="nofollow" href="https://www.shopify.com?utm_campaign=poweredby&amp;utm_medium=shopify&amp;utm_source=onlinestore">Powered by Shopify</a></small></div>
    </div>
  </div>
</footer>


</div>
<!-- END sections: footer-group -->

    <ul hidden>
      <li id="a11y-refresh-page-message">Choosing a selection results in a full page refresh.</li>
      <li id="a11y-new-window-message">Opens in a new window.</li>
    </ul>

    <script>
      window.shopUrl = 'https://fb820e-2.myshopify.com';
      window.routes = {
        cart_add_url: '/cart/add',
        cart_change_url: '/cart/change',
        cart_update_url: '/cart/update',
        cart_url: '/cart',
        predictive_search_url: '/search/suggest',
      };

      window.cartStrings = {
        error: `There was an error while updating your cart. Please try again.`,
        quantityError: `You can only add [quantity] of this item to your cart.`,
      };

      window.variantStrings = {
        addToCart: `Add to cart`,
        soldOut: `Sold out`,
        unavailable: `Unavailable`,
        unavailable_with_option: `[value] - Unavailable`,
      };

      window.quickOrderListStrings = {
        itemsAdded: `[quantity] items added`,
        itemAdded: `[quantity] item added`,
        itemsRemoved: `[quantity] items removed`,
        itemRemoved: `[quantity] item removed`,
        viewCart: `View cart`,
        each: `[money]/ea`,
      };

      window.accessibilityStrings = {
        imageAvailable: `Image [index] is now available in gallery view`,
        shareSuccess: `Link copied to clipboard`,
        pauseSlideshow: `Pause slideshow`,
        playSlideshow: `Play slideshow`,
        recipientFormExpanded: `Gift card recipient form expanded`,
        recipientFormCollapsed: `Gift card recipient form collapsed`,
      };
    </script><script src="//fb820e-2.myshopify.com/cdn/shop/t/1/assets/predictive-search.js?v=162273246065392412141705725821" defer="defer"></script></body>
</html>
<?php
    } else {
      feedback404();
      exit;
    }
}

?>